# HelloGraciela Obsidia

A lead generation workspace for HelloGraciela Digital Studio. The assistant works through LinkedIn prospects. The owner sees daily activity, progress and results as they happen.

- **Assistant portal**: assigned leads, today's targets, the next action for each lead, a tracked **Open LinkedIn profile** button, a 💬 notes button with an editable outreach message and **Copy text**, and manual status updates.
- **Owner portal**: a live dashboard with daily and cumulative counts, progress against targets, daily and weekly trend charts, the lead database with assign and reassign, follow-ups, imports, team targets, credentials and a notification centre.
- **One shared database**: every change reaches both portals within about 2 seconds, with no refresh.

## Go live with GitHub and Vercel

1. **Put the code on GitHub.** Create a new private repository and upload the contents of this folder (keep the folder structure: `api/`, `public/`, `server/`, `data/seed/`, `vercel.json`, `package.json`). Don't upload `node_modules/`.
2. **Import it in Vercel.** In Vercel choose *Add New → Project*, pick the repository and click *Deploy*. No build settings are needed: `vercel.json` already says `public/` holds the site and `api/index.js` runs the server.
3. **Add the database.** In the Vercel project open *Storage → Create database → Neon (Postgres)*, keep the free plan and connect it to the project. This adds `DATABASE_URL` automatically.
4. **Redeploy.** In *Deployments*, open the latest one and choose *Redeploy* so it picks up the database.
5. **Finish setup.** Open your site and sign in as the owner with the initial credentials below. Vercel runs in production mode, so Obsidia asks you to replace both initial passwords first. After that the assistant can sign in.

The first request creates the tables, the two accounts, and imports `data/seed/HelloGraciela — Lead Research 18 of 1000 Incomplete 1.xlsx` (18 leads, assigned to the assistant). The original file is not changed.

| Role      | Username      | Initial password |
| --------- | ------------- | ---------------- |
| Owner     | HELLOGRACIELA | hello2026        |
| Assistant | Helloassist   | Helloassist2026  |

Optional settings (Vercel → *Settings → Environment Variables*): `APP_TIMEZONE` (default `Asia/Manila`), and `OWNER_USERNAME`, `OWNER_INITIAL_PASSWORD`, `ASSISTANT_USERNAME`, `ASSISTANT_INITIAL_PASSWORD` if you want different initial accounts. Set these before the first visit. Any Postgres works; Neon is simply the one built into Vercel.

### How it fits Vercel

- **`api/index.js`** is the entry point. Vercel runs it as a serverless function for every `/api/*` request, and serves `public/index.html` and the rest of the front end from its CDN.
- **Data** lives in Postgres, because Vercel functions have no permanent disk.
- **Live updates** come from each portal checking a small change log every 2 seconds (every 15 seconds when the tab is in the background). Serverless functions can't keep a connection open, so this replaces a live stream. Changes appear in the other portal within about 2 seconds, with no refresh.
- **Overdue follow-ups** are checked during normal requests, at most once a minute, because there are no background timers.
- **Uploads** are read in memory and never stored as files. Vercel limits a request to 4.5 MB, so files are capped at 4 MB. Split bigger lists into several files.

## Run it on your computer

Requires Node.js 20 or newer.

```bash
npm install
npm start            # http://localhost:3000
```

Without `DATABASE_URL` it uses an embedded Postgres stored in `data/pglite/`, so nothing else needs installing. Locally it runs in development mode: the initial passwords work and a banner reminds you to change them.

## Tracking rules

| Metric | Counted when |
| --- | --- |
| Profiles opened | Someone clicks **Open LinkedIn profile**. The status moves to *Profile opened* (only from New or Assigned) and the time is recorded. |
| Connection requests sent | Someone confirms **Connection sent** |
| Connections accepted | Someone confirms **Connected** |
| Replies | Someone confirms **Replied** |
| Follow-ups sent | Someone logs **Follow-up sent** (each one counts) |
| Meetings booked | Someone confirms **Meeting booked** |

- Opening a profile never counts as a connection request. Copying a note never counts as a message sent. Both are logged in the lead's history for context.
- Each lead counts once per milestone, the first time it's confirmed, so switching a status back and forth doesn't inflate numbers. **Undo** (15 minutes, or any time for the owner) removes an update from the counts.
- Obsidia never sends LinkedIn requests or messages. It only opens profiles in a new tab.
- Every status change records who made it and when.

Notifications are created for replies, booked meetings, completed daily targets, overdue follow-ups, finished imports and newly assigned leads. Each one has a timestamp and an unread indicator.

## Fit classification

Leads are classified as **Primary fit**, **Secondary fit** or **Not a fit**. If an imported file has a fit or priority column, its value is used. Otherwise the app suggests a fit from the brief, marked *suggested*: founder-led DTC skincare, supplement and ingestible beauty brands in the US and Australia are primary, and adjacent categories or other markets are secondary. The owner or assistant can change it on any lead.

## Imports

Both portals accept CSV, Excel (.xlsx), Word (.docx) and PDF files, up to 4 MB each.

- **Spreadsheets**: preview, automatic header-row detection (title rows are skipped), column mapping and validation. Duplicate LinkedIn URLs are checked against the database and within the file; `au.`, `www.`, letter case, trailing slashes and tracking parameters are normalised. Invalid or company-page URLs and missing names are flagged for correction. Shared or duplicate emails are flagged.
- **Word and PDF**: possible leads are pulled from the text (anchored on LinkedIn URLs or emails). Each one shows the source text, can be edited, and must be approved before it's added. Tables in Word files go through column mapping.
- Missing details are never invented. Values like "Not found" or "Not confirmed" become visible gap flags on the lead.
- Every import ends with a summary: added, skipped, need correction, and added with missing details flagged.

## Security

- Passwords are stored only as salted scrypt hashes in the database. They never appear in front-end code or API responses.
- Sessions use HTTP-only, SameSite cookies (Secure in production) and expire after 14 days. Sign-in limits are stored in the database, so they hold across serverless instances.
- Wrong sign-ins get the same message whether the username or the password was wrong, and response timing is equalised. Repeated failures are rate-limited.
- Every owner-only endpoint is checked on the server. The assistant can't reach settings, credentials, target editing, the team activity feed or owner reporting. Assistants only see leads assigned to them.
- Only the owner can change credentials, and doing so requires the owner's current password. Changing a password signs that account out everywhere else.
- A strict Content Security Policy is in place, and state-changing requests must carry the app's own header.

## Tests

```bash
python3 tests/make_fixtures.py   # sample CSV, Excel, Word and PDF files (already included)
npm test                         # starts a throwaway server and runs the end-to-end checks in Chromium
TEST_DATABASE_URL=postgres://… npm test   # same checks against a real Postgres database
```

The suite covers 87 checks: both logins, permissions, correct LinkedIn links, automatic profile-open tracking, note editing and copying, manual statuses, undo, targets, assignment, every import type, duplicate detection, unsupported files, notifications, charts, live updates in both directions, mobile layout, credential changes and the production setup gate.

## Brand

- Colours come from the HelloGraciela colour system: Seashell `#FBF6EC` for backgrounds (60–70%), Denim `#5E82AE` for interaction and emphasis (20–30%), and Obsidian `#2B2B2B` for structure (10–20%). A slightly deeper Denim, `#45689A`, is used for button text and links so they pass contrast checks.
- The logo is the supplied wordmark, with the white background removed.
- Type is Playfair Display for headings and Inter for interface text. These stand in until the brand fonts are confirmed, and can be swapped in `public/styles.css`.
- Outreach templates live in **Settings → Outreach templates**. You can edit them and refresh notes for leads that haven't been contacted yet.

## Project layout

```
api/index.js Vercel entry point (serverless function)
vercel.json  Vercel routing, static folder and security headers
server/      Express API, auth, Postgres storage, import parsing, metrics, live change log
public/      Front end served as static files (plain ES modules, no build step), styles, brand assets
data/seed/   The original leads file imported on first run
tests/       End-to-end suite and fixtures
```
