// Vercel entry point. Every /api/* request is routed here (see vercel.json);
// the front end in public/ is served as static files.
import app from '../server/app.js';

export default app;
