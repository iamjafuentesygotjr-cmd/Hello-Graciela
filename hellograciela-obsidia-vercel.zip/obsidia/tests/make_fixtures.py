"""Builds sample import files used by the end-to-end test."""
import csv, os
from openpyxl import Workbook
import docx
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

D = os.path.join(os.path.dirname(__file__), 'fixtures')
os.makedirs(D, exist_ok=True)

rows = [
    ['Name', 'Job title', 'LinkedIn', 'Company', 'Website', 'Email', 'Location', 'Category'],
    ['Maya Test', 'Founder', 'https://www.linkedin.com/in/maya-test-001', 'Maya Skin Lab', 'mayaskin.example', 'maya@mayaskin.example', 'Denver, United States', 'Ingredient-led skincare'],
    ['Alli Reed', 'Founder & CEO', 'linkedin.com/in/AlliReed/', 'Stratia', 'stratiaskin.com', 'info@stratiaskin.com', 'Los Angeles, United States', 'Ingredient-led skincare'],
    ['Maya Test Copy', 'Founder', 'https://www.linkedin.com/in/maya-test-001?trk=abc', 'Maya Skin Lab', '', '', 'Denver, United States', 'Ingredient-led skincare'],
    ['Company Page Person', 'CEO', 'https://www.linkedin.com/company/some-brand', 'Some Brand', '', '', 'Austin, United States', 'Skincare'],
    ['', 'Founder', 'https://www.linkedin.com/in/no-name-person', 'Nameless Co', '', '', 'Sydney, Australia', 'Supplements'],
    ['Priya Shared', 'Brand Manager', 'https://www.linkedin.com/in/priya-shared-002', 'Stratia', 'stratiaskin.com', 'info@stratiaskin.com', 'Los Angeles, United States', 'Ingredient-led skincare'],
    ['Oliver Aussie', 'Co-founder', 'https://au.linkedin.com/in/oliver-aussie-003', 'Gut Glow', 'gutglow.example', 'Not found', 'Melbourne, Australia', 'Functional supplements'],
]
with open(os.path.join(D, 'new-leads.csv'), 'w', newline='') as f:
    csv.writer(f).writerows(rows)

wb = Workbook(); ws = wb.active; ws.title = 'Prospects'
ws.append(['Prospect list — September']); ws.append(['Prepared for HelloGraciela']); ws.append([])
ws.append(['First name', 'Last name', 'Position', 'Profile URL', 'Brand', 'Country', 'Niche', 'Fit'])
ws.append(['Hana', 'Sheet', 'Founder', 'https://www.linkedin.com/in/hana-sheet-010', 'Hana Beauty', 'United States', 'Collagen supplements', 'Secondary'])
ws.append(['Leo', 'Sheet', 'CMO', 'https://www.linkedin.com/in/leo-sheet-011', 'Leo Hair', 'Canada', 'Haircare', ''])
ws2 = wb.create_sheet('Notes'); ws2.append(['Nothing to import here'])
wb.save(os.path.join(D, 'more-leads.xlsx'))

d = docx.Document()
d.add_heading('Prospects from the September event', 1)
d.add_paragraph('Name: Grace Wordsworth\nTitle: Founder & CEO\nCompany: Word Skin Co\nhttps://www.linkedin.com/in/grace-wordsworth-020\ngrace@wordskin.example')
d.add_paragraph('Tom Docx\nHead of Brand at Docx Vitamins\nlinkedin.com/in/tom-docx-021\nAustralia')
d.add_paragraph('A general note with no contact details at all.')
d.save(os.path.join(D, 'event-notes.docx'))

c = canvas.Canvas(os.path.join(D, 'research.pdf'), pagesize=letter)
y = 740
for line in ['Lead research summary', '', 'Pia Portable', 'Co-Founder at Portable Skincare', 'https://www.linkedin.com/in/pia-portable-030', 'pia@portable.example', '',
             'Sam Scanline', 'Chief Executive Officer', 'https://au.linkedin.com/in/sam-scanline-031', 'Australia']:
    c.drawString(72, y, line); y -= 18
c.save()

open(os.path.join(D, 'picture.png'), 'wb').write(b'\x89PNG\r\n\x1a\n' + b'\0' * 64)
open(os.path.join(D, 'legacy.xls'), 'wb').write(b'\xd0\xcf\x11\xe0' + b'\0' * 64)
print('fixtures written to', D)
