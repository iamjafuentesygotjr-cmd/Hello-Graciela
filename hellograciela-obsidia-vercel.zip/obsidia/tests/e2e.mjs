// End-to-end check of HelloGraciela Obsidia. Starts its own server on a throwaway database.
// Run: npm test   (needs Playwright's Chromium; set CHROMIUM_PATH if it isn't found automatically)
// Set TEST_DATABASE_URL to run against a real Postgres instead of the embedded one.
import { chromium, request } from 'playwright';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const FIX = path.join(ROOT, 'tests', 'fixtures');
const PORT = 3100 + Math.floor(Math.random() * 500);
const BASE = `http://localhost:${PORT}`;
const OWNER = { u: 'HELLOGRACIELA', p: 'hello2026' };
const ASSIST = { u: 'Helloassist', p: 'Helloassist2026' };
const results = [];
const check = (name, ok, detail = '') => { results.push({ name, ok: !!ok, detail }); console.log(`${ok ? '✓' : '✗'} ${name}${detail && !ok ? ` — ${detail}` : ''}`); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function startServer(extraEnv = {}, port = PORT) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'obsidia-e2e-'));
  const proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'server/index.js'], {
    cwd: ROOT, env: { ...process.env, PORT: String(port), DATA_DIR: dataDir, DATABASE_URL: extraEnv.DATABASE_URL ?? process.env.TEST_DATABASE_URL ?? '', ...extraEnv }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = '';
  proc.stdout.on('data', d => { log += d; });
  proc.stderr.on('data', d => { log += d; });
  return { proc, dataDir, log: () => log };
}
async function waitUp(base) {
  for (let i = 0; i < 80; i++) { try { const r = await fetch(`${base}/api/me`); if (r.status) return; } catch {} await sleep(250); }
  throw new Error('server did not start');
}
async function apiCtx(base, creds) {
  const ctx = await request.newContext({ baseURL: base, extraHTTPHeaders: { 'X-Obsidia': '1' } });
  if (creds) {
    const r = await ctx.post('/api/auth/login', { data: { username: creds.u, password: creds.p } });
    if (!r.ok()) throw new Error(`login failed for ${creds.u}`);
  }
  return ctx;
}
const j = async (r) => { try { return await r.json(); } catch { return null; } };

const server = startServer();
let browser;
try {
  await waitUp(BASE);
  const exe = process.env.CHROMIUM_PATH || (fs.existsSync('/opt/pw-browsers/chromium') ? '/opt/pw-browsers/chromium' : undefined);
  browser = await chromium.launch({ executablePath: exe });

  // ---------------- Seed import ----------------
  const ownerApi = await apiCtx(BASE, OWNER);
  const assistApi = await apiCtx(BASE, ASSIST);
  let leads = (await j(await ownerApi.get('/api/leads'))).leads;
  check('Initial file imported: 18 leads', leads.length === 18, `got ${leads.length}`);
  const imports = (await j(await ownerApi.get('/api/imports'))).imports;
  const seedSummary = imports[0]?.summary;
  check('Import summary recorded (18 added, 0 skipped, 0 need correction)', seedSummary && seedSummary.added === 18 && seedSummary.skipped === 0 && seedSummary.need_correction === 0, JSON.stringify(seedSummary && { a: seedSummary.added, s: seedSummary.skipped, c: seedSummary.need_correction }));
  check('Missing details flagged, not invented', leads.find(l => l.full_name === 'Liah Yoo').business_email === null && leads.find(l => l.full_name === 'Liah Yoo').gaps.business_email === 'Not found');
  check('Original file preserved', fs.existsSync(path.join(ROOT, 'data', 'seed', 'HelloGraciela — Lead Research 18 of 1000 Incomplete 1.xlsx')));

  // ---------------- Login & permissions ----------------
  const anon = await apiCtx(BASE);
  const bad1 = await anon.post('/api/auth/login', { data: { username: OWNER.u, password: 'wrong-password' } });
  const bad2 = await anon.post('/api/auth/login', { data: { username: 'not-a-user', password: OWNER.p } });
  const m1 = (await j(bad1)).error, m2 = (await j(bad2)).error;
  check('Wrong password is rejected', bad1.status() === 401);
  check('Wrong username is rejected', bad2.status() === 401);
  check('Error message doesn’t reveal which credential was wrong', m1 === m2 && !/username|password is|user not/i.test(m1.replace('username and password combination', '')), m1);
  check('No access without signing in', (await anon.get('/api/leads')).status() === 401);
  check('Requests without the app header are blocked (CSRF)', (await (await request.newContext({ baseURL: BASE })).post('/api/auth/login', { data: { username: OWNER.u, password: OWNER.p } })).status() === 403);

  const ownerOnly = [
    ['GET', '/api/metrics'], ['GET', '/api/settings'], ['PUT', '/api/settings'], ['GET', '/api/activity'],
    ['POST', '/api/leads/assign'], ['PUT', '/api/users/1/credentials'], ['PUT', '/api/users/2'], ['POST', '/api/users'], ['DELETE', `/api/leads/${leads[0].id}`],
  ];
  let allBlocked = true;
  for (const [m, u] of ownerOnly) {
    const r = await assistApi.fetch(u, { method: m, data: {} });
    if (r.status() !== 403) { allBlocked = false; console.log('   not blocked:', m, u, r.status()); }
  }
  check('Assistant is blocked from owner settings, credentials and reporting APIs', allBlocked);
  const aUsers = (await j(await assistApi.get('/api/users'))).users;
  check('Assistant cannot list other accounts', aUsers.length === 1 && aUsers[0].username === ASSIST.u);

  // Passwords never in front-end code
  const assets = ['/', '/js/app.js', '/js/util.js', '/js/leads.js', '/js/assistant.js', '/js/owner.js', '/js/imports.js', '/js/charts.js'];
  let leaked = false;
  for (const a of assets) { const t = await (await fetch(BASE + a)).text(); if (/hello2026|Helloassist2026/.test(t)) leaked = true; }
  check('Initial passwords are not in any front-end file', !leaked);
  const usersRaw = JSON.stringify(await j(await ownerApi.get('/api/users')));
  check('APIs never return password hashes', !/password_hash|scrypt\$/.test(usersRaw));

  // ---------------- Browser sessions ----------------
  const mk = async (creds, opts = {}) => {
    const c = await browser.newContext({ viewport: { width: 1360, height: 900 }, permissions: ['clipboard-read', 'clipboard-write'], ...opts });
    await c.route(/linkedin\.com/, route => route.fulfill({ status: 200, contentType: 'text/html', body: '<title>LinkedIn stub</title>LinkedIn stub' }));
    const p = await c.newPage();
    p.errors = [];
    p.on('pageerror', e => p.errors.push(e.message));
    await p.goto(BASE);
    await p.fill('input[name=username]', creds.u);
    await p.fill('input[name=password]', creds.p);
    await p.click('button[type=submit]');
    return { c, p };
  };
  // Browser login failure path
  {
    const c = await browser.newContext(); const p = await c.newPage();
    await p.goto(BASE); await p.fill('input[name=username]', 'Helloassist'); await p.fill('input[name=password]', 'nope');
    await p.click('button[type=submit]');
    await p.waitForSelector('[data-err]:not(:empty)');
    const msg = await p.textContent('[data-err]');
    check('Sign-in screen shows a neutral error and stays locked', /combination didn’t work/.test(msg) && await p.locator('.topbar').count() === 0, msg);
    await c.close();
  }

  const A = await mk(ASSIST);
  await A.p.waitForSelector('.lead');
  const O = await mk(OWNER);
  await O.p.waitForSelector('.metric-card');
  check('Assistant signs in to the assistant portal', await A.p.locator('.portal-chip').textContent() === 'Assistant portal');
  check('Owner signs in to the owner portal', await O.p.locator('.portal-chip').textContent() === 'Owner portal');
  check('Assistant portal has no owner navigation or settings', await A.p.locator('.nav').count() === 0 && await A.p.locator('[data-cred]').count() === 0);
  await A.p.evaluate(() => { location.hash = '#/settings'; });
  await sleep(400);
  check('Assistant cannot reach settings by URL', await A.p.locator('[data-cred], [data-templates]').count() === 0);
  await A.p.waitForFunction(() => document.querySelector('[data-live] span')?.textContent === 'Live');
  await O.p.waitForFunction(() => document.querySelector('[data-live] span')?.textContent === 'Live');
  check('Both portals connect to live updates', true);

  // LinkedIn links
  leads = (await j(await assistApi.get('/api/leads'))).leads;
  const hrefs = await A.p.$$eval('[data-act="open"]', els => els.map(e => ({ id: +e.dataset.id, href: e.getAttribute('href'), target: e.target, rel: e.rel })));
  const linkOk = hrefs.length === 18 && hrefs.every(h => { const l = leads.find(x => x.id === h.id); return l && h.href === l.linkedin_url && h.target === '_blank' && /noopener/.test(h.rel); });
  check('Every lead has an Open LinkedIn profile button with its own URL, opening in a new tab', linkOk);
  const alli = leads.find(l => l.full_name === 'Alli Reed');
  check('LinkedIn URL matches the source file', alli.linkedin_url === 'https://www.linkedin.com/in/allireed');

  // ---------------- Profile open tracking ----------------
  await A.p.click('[data-filter="all"]'); // leads move between filters as their status changes
  const card = A.p.locator(`#lead-${alli.id}`);
  const [popup] = await Promise.all([A.c.waitForEvent('page'), card.locator('[data-act="open"]').click()]);
  await popup.waitForLoadState();
  check('Clicking the button opens the correct profile in a new tab', popup.url() === 'https://www.linkedin.com/in/allireed', popup.url());
  await popup.close();
  await A.p.waitForFunction((id) => document.querySelector(`#lead-${id} .status`)?.textContent === 'Profile opened', alli.id);
  const alli2 = (await j(await assistApi.get(`/api/leads/${alli.id}`)));
  check('Status is set to Profile opened automatically', alli2.lead.status === 'Profile opened');
  check('Open time and person are recorded', !!alli2.lead.profile_opened_at && alli2.lead.profile_opened_by_name === 'Assistant');
  let met = await j(await ownerApi.get('/api/metrics'));
  check('Profile open counts as opened, not as a connection request', met.metrics.profiles_opened.today === 1 && met.metrics.connections_sent.today === 0);
  await O.p.waitForFunction(() => document.querySelector('.metric-card .value b')?.textContent === '1', null, { timeout: 5000 });
  check('Owner dashboard updates live without refresh', true);

  // ---------------- Notes ----------------
  await card.locator('[data-act="note"]').click();
  const ta = card.locator('textarea[data-note="connection"]');
  await ta.waitFor();
  const noteText = await ta.inputValue();
  check('💬 reveals the prepared outreach note for that lead', /^Hi Alli, /.test(noteText) && noteText.includes('Stratia'), noteText.slice(0, 60));
  await ta.fill('Hi Alli, loved the Stratia barrier range. Would be glad to connect.');
  await sleep(1200);
  const saved = (await j(await ownerApi.get(`/api/leads/${alli.id}`))).lead.connection_note;
  check('Edited note is saved', saved === 'Hi Alli, loved the Stratia barrier range. Would be glad to connect.');
  await card.locator('[data-act="note-copy"]').click();
  await sleep(400);
  const clip = await A.p.evaluate(() => navigator.clipboard.readText());
  check('Copy text puts the edited note on the clipboard', clip === saved, clip);
  const after = (await j(await ownerApi.get(`/api/leads/${alli.id}`)));
  met = await j(await ownerApi.get('/api/metrics'));
  check('Copying is logged but not counted as a message or request', after.activity.some(a => a.type === 'note_copied') && met.metrics.connections_sent.total === 0 && after.lead.status === 'Profile opened');
  await A.p.keyboard.press('Escape');

  // ---------------- Manual statuses ----------------
  const confirmStatus = async (page, scope, label) => {
    await scope.getByRole('button', { name: label }).click();
    await page.locator('.modal button[type=submit]').click();
    await page.waitForSelector('.modal', { state: 'detached' });
  };
  await confirmStatus(A.p, card, 'Mark connection sent');
  await A.p.waitForFunction((id) => document.querySelector(`#lead-${id} .status`)?.textContent === 'Connection sent', alli.id);
  let act = (await j(await ownerApi.get(`/api/leads/${alli.id}`))).activity.find(a => a.type === 'status_change');
  check('Connection sent is a separate confirmed action, recorded with who and when', act && act.to_status === 'Connection sent' && act.user_name === 'Assistant' && !!act.created_at);
  await O.p.waitForFunction(() => document.querySelectorAll('.metric-card .value b')[1]?.textContent === '1');
  check('Owner sees the connection request count update live', true);

  await confirmStatus(A.p, card, 'Mark connected');
  await A.p.waitForFunction((id) => document.querySelector(`#lead-${id} .status`)?.textContent === 'Connected', alli.id);
  await confirmStatus(A.p, card, 'Mark replied');
  await O.p.waitForFunction(() => document.querySelector('[data-badge]') && !document.querySelector('[data-badge]').hidden && +document.querySelector('[data-badge]').textContent >= 2);
  await O.p.click('[data-notif]');
  const notifText = await O.p.textContent('.notif-panel');
  check('Owner gets a timestamped, unread notification for the reply', /Alli Reed replied/.test(notifText) && await O.p.locator('.notif-list li:not(.read) .unread-dot').count() > 0 && /ago|just now/.test(notifText));
  await O.p.click('[data-readall]');
  await O.p.waitForFunction(() => document.querySelector('[data-badge]').hidden);
  check('Mark all as read clears the unread indicator', true);
  await O.p.keyboard.press('Escape');

  await confirmStatus(A.p, card, 'Mark meeting booked');
  await O.p.waitForFunction(() => !document.querySelector('[data-badge]').hidden);
  let notes = (await j(await ownerApi.get('/api/notifications'))).notifications;
  check('Booked meeting creates a notification', notes.some(n => n.type === 'meeting' && /Alli Reed/.test(n.title)));

  // All statuses available in the manual picker
  const statusOpts = await (async () => {
    await card.getByRole('button', { name: 'Update status' }).click();
    const o = await A.p.$$eval('.modal select[name=status] option', els => els.map(e => e.textContent));
    await A.p.click('.modal [data-x]');
    return o;
  })();
  check('Status picker includes all nine statuses', ['New', 'Assigned', 'Profile opened', 'Connection sent', 'Connected', 'Replied', 'Follow-up due', 'Meeting booked', 'Not a fit'].every(s => statusOpts.includes(s)));

  // Follow-up due in the past -> overdue notification
  const jamika = leads.find(l => l.full_name === 'Jamika Martin');
  await assistApi.post(`/api/leads/${jamika.id}/status`, { data: { status: 'Connected' } });
  await assistApi.post(`/api/leads/${jamika.id}/status`, { data: { status: 'Follow-up due', follow_up_due_at: new Date(Date.now() - 3600e3).toISOString() } });
  await sleep(600);
  notes = (await j(await ownerApi.get('/api/notifications'))).notifications;
  check('Overdue follow-up creates a notification', notes.some(n => n.type === 'overdue' && /Jamika Martin/.test(n.title)));
  await O.p.goto(`${BASE}/#/followups`);
  await O.p.waitForSelector('.st-overdue');
  check('Owner sees leads requiring follow-up, with overdue highlighted', /Jamika Martin/.test(await O.p.textContent('main')));
  const jcard = A.p.locator(`#lead-${jamika.id}`);
  await A.p.click('[data-filter="followups"]');
  await jcard.getByRole('button', { name: 'Log follow-up sent' }).click();
  await A.p.locator('.modal button[type=submit]').click();
  await A.p.waitForSelector('.modal', { state: 'detached' });
  await sleep(500);
  const jam = (await j(await ownerApi.get(`/api/leads/${jamika.id}`))).lead;
  met = await j(await ownerApi.get('/api/metrics'));
  check('Logging a follow-up counts it and clears the due status', met.metrics.followups.today === 1 && jam.status === 'Connected');
  await A.p.click('[data-filter="all"]');

  // Undo
  const lisa = leads.find(l => l.full_name === 'Lisa Guerrera');
  const r1 = await j(await assistApi.post(`/api/leads/${lisa.id}/status`, { data: { status: 'Connection sent' } }));
  let before = (await j(await ownerApi.get('/api/metrics'))).metrics.connections_sent.total;
  await assistApi.post(`/api/activity/${r1.activityId}/undo`);
  let afterUndo = (await j(await ownerApi.get('/api/metrics'))).metrics.connections_sent.total;
  const lisaNow = (await j(await ownerApi.get(`/api/leads/${lisa.id}`))).lead;
  check('Undo restores the previous status and removes it from the counts', afterUndo === before - 1 && lisaNow.status === 'Assigned');

  // ---------------- Targets ----------------
  const users = (await j(await ownerApi.get('/api/users'))).users;
  const assistant = users.find(u => u.role === 'assistant');
  await O.p.goto(`${BASE}/#/team`);
  await O.p.waitForSelector(`form[data-targets="${assistant.id}"]`);
  await O.p.fill(`form[data-targets="${assistant.id}"] input[name=profiles_opened]`, '2');
  await O.p.click(`form[data-targets="${assistant.id}"] button[type=submit]`);
  await A.p.waitForFunction(() => /\/\s*2/.test(document.querySelector('[data-targets] .target .row')?.textContent || ''));
  check('Owner sets targets; the assistant’s progress bar updates live', true);
  const [pop2] = await Promise.all([A.c.waitForEvent('page'), A.p.locator(`#lead-${lisa.id} [data-act="open"]`).click()]);
  await pop2.close();
  await sleep(700);
  notes = (await j(await ownerApi.get('/api/notifications'))).notifications;
  check('Reaching a daily target notifies the owner', notes.some(n => n.type === 'target' && /profiles opened/.test(n.title)));
  const aNotes = (await j(await assistApi.get('/api/notifications'))).notifications;
  check('…and the assistant', aNotes.some(n => n.type === 'target'));

  // ---------------- Assign / reassign ----------------
  const add = await ownerApi.post('/api/users', { data: { display_name: 'Second assistant', username: 'assist2', password: 'Second2026pass' } });
  check('Owner can add another assistant', add.ok());
  const second = (await j(add)).users.find(u => u.username === 'assist2');
  const carla = leads.find(l => l.full_name === 'Carla Oates');
  await O.p.goto(`${BASE}/#/leads`);
  await O.p.waitForSelector(`tr[data-row="${carla.id}"]`);
  await O.p.click(`tr[data-row="${carla.id}"] td.cb`);
  await O.p.selectOption('[data-bulk-to]', String(second.id));
  await O.p.click('[data-bulk-apply]');
  await A.p.waitForFunction((id) => !document.querySelector(`#lead-${id}`), carla.id);
  check('Reassigning a lead removes it from the first assistant’s portal live', true);
  const a2 = await apiCtx(BASE, { u: 'assist2', p: 'Second2026pass' });
  check('…and it appears for the new assistant', (await j(await a2.get('/api/leads'))).leads.some(l => l.id === carla.id));
  check('Assistants can’t see leads assigned to someone else', (await assistApi.get(`/api/leads/${carla.id}`)).status() === 404);

  // Owner edits in the drawer -> assistant sees it live
  await O.p.click(`tr[data-row="${jamika.id}"] td[data-label="Name"]`);
  await O.p.waitForSelector('.drawer [data-dstatus]');
  await O.p.click('.drawer [data-dstatus]');
  await O.p.selectOption('.modal select[name=status]', 'Replied');
  await O.p.click('.modal button[type=submit]');
  await A.p.waitForFunction((id) => document.querySelector(`#lead-${id} .status`)?.textContent === 'Replied', jamika.id);
  check('Owner updates appear in the assistant portal automatically', true);
  await O.p.click('.drawer [data-close]');

  // ---------------- File imports ----------------
  // Assistant: CSV with duplicates and invalid rows
  await A.p.click('[data-act="import"]');
  await A.p.setInputFiles('.modal [data-file]', path.join(FIX, 'new-leads.csv'));
  await A.p.waitForSelector('.modal [data-map]');
  const mapped = await A.p.$$eval('.modal [data-map]', els => els.map(e => e.value));
  check('CSV preview shows suggested column mapping', mapped.includes('linkedin_url') && mapped.includes('full_name') && await A.p.locator('.modal table.data').count() >= 2, mapped.join(','));
  await A.p.click('.modal [data-next]');
  await A.p.waitForSelector('.modal .review-row');
  const counts = await A.p.$$eval('.modal .summary-grid .s b', els => els.map(e => +e.textContent));
  check('Review shows ready, duplicate and needs-correction counts (3 / 2 / 2)', counts[0] === 3 && counts[1] === 2 && counts[2] === 2, counts.join('/'));
  const reviewText = await A.p.textContent('.modal .review-list');
  check('Duplicate LinkedIn URL against the database is detected', /Already in the database as Alli Reed/.test(reviewText));
  check('Duplicate within the file is detected', /appears earlier in this file/.test(reviewText));
  check('Invalid LinkedIn URL is flagged', /company page, not a personal profile/.test(reviewText));
  check('Shared email is flagged', /Shared inbox also used by/.test(reviewText));
  // Fix the company-page row
  const fix = A.p.locator('.modal .review-row.err', { hasText: 'Company Page Person' }).locator('input[data-field="linkedin_url"]');
  await fix.fill('https://www.linkedin.com/in/company-page-person-004');
  await A.p.click('.modal [data-recheck]');
  await A.p.waitForFunction(() => document.querySelectorAll('.modal .summary-grid .s b')[0]?.textContent === '4');
  check('Corrected records can be re-checked and become ready', true);
  await A.p.click('.modal [data-commit]');
  await A.p.waitForSelector('.modal .summary-grid');
  await A.p.waitForFunction(() => /Import summary/.test(document.querySelector('.modal h2')?.textContent || ''));
  const done = await A.p.$$eval('.modal .summary-grid .s b', els => els.map(e => +e.textContent));
  check('Import summary: 4 added, 2 skipped, 1 needs correction', done[0] === 4 && done[1] === 2 && done[2] === 1, done.join('/'));
  await A.p.click('.modal [data-close]');
  await O.p.goto(`${BASE}/#/leads`);
  await O.p.waitForSelector('tr[data-row]');
  await O.p.waitForFunction(() => /Maya Test/.test(document.querySelector('[data-rows]').textContent));
  check('Approved leads appear in the owner portal immediately', true);
  await A.p.waitForFunction(() => [...document.querySelectorAll('.lead-name')].some(e => e.textContent === 'Maya Test'), null, { timeout: 10000 });
  check('…and in the assistant portal, without a refresh', await A.p.locator('.lead', { hasText: 'Maya Test' }).count() === 1);
  notes = (await j(await ownerApi.get('/api/notifications'))).notifications;
  check('Finished import notifies the owner', notes.some(n => n.type === 'import' && /new-leads\.csv/.test(n.title)));
  const maya = (await j(await ownerApi.get('/api/leads'))).leads.find(l => l.full_name === 'Maya Test');
  check('Imported lead gets a suggested fit from the brief', maya.fit === 'Primary fit' && maya.fit_basis === 'suggested');

  // Owner: Excel with title rows, first/last name and a second sheet
  await O.p.click('[data-act="import"]');
  await O.p.setInputFiles('.modal [data-file]', path.join(FIX, 'more-leads.xlsx'));
  await O.p.waitForSelector('.modal [data-map]');
  check('Excel header row is detected below title rows', (await O.p.$eval('.modal [data-header]', e => e.value)) === '3');
  await O.p.click('.modal [data-next]');
  await O.p.waitForSelector('.modal .review-row');
  await O.p.click('.modal [data-commit]');
  await O.p.waitForFunction(() => /Import summary/.test(document.querySelector('.modal h2')?.textContent || ''));
  await O.p.click('.modal [data-close]');
  const all = (await j(await ownerApi.get('/api/leads'))).leads;
  const hana = all.find(l => l.full_name === 'Hana Sheet');
  check('Excel import combines first and last names and keeps the file’s fit', hana && hana.fit === 'Secondary fit');

  // Owner: Word document requires review
  await O.p.click('[data-act="import"]');
  await O.p.setInputFiles('.modal [data-file]', path.join(FIX, 'event-notes.docx'));
  await O.p.waitForSelector('.modal .review-row');
  const wordRows = await O.p.locator('.modal .review-row').count();
  check('Word file: possible leads extracted for review (2)', wordRows === 2, String(wordRows));
  check('Word file: nothing is approved until reviewed', await O.p.locator('.modal [data-commit]').isDisabled());
  const grace = await O.p.locator('.modal .review-row', { hasText: 'Grace Wordsworth' }).count();
  check('Word file: names, titles and emails extracted', grace === 1 && /grace@wordskin\.example/.test(await O.p.textContent('.modal .review-list') + (await O.p.$$eval('.modal input[data-field="business_email"]', e => e.map(x => x.value).join(' ')))));
  await O.p.click('.modal [data-all]');
  await O.p.click('.modal [data-commit]');
  await O.p.waitForFunction(() => /Import summary/.test(document.querySelector('.modal h2')?.textContent || ''));
  await O.p.click('.modal [data-close]');

  // PDF
  await O.p.click('[data-act="import"]');
  await O.p.setInputFiles('.modal [data-file]', path.join(FIX, 'research.pdf'));
  await O.p.waitForSelector('.modal .review-row');
  const pdfRows = await O.p.locator('.modal .review-row').count();
  check('PDF file: possible leads extracted for review (2)', pdfRows === 2, String(pdfRows));
  await O.p.locator('.modal [data-inc]').first().check();
  await O.p.click('.modal [data-commit]');
  await O.p.waitForFunction(() => /Import summary/.test(document.querySelector('.modal h2')?.textContent || ''));
  const pdfDone = await O.p.$$eval('.modal .summary-grid .s b', els => els.map(e => +e.textContent));
  check('PDF file: only approved records are added', pdfDone[0] === 1 && pdfDone[1] === 1, pdfDone.join('/'));
  await O.p.click('.modal [data-close]');

  // Unsupported files
  await O.p.click('[data-act="import"]');
  await O.p.setInputFiles('.modal [data-file]', path.join(FIX, 'picture.png'));
  await O.p.waitForFunction(() => /isn’t supported/.test(document.querySelector('.modal [data-err]')?.textContent || ''));
  check('Unsupported file type shows a clear error', true);
  await O.p.setInputFiles('.modal [data-file]', path.join(FIX, 'legacy.xls'));
  await O.p.waitForFunction(() => /\.xls files aren’t supported/.test(document.querySelector('.modal [data-err]')?.textContent || ''));
  check('Old .xls file shows a clear error', true);
  await O.p.keyboard.press('Escape');

  // Re-import same CSV: everything is a duplicate
  const reup = await ownerApi.post('/api/imports', { multipart: { file: { name: 'new-leads.csv', mimeType: 'text/csv', buffer: fs.readFileSync(path.join(FIX, 'new-leads.csv')) } } });
  const reId = (await j(reup)).import.id;
  const reVal = await j(await ownerApi.post(`/api/imports/${reId}/validate`, { data: { sheet: 0 } }));
  check('Uploading the same file again finds the duplicates', reVal.counts.duplicate >= 5, JSON.stringify(reVal.counts));

  // ---------------- Charts ----------------
  await O.p.goto(`${BASE}/#/overview`);
  await O.p.waitForSelector('.chart svg');
  const nCharts = await O.p.locator('.chart').count();
  const todayLabel = await O.p.locator('.chart').first().locator('rect.hit').last().getAttribute('aria-label');
  check('Six separate trend charts, one per metric', nCharts === 6);
  check('Daily chart shows today’s profile opens', /: 2$/.test(todayLabel), todayLabel);
  await O.p.locator('.chart').first().locator('rect.hit').last().hover();
  check('Hovering a bar shows a tooltip', await O.p.locator('#tooltip:not([hidden])').count() === 1);
  await O.p.click('[data-trend="weekly"]');
  check('Weekly trend view works', /Week of/.test(await O.p.locator('.chart').first().locator('rect.hit').last().getAttribute('aria-label')));
  await O.p.click('[data-toggle-table]');
  check('Table view of the trends works', await O.p.locator('section table.data').count() === 1);

  // ---------------- Mobile ----------------
  for (const [who, creds] of [['assistant', ASSIST], ['owner', OWNER]]) {
    const M = await mk(creds, { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
    await M.p.waitForSelector(who === 'owner' ? '.metric-card' : '.lead');
    const sw = await M.p.evaluate(() => document.documentElement.scrollWidth);
    check(`Mobile ${who} portal fits a 390px screen`, sw <= 390, String(sw));
    if (who === 'owner') { await M.p.goto(`${BASE}/#/leads`); await M.p.waitForSelector('tr[data-row]'); check('Mobile owner lead list fits the screen', await M.p.evaluate(() => document.documentElement.scrollWidth) <= 390); }
    await M.c.close();
  }

  // ---------------- Credentials ----------------
  await O.p.goto(`${BASE}/#/settings`);
  const credForm = O.p.locator(`form[data-cred="${assistant.id}"]`);
  await credForm.waitFor();
  await credForm.locator('[name=password]').fill('NewAssist2026!x');
  await credForm.locator('[name=confirm]').fill('NewAssist2026!x');
  await credForm.locator('[name=current_password]').fill('wrong');
  await credForm.locator('button[type=submit]').click();
  await O.p.waitForFunction((id) => /current password is incorrect/.test(document.querySelector(`form[data-cred="${id}"] [data-err]`).textContent), assistant.id);
  check('Changing credentials requires the owner’s current password', true);
  await credForm.locator('[name=current_password]').fill(OWNER.p);
  await credForm.locator('button[type=submit]').click();
  await A.p.waitForSelector('input[name=username]', { timeout: 8000 });
  check('Changing the assistant password signs the assistant out', true);
  const oldTry = await anon.post('/api/auth/login', { data: { username: ASSIST.u, password: ASSIST.p } });
  const newTry = await anon.post('/api/auth/login', { data: { username: ASSIST.u, password: 'NewAssist2026!x' } });
  check('Old assistant password no longer works; new one does', oldTry.status() === 401 && newTry.ok());
  const ownerForm = O.p.locator('form[data-cred="1"]');
  await ownerForm.locator('[name=username]').fill('HELLOGRACIELA');
  await ownerForm.locator('[name=password]').fill('OwnerNew2026!x');
  await ownerForm.locator('[name=confirm]').fill('OwnerNew2026!x');
  await ownerForm.locator('[name=current_password]').fill(OWNER.p);
  await ownerForm.locator('button[type=submit]').click();
  await sleep(800);
  const ownerNew = await anon.post('/api/auth/login', { data: { username: OWNER.u, password: 'OwnerNew2026!x' } });
  check('Owner can change the owner password', ownerNew.ok());
  check('Initial-password banner disappears once both are changed', await O.p.locator('.banner').count() === 0);

  check('No script errors in the assistant portal', A.p.errors.length === 0, A.p.errors.join(' | '));
  check('No script errors in the owner portal', O.p.errors.length === 0, O.p.errors.join(' | '));

  // ---------------- Production gate ----------------
  const PPORT = PORT + 600;
  const prod = startServer({ NODE_ENV: 'production', SKIP_SEED_IMPORT: 'true', DATABASE_URL: '' }, PPORT);
  try {
    await waitUp(`http://localhost:${PPORT}`);
    const po = await apiCtx(`http://localhost:${PPORT}`, OWNER);
    const pa = await apiCtx(`http://localhost:${PPORT}`, ASSIST);
    const blockedO = await po.get('/api/leads');
    const blockedA = await pa.get('/api/leads');
    check('Production: work is blocked until initial passwords are changed', blockedO.status() === 403 && blockedA.status() === 403 && (await j(blockedO)).code === 'setup_required');
    await po.put('/api/users/1/credentials', { data: { current_password: OWNER.p, password: 'ProdOwner2026!x' } });
    await po.put('/api/users/2/credentials', { data: { current_password: 'ProdOwner2026!x', password: 'ProdAssist2026!x' } });
    const pa2 = await apiCtx(`http://localhost:${PPORT}`, { u: ASSIST.u, p: 'ProdAssist2026!x' });
    check('Production: access opens once both passwords are changed', (await po.get('/api/leads')).ok() && (await pa2.get('/api/leads')).ok());
  } finally { prod.proc.kill(); }
} catch (e) {
  console.error(e);
  check('Test run completed without crashing', false, e.message);
  console.log(server.log().slice(-2000));
} finally {
  await browser?.close();
  server.proc.kill();
}

const failed = results.filter(r => !r.ok);
console.log(`\n${results.length - failed.length} of ${results.length} checks passed.`);
fs.writeFileSync(path.join(os.tmpdir(), 'obsidia-e2e-results.json'), JSON.stringify(results, null, 2));
process.exit(failed.length ? 1 : 0);
