// The Obsidia API as an Express app. Used by api/index.js on Vercel and server/index.js locally.
import express from 'express';
import multer from 'multer';
import path from 'node:path';
import { get, all, run, now, tx, getSetting, setSetting } from './db.js';
import {
  COOKIE, checkCredentials, createSession, destroySession, destroyUserSessions, sessionUser, parseCookies,
  tooManyAttempts, recordFailure, clearFailures, publicUser, hashPassword, verifyPassword,
  validatePassword, validateUsername,
} from './auth.js';
import {
  broadcast, changesSince, serializeLead, getLead, canAccessLead, leadActivity, setStatus,
  recordProfileOpen, recordFollowupSent, undoActivity, assignLeads, metricsSummary, targetsFor, defaultTargets,
  checkOverdue, userNames, logActivity, httpError, timezone,
} from './services.js';
import { STATUSES, FITS, PRIORITIES, METRICS, DEFAULT_TEMPLATES, DEFAULT_TARGETS, renderTemplate, parseLinkedIn, EMAIL_RE } from './domain.js';
import {
  FIELDS, suggestMapping, parseFile, UnsupportedFileError, createImport, recordsForImport, validateRecords, commitImport, applyReview,
} from './importer.js';
import { ensureSetup } from './seed.js';

const PROD = process.env.NODE_ENV === 'production';
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 4); // Vercel limits request bodies to 4.5 MB
const FIELD_LIST = FIELDS.map(({ key, label }) => ({ key, label }));

export const app = express();
app.disable('x-powered-by');
if (process.env.VERCEL || process.env.TRUST_PROXY) app.set('trust proxy', process.env.TRUST_PROXY && process.env.TRUST_PROXY !== 'true' ? process.env.TRUST_PROXY : 1);

// Security headers (vercel.json sets the same ones for static files)
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com", "img-src 'self' data:", "connect-src 'self'",
    "frame-ancestors 'none'", "base-uri 'self'", "form-action 'self'",
  ].join('; '));
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (req.path.startsWith('/api')) res.setHeader('Cache-Control', 'no-store');
  if (PROD) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use('/api', express.json({ limit: '4mb' }));

// Database, first-run setup and session on every API call
app.use('/api', async (req, res, next) => {
  await ensureSetup();
  const token = parseCookies(req.headers.cookie)[COOKIE];
  req.token = token;
  req.user = await sessionUser(token);
  next();
});
// CSRF defence: state-changing API calls must come from our own scripts.
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('X-Obsidia') !== '1') return res.status(403).json({ error: 'Request blocked.' });
  next();
});

const setupRequired = (u) => PROD && !!u.must_change;
const anyOwnerNeedsSetup = async () => !!(await get("SELECT 1 AS x FROM users WHERE role = 'owner' AND must_change = 1 AND active = 1"));
const isBlocked = async (u) => setupRequired(u) || (PROD && u.role === 'assistant' && await anyOwnerNeedsSetup());

async function requireUser(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
  if (await isBlocked(req.user)) {
    return res.status(403).json({ error: req.user.role === 'owner' ? 'Update the initial credentials to continue.' : 'Access opens once the owner finishes account setup.', code: 'setup_required' });
  }
  next();
}
function requireOwner(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
  if (req.user.role !== 'owner') return res.status(403).json({ error: 'Only the owner can do that.' });
  next();
}
function setCookie(res, token, expires) {
  res.setHeader('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; ${PROD ? 'Secure; ' : ''}Expires=${new Date(expires).toUTCString()}`);
}

// ---------------- Auth ----------------
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  const ip = req.ip || 'unknown';
  const keys = [`ip:${ip}`, `u:${String(username || '').toLowerCase()}`];
  if (await tooManyAttempts(keys)) return res.status(429).json({ error: 'Too many sign-in attempts. Please wait 15 minutes and try again.' });
  const user = await checkCredentials(username, password);
  if (!user) {
    await recordFailure(keys);
    return res.status(401).json({ error: 'That username and password combination didn’t work. Please try again.' });
  }
  await clearFailures(keys);
  const { token, expires } = await createSession(user.id);
  setCookie(res, token, expires);
  res.json({ user: publicUser(user) });
});

app.post('/api/auth/logout', async (req, res) => {
  await destroySession(req.token);
  res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
  res.json({ ok: true });
});

app.get('/api/me', async (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
  const initialInUse = await all('SELECT username, role FROM users WHERE must_change = 1 AND active = 1');
  res.json({
    user: publicUser(req.user),
    production: PROD,
    setup_required: await isBlocked(req.user),
    initial_credentials_in_use: req.user.role === 'owner' ? initialInUse.map(u => u.role) : undefined,
    timezone: await timezone(),
    constants: { statuses: STATUSES, fits: FITS, priorities: PRIORITIES, metrics: METRICS },
  });
});

// ---------------- Live updates (polled) ----------------
app.get('/api/changes', requireUser, async (req, res) => {
  await checkOverdue(); // runs at most once a minute across all instances
  const after = req.query.after === undefined ? null : Number(req.query.after);
  res.json(await changesSince(after));
});

// ---------------- Leads ----------------
async function visibleLeads(user) {
  const rows = user.role === 'owner'
    ? await all('SELECT * FROM leads ORDER BY id')
    : await all('SELECT * FROM leads WHERE assigned_to = ? ORDER BY id', [user.id]);
  const names = await userNames();
  return rows.map(r => serializeLead(r, names));
}

app.get('/api/leads', requireUser, async (req, res) => res.json({ leads: await visibleLeads(req.user) }));

app.get('/api/leads/:id', requireUser, async (req, res) => {
  const lead = await getLead(Number(req.params.id));
  if (!canAccessLead(req.user, lead)) return res.status(404).json({ error: 'Lead not found.' });
  res.json({ lead: serializeLead(lead, await userNames()), activity: await leadActivity(lead.id) });
});

const ASSISTANT_EDITABLE = ['connection_note', 'followup_note', 'qualification_notes', 'company_size', 'business_email', 'email_source', 'fit'];
const OWNER_EDITABLE = [...ASSISTANT_EDITABLE, 'full_name', 'title', 'linkedin_url', 'company', 'website', 'city', 'country', 'market',
  'brand_category', 'priority', 'email_type', 'fit_rationale', 'verification_notes'];

app.patch('/api/leads/:id', requireUser, async (req, res) => {
  const lead = await getLead(Number(req.params.id));
  if (!canAccessLead(req.user, lead)) return res.status(404).json({ error: 'Lead not found.' });
  const allowed = req.user.role === 'owner' ? OWNER_EDITABLE : ASSISTANT_EDITABLE;
  const body = req.body || {};
  const changes = {};
  for (const k of Object.keys(body)) {
    if (!allowed.includes(k)) continue;
    let v = body[k] === null ? null : String(body[k]).trim().slice(0, 5000);
    if (v === '') v = null;
    if (k === 'fit' && v && !FITS.includes(v)) return res.status(400).json({ error: 'Choose a valid fit classification.' });
    if (k === 'priority' && v && !PRIORITIES.includes(v)) return res.status(400).json({ error: 'Choose a valid priority.' });
    if (k === 'business_email' && v && !EMAIL_RE.test(v)) return res.status(400).json({ error: 'That email address doesn’t look right.' });
    if (k === 'full_name' && !v) return res.status(400).json({ error: 'Name is required.' });
    if (k === 'linkedin_url') {
      const li = parseLinkedIn(v);
      if (!li.ok) return res.status(400).json({ error: li.error });
      const clash = await get('SELECT full_name FROM leads WHERE linkedin_key = ? AND id <> ?', [li.key, lead.id]);
      if (clash) return res.status(409).json({ error: `That LinkedIn profile already belongs to ${clash.full_name}.` });
      v = li.url;
      if (li.key !== lead.linkedin_key) changes.linkedin_key = li.key;
    }
    if (k === 'website' && v && !/^https?:\/\//i.test(v)) v = `https://${v}`;
    if ((lead[k] ?? null) !== v) changes[k] = v;
  }
  const keys = Object.keys(changes);
  if (!keys.length) return res.json({ lead: serializeLead(lead, await userNames()) });
  if (changes.fit !== undefined) changes.fit_basis = 'manual';
  if (changes.business_email !== undefined || changes.city !== undefined || changes.country !== undefined) {
    const gaps = lead.gaps ? JSON.parse(lead.gaps) : {};
    for (const k of ['business_email', 'city', 'country']) if (changes[k]) delete gaps[k];
    changes.gaps = JSON.stringify(gaps);
  }
  const t = now();
  await tx(async () => {
    const sets = Object.keys(changes).map(k => `${k} = ?`).join(', ');
    await run(`UPDATE leads SET ${sets}, updated_at = ? WHERE id = ?`, [...Object.values(changes), t, lead.id]);
    const fields = keys.filter(k => !['linkedin_key', 'gaps', 'fit_basis'].includes(k));
    const noteOnly = fields.every(k => ['connection_note', 'followup_note'].includes(k));
    await logActivity(lead.id, req.user.id, noteOnly ? 'note_edited' : 'edited', { detail: { fields } });
  });
  await broadcast('leads', 'activity');
  res.json({ lead: serializeLead(await getLead(lead.id), await userNames()) });
});

app.delete('/api/leads/:id', requireOwner, requireUser, async (req, res) => {
  const lead = await getLead(Number(req.params.id));
  if (!lead) return res.status(404).json({ error: 'Lead not found.' });
  await run('DELETE FROM leads WHERE id = ?', [lead.id]);
  await broadcast('leads', 'activity', 'metrics');
  res.json({ ok: true });
});

app.post('/api/leads/:id/open', requireUser, async (req, res) => {
  res.json(await recordProfileOpen(Number(req.params.id), req.user));
});
app.post('/api/leads/:id/status', requireUser, async (req, res) => {
  const { status, follow_up_due_at, meeting_at, reason } = req.body || {};
  res.json(await setStatus(Number(req.params.id), status, req.user, { follow_up_due_at, meeting_at, reason }));
});
app.post('/api/leads/:id/followup-sent', requireUser, async (req, res) => {
  res.json(await recordFollowupSent(Number(req.params.id), req.user, { next_due_at: req.body?.next_due_at }));
});
app.post('/api/leads/:id/copied', requireUser, async (req, res) => {
  const lead = await getLead(Number(req.params.id));
  if (!canAccessLead(req.user, lead)) return res.status(404).json({ error: 'Lead not found.' });
  const kind = req.body?.kind === 'followup' ? 'followup' : 'connection';
  await logActivity(lead.id, req.user.id, 'note_copied', { detail: { kind } });
  await broadcast('activity');
  res.json({ ok: true });
});
app.post('/api/leads/:id/reset-note', requireUser, async (req, res) => {
  const lead = await getLead(Number(req.params.id));
  if (!canAccessLead(req.user, lead)) return res.status(404).json({ error: 'Lead not found.' });
  const kind = req.body?.kind === 'followup' ? 'followup' : 'connection';
  const templates = { ...DEFAULT_TEMPLATES, ...(await getSetting('templates', {})) };
  res.json({ text: renderTemplate(templates[kind], lead) });
});
app.post('/api/activity/:id/undo', requireUser, async (req, res) => {
  await undoActivity(Number(req.params.id), req.user);
  res.json({ ok: true });
});
app.post('/api/leads/assign', requireOwner, requireUser, async (req, res) => {
  const ids = (req.body?.ids || []).map(Number).filter(Boolean);
  if (!ids.length) return res.status(400).json({ error: 'Select at least one lead.' });
  const changed = await assignLeads(ids, req.body.assistant_id ? Number(req.body.assistant_id) : null, req.user);
  res.json({ changed });
});

// ---------------- Activity & metrics ----------------
app.get('/api/activity', requireOwner, requireUser, async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 60, 300);
  const names = await userNames();
  const rows = await all(`SELECT a.*, l.full_name AS lead_name, l.company AS lead_company FROM activity a
    LEFT JOIN leads l ON l.id = a.lead_id ORDER BY a.created_at DESC, a.id DESC LIMIT ?`, [limit]);
  res.json({ activity: rows.map(a => ({ ...a, detail: a.detail ? JSON.parse(a.detail) : null, user_name: names[a.user_id] || 'System' })) });
});

app.get('/api/metrics', requireOwner, requireUser, async (req, res) => {
  const userId = req.query.assistant ? Number(req.query.assistant) : null;
  res.json(await metricsSummary({ userId }));
});

// Assistants only see their own progress for today.
app.get('/api/my-progress', requireUser, async (req, res) => {
  const s = await metricsSummary({ userId: req.user.id, days: 1, weeks: 1 });
  const targets = req.user.role === 'assistant' ? targetsFor(req.user, await defaultTargets()) : s.targets;
  res.json({
    today: s.today, timezone: s.timezone,
    metrics: METRICS.map(m => ({ key: m.key, label: m.label, today: s.metrics[m.key].today, target: Number(targets[m.key]) || 0 })),
  });
});

// ---------------- Notifications ----------------
app.get('/api/notifications', requireUser, async (req, res) => {
  const rows = await all('SELECT * FROM notifications WHERE recipient_id = ? ORDER BY created_at DESC, id DESC LIMIT 100', [req.user.id]);
  const unread = (await get('SELECT COUNT(*)::int AS n FROM notifications WHERE recipient_id = ? AND read_at IS NULL', [req.user.id])).n;
  res.json({ notifications: rows, unread });
});
app.post('/api/notifications/read', requireUser, async (req, res) => {
  const t = now();
  if (req.body?.all) await run('UPDATE notifications SET read_at = ? WHERE recipient_id = ? AND read_at IS NULL', [t, req.user.id]);
  else for (const id of (req.body?.ids || []).map(Number)) await run('UPDATE notifications SET read_at = ? WHERE id = ? AND recipient_id = ? AND read_at IS NULL', [t, id, req.user.id]);
  await broadcast('notifications');
  res.json({ ok: true });
});

// ---------------- Users, targets, credentials (owner only) ----------------
async function usersPayload() {
  const counts = Object.fromEntries((await all('SELECT assigned_to, COUNT(*)::int AS n FROM leads WHERE assigned_to IS NOT NULL GROUP BY assigned_to')).map(r => [r.assigned_to, r.n]));
  const defaults = await defaultTargets();
  return (await all('SELECT * FROM users ORDER BY role DESC, id')).map(u => ({
    ...publicUser(u), targets: u.role === 'assistant' ? targetsFor(u, defaults) : null, lead_count: counts[u.id] || 0,
    password_changed_at: u.password_changed_at,
  }));
}
// Assistants only get their own account back.
app.get('/api/users', async (req, res, next) => {
  if (req.user?.role === 'owner') return res.json({ users: await usersPayload() }); // allowed during setup
  await requireUser(req, res, () => res.json({ users: [publicUser(req.user)] }));
});
app.post('/api/users', requireOwner, requireUser, async (req, res) => {
  const { username, display_name, password } = req.body || {};
  const e = validateUsername(username) || validatePassword(password);
  if (e) return res.status(400).json({ error: e });
  if (!display_name || !String(display_name).trim()) return res.status(400).json({ error: 'Add a display name.' });
  if (await get('SELECT 1 AS x FROM users WHERE lower(username) = lower(?)', [username.trim()])) return res.status(409).json({ error: 'That username is already taken.' });
  await run(`INSERT INTO users (username, display_name, role, password_hash, must_change, created_at, password_changed_at)
    VALUES (?, ?, 'assistant', ?, 0, ?, ?)`, [username.trim(), String(display_name).trim().slice(0, 60), hashPassword(password), now(), now()]);
  await broadcast('users', 'metrics');
  res.json({ users: await usersPayload() });
});
app.put('/api/users/:id', requireOwner, requireUser, async (req, res) => {
  const u = await get('SELECT * FROM users WHERE id = ?', [Number(req.params.id)]);
  if (!u) return res.status(404).json({ error: 'User not found.' });
  const { display_name, active, targets } = req.body || {};
  if (targets && u.role === 'assistant') {
    const clean = {};
    for (const m of METRICS) {
      const n = Number(targets[m.key]);
      if (!Number.isFinite(n) || n < 0 || n > 10000) return res.status(400).json({ error: `Enter a target between 0 and 10,000 for ${m.label.toLowerCase()}.` });
      clean[m.key] = Math.round(n);
    }
    await run('UPDATE users SET targets = ? WHERE id = ?', [JSON.stringify(clean), u.id]);
  }
  if (display_name !== undefined) {
    if (!String(display_name).trim()) return res.status(400).json({ error: 'Add a display name.' });
    await run('UPDATE users SET display_name = ? WHERE id = ?', [String(display_name).trim().slice(0, 60), u.id]);
  }
  if (active !== undefined && u.role === 'assistant') {
    await run('UPDATE users SET active = ? WHERE id = ?', [active ? 1 : 0, u.id]);
    if (!active) await destroyUserSessions(u.id);
  }
  await broadcast('users', 'metrics', 'leads');
  res.json({ users: await usersPayload() });
});

// Change any account's username/password. Requires the owner's current password.
app.put('/api/users/:id/credentials', requireOwner, async (req, res) => {
  const target = await get('SELECT * FROM users WHERE id = ?', [Number(req.params.id)]);
  if (!target) return res.status(404).json({ error: 'User not found.' });
  const { current_password, username, password } = req.body || {};
  if (!verifyPassword(String(current_password || ''), req.user.password_hash)) {
    return res.status(403).json({ error: 'Your current password is incorrect.' });
  }
  const updates = {};
  if (username !== undefined && username.trim() !== target.username) {
    const e = validateUsername(username); if (e) return res.status(400).json({ error: e });
    if (await get('SELECT 1 AS x FROM users WHERE lower(username) = lower(?) AND id <> ?', [username.trim(), target.id])) return res.status(409).json({ error: 'That username is already taken.' });
    updates.username = username.trim();
  }
  if (password) {
    const e = validatePassword(password); if (e) return res.status(400).json({ error: e });
    if (verifyPassword(password, target.password_hash)) return res.status(400).json({ error: 'Choose a password that’s different from the current one.' });
    updates.password_hash = hashPassword(password);
    updates.must_change = 0;
    updates.password_changed_at = now();
  }
  if (!Object.keys(updates).length) return res.status(400).json({ error: 'Nothing to update.' });
  const sets = Object.keys(updates).map(k => `${k} = ?`).join(', ');
  await run(`UPDATE users SET ${sets} WHERE id = ?`, [...Object.values(updates), target.id]);
  // Changing a password signs that account out everywhere else.
  if (updates.password_hash) await destroyUserSessions(target.id, target.id === req.user.id ? req.token : null);
  await broadcast('users');
  res.json({ users: await usersPayload() });
});

// ---------------- Settings (owner only) ----------------
app.get('/api/settings', requireOwner, requireUser, async (req, res) => {
  res.json({
    timezone: await timezone(),
    templates: { ...DEFAULT_TEMPLATES, ...(await getSetting('templates', {})) },
    default_templates: DEFAULT_TEMPLATES,
    default_targets: { ...DEFAULT_TARGETS, ...(await defaultTargets()) },
  });
});
app.put('/api/settings', requireOwner, requireUser, async (req, res) => {
  const { timezone: tz, templates, regenerate_notes } = req.body || {};
  if (tz) {
    try { new Intl.DateTimeFormat('en', { timeZone: tz }); } catch { return res.status(400).json({ error: 'Choose a valid time zone.' }); }
    await setSetting('timezone', tz);
  }
  if (templates) {
    const clean = {};
    for (const k of ['connection', 'followup']) if (typeof templates[k] === 'string' && templates[k].trim()) clean[k] = templates[k].trim().slice(0, 2000);
    await setSetting('templates', clean);
    if (regenerate_notes) {
      // Refresh notes only for leads that haven't been contacted yet.
      const t = { ...DEFAULT_TEMPLATES, ...clean };
      const rows = await all("SELECT * FROM leads WHERE status IN ('New','Assigned','Profile opened')");
      await tx(async () => {
        for (const l of rows) await run('UPDATE leads SET connection_note = ?, followup_note = ?, updated_at = ? WHERE id = ?', [renderTemplate(t.connection, l), renderTemplate(t.followup, l), now(), l.id]);
      });
    }
  }
  await broadcast('settings', 'metrics', 'leads');
  res.json({ ok: true });
});

// ---------------- Imports ----------------
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 } });

// Browsers send UTF-8 file names that the multipart parser may read as Latin-1.
function fixName(n) {
  if (/[^\x00-\xff]/.test(n)) return n;
  const d = Buffer.from(n, 'latin1').toString('utf8');
  return d.includes('\uFFFD') ? n : d;
}

async function importFor(req) {
  const row = await get('SELECT * FROM imports WHERE id = ?', [Number(req.params.id)]);
  if (!row || (req.user.role !== 'owner' && row.user_id !== req.user.id)) throw httpError(404, 'Import not found.');
  return row;
}
function importPayload(row, names) {
  const parsed = row.parsed ? JSON.parse(row.parsed) : null;
  let preview = null;
  if (parsed?.kind === 'table') {
    preview = { kind: 'table', review_required: !!parsed.review_required, sheets: parsed.sheets.map(s => ({ name: s.name, header_row: s.header_row, mapping: s.mapping, row_count: s.rows.length, rows: s.rows.slice(0, 40) })), text_candidates: parsed.text_candidates?.length || 0 };
  } else if (parsed) preview = { kind: 'document', review_required: true, candidates: parsed.candidates };
  return {
    id: row.id, filename: row.filename, file_kind: row.file_kind, status: row.status, created_at: row.created_at,
    completed_at: row.completed_at, user_name: names[row.user_id] || 'Unknown',
    summary: row.summary ? JSON.parse(row.summary) : null, preview,
  };
}

app.post('/api/imports', requireUser, (req, res, next) => {
  upload.single('file')(req, res, async (err) => {
    try {
      if (err) {
        if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: `That file is larger than ${MAX_UPLOAD_MB} MB. Split it into smaller files and try again.` });
        return res.status(400).json({ error: 'The upload didn’t complete. Please try again.' });
      }
      if (!req.file) return res.status(400).json({ error: 'Choose a file to upload.' });
      const original = path.basename(fixName(req.file.originalname)).slice(0, 200);
      let parsed;
      try { parsed = await parseFile(req.file.buffer, original); } catch (e) {
        if (e instanceof UnsupportedFileError) return res.status(400).json({ error: e.message });
        console.error(e);
        return res.status(400).json({ error: 'This file couldn’t be read. Check that it isn’t damaged and try again.' });
      }
      if (parsed.kind === 'document' && !parsed.candidates.length) {
        return res.status(400).json({ error: 'No possible leads were found in this document. Records need at least a LinkedIn profile URL or an email address.' });
      }
      const id = await createImport(req.user, original, parsed.file_kind, parsed);
      await broadcast('imports');
      res.json({ import: importPayload(await get('SELECT * FROM imports WHERE id = ?', [id]), await userNames()), fields: FIELD_LIST });
    } catch (e) { next(e); }
  });
});

app.get('/api/imports', requireUser, async (req, res) => {
  const rows = req.user.role === 'owner'
    ? await all('SELECT * FROM imports ORDER BY created_at DESC LIMIT 50')
    : await all('SELECT * FROM imports WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  const names = await userNames();
  res.json({ imports: rows.map(r => { const p = importPayload({ ...r, parsed: null }, names); delete p.preview; return p; }), fields: FIELD_LIST });
});
app.get('/api/imports/:id', requireUser, async (req, res) => res.json({ import: importPayload(await importFor(req), await userNames()), fields: FIELD_LIST }));

app.post('/api/imports/:id/suggest', requireUser, async (req, res) => {
  const row = await importFor(req);
  const parsed = JSON.parse(row.parsed || 'null');
  const sheet = parsed?.sheets?.[Number(req.body?.sheet) || 0];
  if (!sheet) return res.status(400).json({ error: 'Choose a sheet.' });
  res.json({ mapping: suggestMapping(sheet.rows[Number(req.body?.header_row) || 0] || []) });
});
app.post('/api/imports/:id/validate', requireUser, async (req, res) => {
  const row = await importFor(req);
  const parsed = JSON.parse(row.parsed || 'null');
  const records = applyReview(recordsForImport(row, req.body || {}), req.body || {}, !!parsed?.review_required || parsed?.kind === 'document');
  const results = await validateRecords(records);
  const counts = { total: results.length, ready: 0, duplicate: 0, error: 0, warnings: 0 };
  for (const r of results) { counts[r.state]++; if (r.warnings.length) counts.warnings++; }
  res.json({ results: results.map((r, i) => ({ ...r, raw: stripRaw(records[i]) })), counts });
});
function stripRaw(r) { const o = { ...r }; delete o._extra; delete o._include; return o; }

app.post('/api/imports/:id/commit', requireUser, async (req, res) => {
  const row = await importFor(req);
  if (row.status !== 'preview') return res.status(409).json({ error: 'This import has already been completed or cancelled.' });
  const parsed = JSON.parse(row.parsed || 'null');
  const records = applyReview(recordsForImport(row, req.body || {}), req.body || {}, !!parsed?.review_required || parsed?.kind === 'document');
  let assignTo = null;
  if (req.user.role === 'owner' && req.body?.assign_to) {
    const a = await get("SELECT id FROM users WHERE id = ? AND role = 'assistant' AND active = 1", [Number(req.body.assign_to)]);
    if (!a) return res.status(400).json({ error: 'Choose an active assistant.' });
    assignTo = a.id;
  }
  // Claim the import so a double click can't add the same records twice.
  const claimed = await run("UPDATE imports SET status = 'committing' WHERE id = ? AND status = 'preview'", [row.id]);
  if (!claimed.changes) return res.status(409).json({ error: 'This import is already being added.' });
  try {
    res.json({ summary: await commitImport(row, records, req.user, { assignTo }) });
  } catch (e) {
    await run("UPDATE imports SET status = 'preview' WHERE id = ? AND status = 'committing'", [row.id]);
    throw e;
  }
});
app.post('/api/imports/:id/cancel', requireUser, async (req, res) => {
  const row = await importFor(req);
  if (row.status === 'preview') {
    await run("UPDATE imports SET status = 'cancelled', parsed = NULL, completed_at = ? WHERE id = ?", [now(), row.id]);
    await broadcast('imports');
  }
  res.json({ ok: true });
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// Errors
app.use((err, req, res, next) => {
  const status = err.status || (err.type === 'entity.too.large' ? 413 : 500);
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Something went wrong on our side. Please try again.' : err.message });
});

export default app;
