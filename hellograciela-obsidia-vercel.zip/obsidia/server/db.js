// Postgres storage. On Vercel, DATABASE_URL points at Neon (or any Postgres).
// Locally, with no DATABASE_URL, an embedded Postgres (PGlite) stores data in ./data/pglite.
import { AsyncLocalStorage } from 'node:async_hooks';
import path from 'node:path';

const txStore = new AsyncLocalStorage();
let driver = null; // { query(text, params), transaction(fn) }

const DB_URL = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.DATABASE_URL_UNPOOLED || '';

async function connect() {
  if (DB_URL) {
    const { default: pg } = await import('pg');
    const local = /localhost|127\.0\.0\.1/.test(DB_URL);
    const pool = new pg.Pool({
      connectionString: DB_URL,
      max: Number(process.env.PG_POOL_MAX || 5),
      idleTimeoutMillis: 10_000,
      ssl: local || /sslmode=disable/.test(DB_URL) ? false : { rejectUnauthorized: false },
    });
    return {
      query: (text, params) => pool.query(text, params),
      async transaction(fn) {
        const client = await pool.connect();
        try {
          await client.query('BEGIN');
          const r = await fn((t, p) => client.query(t, p));
          await client.query('COMMIT');
          return r;
        } catch (e) {
          await client.query('ROLLBACK').catch(() => {});
          throw e;
        } finally { client.release(); }
      },
    };
  }
  if (process.env.VERCEL) throw new Error('DATABASE_URL is not set. Add a Postgres database (for example Neon) to this Vercel project.');
  const { PGlite } = await import('@electric-sql/pglite');
  const dir = process.env.PGLITE_DIR || path.resolve(process.env.DATA_DIR || 'data', 'pglite');
  const pgl = new PGlite(dir);
  await pgl.waitReady;
  return {
    query: (text, params) => pgl.query(text, params),
    transaction: (fn) => pgl.transaction(tx => fn((t, p) => tx.query(t, p))),
  };
}

// Converts `?` placeholders to $1, $2… so queries stay readable.
function toPg(sql) {
  let i = 0;
  return sql.replace(/\?/g, () => `$${++i}`);
}

let ready = null;
export function init() {
  if (!ready) ready = (async () => { driver = await connect(); await migrate(); })().catch(e => { ready = null; throw e; });
  return ready;
}

async function raw(sql, params = []) {
  await init();
  const q = txStore.getStore();
  const clean = params.map(v => (v === undefined ? null : v));
  const res = q ? await q(toPg(sql), clean) : await driver.query(toPg(sql), clean);
  return res;
}
export const all = async (sql, params) => (await raw(sql, params)).rows;
export const get = async (sql, params) => (await raw(sql, params)).rows[0];
export async function run(sql, params) {
  const r = await raw(sql, params);
  return { changes: r.rowCount ?? r.affectedRows ?? 0, rows: r.rows };
}
export async function tx(fn) {
  await init();
  if (txStore.getStore()) return fn();
  return driver.transaction(q => txStore.run(q, fn));
}

export const now = () => new Date().toISOString();

export async function getSetting(key, fallback) {
  const row = await get('SELECT value FROM settings WHERE key = ?', [key]);
  return row ? JSON.parse(row.value) : fallback;
}
export async function setSetting(key, value) {
  await run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value', [key, JSON.stringify(value)]);
}

const JSON_COLS = ['sources', 'gaps', 'extra'];
export function hydrateLead(row) {
  if (!row) return row;
  const out = { ...row };
  for (const c of JSON_COLS) out[c] = row[c] ? JSON.parse(row[c]) : (c === 'gaps' ? {} : null);
  return out;
}

async function migrate() {
  const statements = `
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner','assistant')),
  password_hash TEXT NOT NULL,
  must_change INTEGER NOT NULL DEFAULT 1,
  active INTEGER NOT NULL DEFAULT 1,
  targets TEXT,
  created_at TEXT NOT NULL,
  password_changed_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS users_username_lower ON users (lower(username));
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS leads (
  id SERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  title TEXT,
  linkedin_url TEXT NOT NULL,
  linkedin_key TEXT NOT NULL UNIQUE,
  company TEXT, website TEXT, city TEXT, country TEXT, market TEXT, location_basis TEXT,
  brand_category TEXT, fit TEXT, fit_basis TEXT, priority TEXT,
  assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'New',
  status_updated_at TEXT, status_updated_by INTEGER,
  profile_opened_at TEXT, profile_opened_by INTEGER,
  follow_up_due_at TEXT, overdue_notified_at TEXT, meeting_at TEXT,
  connection_note TEXT, followup_note TEXT,
  company_size TEXT, business_email TEXT, email_type TEXT, email_source TEXT,
  qualification_notes TEXT, fit_rationale TEXT, verification_notes TEXT, research_date TEXT,
  sources TEXT, gaps TEXT, extra TEXT,
  import_id INTEGER, created_by INTEGER,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS leads_assigned ON leads(assigned_to);
CREATE INDEX IF NOT EXISTS leads_status ON leads(status);
CREATE TABLE IF NOT EXISTS activity (
  id SERIAL PRIMARY KEY,
  lead_id INTEGER REFERENCES leads(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  type TEXT NOT NULL,
  from_status TEXT, to_status TEXT, detail TEXT,
  voided INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS activity_lead ON activity(lead_id);
CREATE INDEX IF NOT EXISTS activity_created ON activity(created_at);
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL, title TEXT NOT NULL, body TEXT,
  lead_id INTEGER, import_id INTEGER, dedupe_key TEXT,
  created_at TEXT NOT NULL, read_at TEXT,
  UNIQUE (recipient_id, dedupe_key)
);
CREATE TABLE IF NOT EXISTS imports (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  filename TEXT NOT NULL, file_kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'preview',
  parsed TEXT, summary TEXT,
  created_at TEXT NOT NULL, completed_at TEXT
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS changes (id SERIAL PRIMARY KEY, scopes TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS login_failures (key TEXT PRIMARY KEY, first_at BIGINT NOT NULL, count INTEGER NOT NULL);
`;
  // Run each statement separately (works for both drivers). Concurrent cold starts are safe: all are IF NOT EXISTS.
  for (const s of statements.split(';').map(x => x.trim()).filter(Boolean)) {
    try { await driver.query(s, []); } catch (e) { if (!/already exists|duplicate key/i.test(e.message)) throw e; }
  }
}
