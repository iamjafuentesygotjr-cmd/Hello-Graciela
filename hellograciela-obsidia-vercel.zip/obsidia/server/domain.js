// Shared business rules: statuses, metrics, fit classification, outreach notes.

export const STATUSES = [
  'New', 'Assigned', 'Profile opened', 'Connection sent', 'Connected',
  'Replied', 'Follow-up due', 'Meeting booked', 'Not a fit',
];
export const FITS = ['Primary fit', 'Secondary fit', 'Not a fit'];
export const PRIORITIES = ['High', 'Medium', 'Low'];

// Each metric is counted from a distinct, confirmed action. Opening a profile
// or copying a note never counts as a request or message being sent.
export const METRICS = [
  { key: 'profiles_opened', label: 'Profiles opened', short: 'Opened' },
  { key: 'connections_sent', label: 'Connection requests sent', short: 'Requests' },
  { key: 'connections_accepted', label: 'Connections accepted', short: 'Accepted' },
  { key: 'replies', label: 'Replies', short: 'Replies' },
  { key: 'followups', label: 'Follow-ups sent', short: 'Follow-ups' },
  { key: 'meetings', label: 'Meetings booked', short: 'Meetings' },
];
export const STATUS_METRIC = {
  'Connection sent': 'connections_sent',
  'Connected': 'connections_accepted',
  'Replied': 'replies',
  'Meeting booked': 'meetings',
};
export const DEFAULT_TARGETS = {
  profiles_opened: 30, connections_sent: 20, connections_accepted: 8,
  replies: 3, followups: 10, meetings: 1,
};

// ---------- Fit classification (HelloGraciela brief) ----------
// Primary: founder-led DTC skincare, supplement or ingestible beauty brands in the US or Australia.
const CORE_CATEGORY = /(skin|spf|sun ?care|supplement|vitamin|collagen|ingestible|nutri|probiotic|gut|greens|serum|derma)/i;
const ADJACENT_CATEGORY = /(beauty|wellness|cosmetic|hair|body ?care|self[- ]care|clean|makeup|fragrance|personal care|health)/i;
const CORE_MARKET = /(united states|^us$|^usa$|u\.s\.|america|australia|^au$|^aus$)/i;

export function normaliseFit(value) {
  if (!value) return null;
  const v = String(value).toLowerCase();
  if (/not\s*(a\s*)?fit|disqualif|exclude|^no$/.test(v)) return 'Not a fit';
  if (/primary|tier\s*1|^a$|high/.test(v)) return 'Primary fit';
  if (/secondary|tier\s*2|^b$|medium/.test(v)) return 'Secondary fit';
  return null;
}

export function suggestFit(lead) {
  const cat = lead.brand_category || '';
  const market = [lead.country, lead.market].filter(Boolean).join(' ');
  const coreCat = CORE_CATEGORY.test(cat);
  const adjCat = !coreCat && ADJACENT_CATEGORY.test(cat);
  const coreMarket = market.split(/[\/,]/).some(m => CORE_MARKET.test(m.trim()));
  const founder = /(founder|owner|ceo|chief executive)/i.test(lead.title || '');
  if (!cat && !market) return { fit: null, reason: 'Not enough information to classify' };
  if (coreCat && coreMarket) return { fit: 'Primary fit', reason: founder ? 'Core category, US/Australia market, founder-level contact' : 'Core category and US/Australia market' };
  if ((coreCat && !coreMarket) || (adjCat && coreMarket)) return { fit: 'Secondary fit', reason: coreCat ? 'Core category outside the US/Australia focus' : 'Adjacent beauty or wellness category' };
  if (cat && !coreCat && !adjCat) return { fit: 'Not a fit', reason: 'Category is outside skincare, supplements and ingestible beauty' };
  return { fit: null, reason: 'Needs review' };
}

// ---------- Outreach notes ----------
export const DEFAULT_TEMPLATES = {
  connection:
    "Hi {first_name}, I came across {company} and liked your focus on {focus}. I'm with HelloGraciela, a digital studio that helps founder-led {sector} brands explain their products through organic and creator content. I'd be glad to connect.",
  followup:
    "Thanks for connecting, {first_name}. We work with {sector} brands on content that explains ingredients and routines clearly, without the hype. If it's ever useful, I'd be happy to share a few ideas for {company}. No pressure either way.",
};

function categoryPhrases(category = '') {
  const c = category.toLowerCase();
  if (/spf|sun/.test(c)) return { focus: 'sun care education', sector: 'skincare' };
  if (/derma/.test(c)) return { focus: 'dermatologist-informed routines', sector: 'skincare' };
  if (/ingredient/.test(c)) return { focus: 'ingredient-led skincare', sector: 'skincare' };
  if (/supplement|vitamin|functional/.test(c)) return { focus: 'supplement education', sector: 'supplement and wellness' };
  if (/ingestible|collagen/.test(c)) return { focus: 'ingestible beauty', sector: 'ingestible beauty' };
  if (/skin/.test(c)) return { focus: 'thoughtful skincare', sector: 'skincare' };
  return { focus: 'your products', sector: 'beauty and wellness' };
}

export function firstName(fullName = '') {
  return String(fullName).trim().split(/\s+/)[0] || 'there';
}

export function renderTemplate(template, lead) {
  const { focus, sector } = categoryPhrases(lead.brand_category || '');
  const vars = {
    first_name: firstName(lead.full_name),
    full_name: lead.full_name || '',
    company: lead.company || 'your brand',
    title: lead.title || '',
    focus, sector,
  };
  return template.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
}

// ---------- Next action per status ----------
export function nextAction(lead) {
  switch (lead.status) {
    case 'New':
    case 'Assigned': return 'Open the LinkedIn profile and check the fit';
    case 'Profile opened': return 'Send a connection request with the note, then mark it as sent';
    case 'Connection sent': return 'Wait for acceptance, then mark as connected';
    case 'Connected': return 'Send the follow-up message and log it';
    case 'Replied': return 'Reply personally and suggest a short call';
    case 'Follow-up due': return lead.follow_up_due_at ? 'Follow up by the due date' : 'Set a follow-up date';
    case 'Meeting booked': return 'Share call details with the owner';
    case 'Not a fit': return 'No further action';
    default: return '';
  }
}

// ---------- LinkedIn URL validation ----------
const LI_RE = /^(?:https?:\/\/)?(?:([a-z]{2,3})\.)?linkedin\.com\/(in|pub)\/([^\/?#\s]+)\/?(?:[?#].*)?$/i;
export function parseLinkedIn(raw) {
  if (!raw) return { ok: false, error: 'LinkedIn URL is missing' };
  const s = String(raw).trim();
  if (/linkedin\.com\/(company|school|showcase)\//i.test(s)) return { ok: false, error: 'This is a company page, not a personal profile' };
  if (/linkedin\.com\/(sales|talent|recruiter)\//i.test(s)) return { ok: false, error: 'Sales Navigator or Recruiter links need the public /in/ profile URL' };
  const m = s.match(LI_RE);
  if (!m) return { ok: false, error: 'Not a valid LinkedIn profile URL' };
  let slug;
  try { slug = decodeURIComponent(m[3]); } catch { slug = m[3]; }
  const sub = (m[1] || 'www').toLowerCase();
  const url = `https://${sub}.linkedin.com/${m[2].toLowerCase()}/${encodeURIComponent(slug).replace(/%2D/gi, '-')}`;
  return { ok: true, url, key: `${m[2].toLowerCase()}/${slug.toLowerCase()}` };
}

export const EMAIL_RE = /[A-Z0-9._%+'-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;
