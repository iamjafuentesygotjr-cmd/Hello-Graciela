// Local / self-hosted runner: serves the front end and the API from one process.
// On Vercel, api/index.js is used instead and public/ is served by Vercel's CDN.
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { app } from './app.js';
import { ensureSetup } from './seed.js';

const PUBLIC = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const PORT = Number(process.env.PORT || 3000);

const server = express();
server.use(app);
server.use(express.static(PUBLIC, { index: 'index.html', maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));

await ensureSetup();
server.listen(PORT, () => {
  console.log(`HelloGraciela Obsidia running on http://localhost:${PORT} (${process.env.NODE_ENV === 'production' ? 'production' : 'development'} mode, ${process.env.DATABASE_URL ? 'Postgres' : 'local embedded Postgres'})`);
});
