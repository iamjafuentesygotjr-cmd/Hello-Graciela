import crypto from 'node:crypto';
import { get, run, now } from './db.js';

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };
const SESSION_DAYS = 14;
export const COOKIE = 'obs_sid';

export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${hash.toString('base64')}`;
}

export function verifyPassword(password, stored) {
  try {
    const [alg, N, r, p, saltB64, hashB64] = stored.split('$');
    if (alg !== 'scrypt') return false;
    const expected = Buffer.from(hashB64, 'base64');
    const actual = crypto.scryptSync(password, Buffer.from(saltB64, 'base64'), expected.length, { N: +N, r: +r, p: +p });
    return crypto.timingSafeEqual(expected, actual);
  } catch { return false; }
}

// Used when the username doesn't exist so response time doesn't reveal it.
const DUMMY_HASH = hashPassword(crypto.randomBytes(12).toString('hex'));

export async function checkCredentials(username, password) {
  const user = await get('SELECT * FROM users WHERE lower(username) = lower(?) AND active = 1', [String(username || '').trim()]);
  const ok = verifyPassword(String(password || ''), user ? user.password_hash : DUMMY_HASH);
  return ok && user ? user : null;
}

const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

export async function createSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  await run('INSERT INTO sessions (id, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)', [sha(token), userId, now(), expires]);
  await run('DELETE FROM sessions WHERE expires_at < ?', [now()]);
  return { token, expires };
}

export async function destroySession(token) {
  if (token) await run('DELETE FROM sessions WHERE id = ?', [sha(token)]);
}

export async function destroyUserSessions(userId, exceptToken) {
  if (exceptToken) await run('DELETE FROM sessions WHERE user_id = ? AND id <> ?', [userId, sha(exceptToken)]);
  else await run('DELETE FROM sessions WHERE user_id = ?', [userId]);
}

export async function sessionUser(token) {
  if (!token) return null;
  const row = await get(`SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.id = ? AND u.active = 1`, [sha(token)]);
  if (!row) return null;
  if (row.expires_at < now()) { await destroySession(token); return null; }
  return row;
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

// Failed sign-in limiter, stored in the database so it holds across serverless instances.
const WINDOW = 15 * 60 * 1000, MAX = 8;
export async function tooManyAttempts(keys) {
  const t = Date.now();
  for (const k of keys) {
    const f = await get('SELECT first_at, count FROM login_failures WHERE key = ?', [k]);
    if (f && t - Number(f.first_at) <= WINDOW && Number(f.count) >= MAX) return true;
  }
  return false;
}
export async function recordFailure(keys) {
  const t = Date.now();
  for (const k of keys) {
    await run(`INSERT INTO login_failures (key, first_at, count) VALUES (?, ?, 1)
      ON CONFLICT (key) DO UPDATE SET
        count = CASE WHEN ? - login_failures.first_at > ? THEN 1 ELSE login_failures.count + 1 END,
        first_at = CASE WHEN ? - login_failures.first_at > ? THEN ? ELSE login_failures.first_at END`,
    [k, t, t, WINDOW, t, WINDOW, t]);
  }
}
export async function clearFailures(keys) { for (const k of keys) await run('DELETE FROM login_failures WHERE key = ?', [k]); }

export function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id, username: u.username, display_name: u.display_name, role: u.role,
    must_change: !!u.must_change, active: !!u.active,
  };
}

export function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 10) return 'Use at least 10 characters.';
  if (pw.length > 200) return 'That password is too long.';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Include at least one letter and one number.';
  return null;
}
export function validateUsername(name) {
  if (typeof name !== 'string' || !/^[A-Za-z0-9._-]{3,40}$/.test(name.trim())) return 'Usernames are 3–40 characters: letters, numbers, dots, dashes or underscores.';
  return null;
}
