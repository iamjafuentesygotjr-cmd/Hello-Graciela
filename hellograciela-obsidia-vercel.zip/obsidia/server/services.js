import { get, all, run, now, tx, hydrateLead, getSetting, setSetting } from './db.js';
import {
  STATUSES, STATUS_METRIC, METRICS, DEFAULT_TARGETS, nextAction,
} from './domain.js';

// ---------------- Live updates ----------------
// Every change is written to a small "changes" log. Both portals poll it every few seconds,
// which works on serverless hosts where long-lived connections aren't available.
export async function broadcast(...scopes) {
  await run('INSERT INTO changes (scopes, created_at) VALUES (?, ?)', [scopes.join(','), now()]);
}
export async function changesSince(after) {
  const latest = (await get('SELECT COALESCE(MAX(id), 0)::int AS id FROM changes')).id;
  if (after === null || after === undefined || Number.isNaN(after)) return { latest, scopes: [] };
  if (after > latest) return { latest, scopes: ['*'] };
  const rows = await all('SELECT scopes FROM changes WHERE id > ? ORDER BY id LIMIT 500', [after]);
  const scopes = [...new Set(rows.flatMap(r => r.scopes.split(',')))];
  return { latest, scopes };
}

// ---------------- Users ----------------
export const userById = (id) => get('SELECT * FROM users WHERE id = ?', [id]);
export const ownerIds = async () => (await all("SELECT id FROM users WHERE role = 'owner' AND active = 1")).map(r => r.id);
export async function userNames() {
  const m = {};
  for (const u of await all('SELECT id, display_name FROM users')) m[u.id] = u.display_name;
  return m;
}
export function targetsFor(user, defaults = {}) {
  const t = user && user.targets ? JSON.parse(user.targets) : null;
  return { ...DEFAULT_TARGETS, ...defaults, ...(t || {}) };
}
export const defaultTargets = () => getSetting('default_targets', {});

// ---------------- Time helpers ----------------
export const timezone = () => getSetting('timezone', process.env.APP_TIMEZONE || 'Asia/Manila');
export function dayKey(iso, tz) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));
}
function addDays(key, n) {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}
function weekStart(key) {
  const [y, m, d] = key.split('-').map(Number);
  const dow = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return addDays(key, -((dow + 6) % 7));
}
export async function fmtInTz(iso) {
  return new Date(iso).toLocaleString('en-US', { timeZone: await timezone(), dateStyle: 'medium', timeStyle: 'short' });
}

// ---------------- Notifications ----------------
export async function notify(recipients, n) {
  let created = 0;
  for (const r of new Set(recipients.filter(Boolean))) {
    const res = await run(`INSERT INTO notifications (recipient_id, type, title, body, lead_id, import_id, dedupe_key, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT (recipient_id, dedupe_key) DO NOTHING`,
    [r, n.type, n.title, n.body || null, n.lead_id || null, n.import_id || null, n.dedupe_key || null, now()]);
    created += res.changes;
  }
  if (created) await broadcast('notifications');
}

// ---------------- Leads ----------------
export function serializeLead(row, names) {
  const l = hydrateLead(row);
  return {
    ...l,
    assigned_name: l.assigned_to ? names[l.assigned_to] || 'Unknown' : null,
    status_updated_by_name: l.status_updated_by ? names[l.status_updated_by] || 'Unknown' : null,
    profile_opened_by_name: l.profile_opened_by ? names[l.profile_opened_by] || 'Unknown' : null,
    next_action: nextAction(l),
    follow_up_overdue: !!(l.status === 'Follow-up due' && l.follow_up_due_at && l.follow_up_due_at < now()),
  };
}
export const getLead = (id) => get('SELECT * FROM leads WHERE id = ?', [id]);

export function canAccessLead(user, lead) {
  return !!lead && (user.role === 'owner' || lead.assigned_to === user.id);
}

export async function logActivity(leadId, userId, type, { from = null, to = null, detail = null } = {}) {
  const r = await get(`INSERT INTO activity (lead_id, user_id, type, from_status, to_status, detail, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id`, [leadId, userId, type, from, to, detail ? JSON.stringify(detail) : null, now()]);
  return r.id;
}

export async function leadActivity(leadId) {
  const names = await userNames();
  return (await all('SELECT * FROM activity WHERE lead_id = ? ORDER BY created_at DESC, id DESC', [leadId]))
    .map(a => ({ ...a, detail: a.detail ? JSON.parse(a.detail) : null, user_name: names[a.user_id] || 'System' }));
}

function leadLabel(l) { return l.company ? `${l.full_name} (${l.company})` : l.full_name; }

export async function setStatus(leadId, status, user, opts = {}) {
  if (!STATUSES.includes(status)) throw httpError(400, 'Choose a valid status.');
  const lead = await getLead(leadId);
  if (!canAccessLead(user, lead)) throw httpError(404, 'Lead not found.');
  const t = now();
  let due = null, meeting = null;
  if (status === 'Follow-up due') {
    const d = opts.follow_up_due_at ? new Date(opts.follow_up_due_at) : new Date(Date.now() + 3 * 864e5);
    if (isNaN(d)) throw httpError(400, 'Choose a valid follow-up date.');
    due = d.toISOString();
  }
  if (status === 'Meeting booked' && opts.meeting_at) {
    const d = new Date(opts.meeting_at);
    if (isNaN(d)) throw httpError(400, 'Choose a valid meeting date.');
    meeting = d.toISOString();
  }
  if (lead.status === status && status !== 'Follow-up due' && status !== 'Meeting booked') return { activityId: null };
  const activityId = await tx(async () => {
    await run(`UPDATE leads SET status = ?, status_updated_at = ?, status_updated_by = ?,
      follow_up_due_at = ?, overdue_notified_at = NULL,
      meeting_at = CASE WHEN ?::text = 'Meeting booked' THEN COALESCE(?::text, meeting_at) ELSE meeting_at END,
      updated_at = ? WHERE id = ?`, [status, t, user.id, due, status, meeting, t, leadId]);
    return logActivity(leadId, user.id, 'status_change', {
      from: lead.status, to: status,
      detail: { follow_up_due_at: due, meeting_at: meeting, reason: opts.reason || null, prev_due_at: lead.follow_up_due_at },
    });
  });
  if (status === 'Replied') {
    await notify((await ownerIds()).filter(id => id !== user.id), {
      type: 'reply', title: `${lead.full_name} replied`,
      body: `${user.display_name} marked ${leadLabel(lead)} as replied.`, lead_id: leadId,
    });
  }
  if (status === 'Meeting booked') {
    await notify((await ownerIds()).filter(id => id !== user.id), {
      type: 'meeting', title: `Meeting booked with ${lead.full_name}`,
      body: `${user.display_name} booked a meeting with ${leadLabel(lead)}${meeting ? ` for ${await fmtInTz(meeting)}` : ''}.`,
      lead_id: leadId,
    });
  }
  if (STATUS_METRIC[status]) await checkTargets(user, STATUS_METRIC[status]);
  if (due && due < now()) await checkOverdue(true); // a date already in the past is overdue right away
  await broadcast('leads', 'activity', 'metrics');
  return { activityId };
}

export async function recordProfileOpen(leadId, user) {
  const lead = await getLead(leadId);
  if (!canAccessLead(user, lead)) throw httpError(404, 'Lead not found.');
  const t = now();
  const advance = ['New', 'Assigned'].includes(lead.status);
  const to = advance ? 'Profile opened' : lead.status;
  const activityId = await tx(async () => {
    await run(`UPDATE leads SET profile_opened_at = ?, profile_opened_by = ?, updated_at = ?, status = ?,
      status_updated_at = CASE WHEN ?::boolean THEN ?::text ELSE status_updated_at END,
      status_updated_by = CASE WHEN ?::boolean THEN ?::int ELSE status_updated_by END WHERE id = ?`,
    [t, user.id, t, to, advance, t, advance, user.id, leadId]);
    return logActivity(leadId, user.id, 'profile_opened', { from: lead.status, to, detail: { url: lead.linkedin_url } });
  });
  await checkTargets(user, 'profiles_opened');
  await broadcast('leads', 'activity', 'metrics');
  return { activityId, url: lead.linkedin_url, status: to, opened_at: t };
}

export async function recordFollowupSent(leadId, user, { next_due_at } = {}) {
  const lead = await getLead(leadId);
  if (!canAccessLead(user, lead)) throw httpError(404, 'Lead not found.');
  const t = now();
  let to = lead.status, due = null;
  if (next_due_at) {
    const d = new Date(next_due_at);
    if (isNaN(d)) throw httpError(400, 'Choose a valid follow-up date.');
    to = 'Follow-up due'; due = d.toISOString();
  } else if (lead.status === 'Follow-up due') {
    const prev = await get(`SELECT from_status FROM activity WHERE lead_id = ? AND type = 'status_change'
      AND to_status = 'Follow-up due' AND voided = 0 ORDER BY id DESC LIMIT 1`, [leadId]);
    to = prev && prev.from_status && prev.from_status !== 'Follow-up due' ? prev.from_status : 'Connected';
  }
  const activityId = await tx(async () => {
    await run(`UPDATE leads SET status = ?, follow_up_due_at = ?, overdue_notified_at = NULL,
      status_updated_at = ?, status_updated_by = ?, updated_at = ? WHERE id = ?`, [to, due, t, user.id, t, leadId]);
    return logActivity(leadId, user.id, 'followup_sent', {
      from: lead.status, to, detail: { prev_due_at: lead.follow_up_due_at, next_due_at: due },
    });
  });
  await checkTargets(user, 'followups');
  await broadcast('leads', 'activity', 'metrics');
  return { activityId };
}

export async function undoActivity(activityId, user) {
  const a = await get('SELECT * FROM activity WHERE id = ?', [activityId]);
  if (!a || a.voided) throw httpError(404, 'Nothing to undo.');
  const lead = await getLead(a.lead_id);
  if (!canAccessLead(user, lead)) throw httpError(404, 'Nothing to undo.');
  if (!['status_change', 'profile_opened', 'followup_sent'].includes(a.type)) throw httpError(400, 'This update can’t be undone.');
  if (user.role !== 'owner' && (a.user_id !== user.id || Date.now() - Date.parse(a.created_at) > 15 * 60e3)) {
    throw httpError(403, 'Updates can be undone for 15 minutes by the person who made them.');
  }
  if (lead.status !== a.to_status) throw httpError(409, 'This lead has been updated since, so it can’t be undone.');
  const detail = a.detail ? JSON.parse(a.detail) : {};
  const t = now();
  await tx(async () => {
    await run('UPDATE activity SET voided = 1 WHERE id = ?', [a.id]);
    const restoreDue = detail.prev_due_at || null;
    await run(`UPDATE leads SET status = ?, status_updated_at = ?, status_updated_by = ?, updated_at = ?,
      follow_up_due_at = CASE WHEN ?::text = 'Follow-up due' THEN COALESCE(?::text, follow_up_due_at) ELSE NULL END WHERE id = ?`,
    [a.from_status || lead.status, t, user.id, t, a.from_status, restoreDue, lead.id]);
    if (a.type === 'profile_opened') {
      const prev = await get(`SELECT created_at, user_id FROM activity WHERE lead_id = ? AND type = 'profile_opened' AND voided = 0 ORDER BY id DESC LIMIT 1`, [lead.id]);
      await run('UPDATE leads SET profile_opened_at = ?, profile_opened_by = ? WHERE id = ?', [prev?.created_at || null, prev?.user_id || null, lead.id]);
    }
    await logActivity(lead.id, user.id, 'undo', { from: a.to_status, to: a.from_status, detail: { undone_type: a.type, undone_id: a.id } });
  });
  await broadcast('leads', 'activity', 'metrics');
}

export async function assignLeads(ids, assistantId, user) {
  let assignee = null;
  if (assistantId) {
    assignee = await get("SELECT * FROM users WHERE id = ? AND role = 'assistant' AND active = 1", [assistantId]);
    if (!assignee) throw httpError(400, 'Choose an active assistant.');
  }
  const names = await userNames();
  let changed = 0;
  await tx(async () => {
    for (const id of ids) {
      const lead = await getLead(id);
      if (!lead || lead.assigned_to === (assignee?.id ?? null)) continue;
      let status = lead.status;
      if (assignee && status === 'New') status = 'Assigned';
      if (!assignee && status === 'Assigned') status = 'New';
      const t = now();
      const statusChanged = status !== lead.status;
      await run(`UPDATE leads SET assigned_to = ?, status = ?, updated_at = ?,
        status_updated_at = CASE WHEN ?::boolean THEN ?::text ELSE status_updated_at END,
        status_updated_by = CASE WHEN ?::boolean THEN ?::int ELSE status_updated_by END WHERE id = ?`,
      [assignee?.id ?? null, status, t, statusChanged, t, statusChanged, user.id, id]);
      await logActivity(id, user.id, 'assigned', {
        from: lead.status, to: status,
        detail: { from_user: lead.assigned_to ? names[lead.assigned_to] : null, to_user: assignee?.display_name || null },
      });
      changed++;
    }
  });
  if (assignee && changed) {
    await notify([assignee.id], {
      type: 'assigned', title: `${changed} ${changed === 1 ? 'lead' : 'leads'} assigned to you`,
      body: `${user.display_name} added ${changed === 1 ? 'a lead' : `${changed} leads`} to your list.`,
    });
  }
  await broadcast('leads', 'activity', 'metrics');
  return changed;
}

// ---------------- Metrics ----------------
async function metricEvents() {
  const rows = await all(`SELECT lead_id, user_id, type, to_status, created_at FROM activity
    WHERE voided = 0 AND type IN ('profile_opened', 'status_change', 'followup_sent') ORDER BY created_at, id`);
  const seen = new Set();
  const events = [];
  for (const r of rows) {
    const metric = r.type === 'profile_opened' ? 'profiles_opened'
      : r.type === 'followup_sent' ? 'followups' : STATUS_METRIC[r.to_status];
    if (!metric) continue;
    if (metric !== 'followups') {
      // Each lead counts once per milestone, the first time it is confirmed.
      const k = `${metric}:${r.lead_id}`;
      if (seen.has(k)) continue;
      seen.add(k);
    }
    events.push({ metric, user_id: r.user_id, at: r.created_at });
  }
  return events;
}

export async function metricsSummary({ userId = null, days = 14, weeks = 8 } = {}) {
  const tz = await timezone();
  const today = dayKey(now(), tz);
  const events = (await metricEvents()).filter(e => !userId || e.user_id === userId);
  const dayKeys = Array.from({ length: days }, (_, i) => addDays(today, i - days + 1));
  const thisWeek = weekStart(today);
  const weekKeys = Array.from({ length: weeks }, (_, i) => addDays(thisWeek, (i - weeks + 1) * 7));
  const out = {};
  for (const m of METRICS) out[m.key] = { today: 0, total: 0, week: 0, daily: Object.fromEntries(dayKeys.map(k => [k, 0])), weekly: Object.fromEntries(weekKeys.map(k => [k, 0])) };
  for (const e of events) {
    const m = out[e.metric];
    const dk = dayKey(e.at, tz);
    const wk = weekStart(dk);
    m.total++;
    if (dk === today) m.today++;
    if (wk === thisWeek) m.week++;
    if (dk in m.daily) m.daily[dk]++;
    if (wk in m.weekly) m.weekly[wk]++;
  }
  const assistants = await all("SELECT * FROM users WHERE role = 'assistant' AND active = 1");
  const defaults = await defaultTargets();
  const scope = userId ? assistants.filter(a => a.id === userId) : assistants;
  const targets = {};
  for (const m of METRICS) targets[m.key] = scope.reduce((s, a) => s + (Number(targetsFor(a, defaults)[m.key]) || 0), 0);
  return { today, timezone: tz, dayKeys, weekKeys, metrics: out, targets, definitions: METRICS };
}

async function checkTargets(user, metric) {
  if (user.role !== 'assistant') return;
  const target = Number(targetsFor(user, await defaultTargets())[metric]) || 0;
  if (!target) return;
  const s = await metricsSummary({ userId: user.id, days: 1, weeks: 1 });
  const count = s.metrics[metric].today;
  if (count < target) return;
  const def = METRICS.find(m => m.key === metric);
  await notify([...(await ownerIds()), user.id], {
    type: 'target', title: `Daily target reached: ${def.label.toLowerCase()}`,
    body: `${user.display_name} reached ${count} of ${target} ${def.label.toLowerCase()} today.`,
    dedupe_key: `target:${user.id}:${metric}:${s.today}`,
  });
}

// ---------------- Overdue follow-ups ----------------
// Serverless hosts have no background timers, so this runs from regular requests at most once a minute.
export async function checkOverdue(force = false) {
  if (!force) {
    const last = await getSetting('last_overdue_check', 0);
    if (Date.now() - last < 60_000) return;
    await setSetting('last_overdue_check', Date.now());
    await run('DELETE FROM changes WHERE created_at < ?', [new Date(Date.now() - 864e5).toISOString()]);
  }
  const rows = await all(`SELECT * FROM leads WHERE status = 'Follow-up due' AND follow_up_due_at IS NOT NULL
    AND follow_up_due_at < ? AND overdue_notified_at IS NULL`, [now()]);
  for (const l of rows) {
    await run('UPDATE leads SET overdue_notified_at = ? WHERE id = ?', [now(), l.id]);
    await notify([...(await ownerIds()), l.assigned_to], {
      type: 'overdue', title: `Follow-up overdue: ${l.full_name}`,
      body: `The follow-up for ${leadLabel(l)} was due ${await fmtInTz(l.follow_up_due_at)}.`,
      lead_id: l.id, dedupe_key: `overdue:${l.id}:${l.follow_up_due_at}`,
    });
  }
  if (rows.length) await broadcast('leads');
}

export function httpError(status, message, extra) {
  const e = new Error(message);
  e.status = status;
  if (extra) e.extra = extra;
  return e;
}
