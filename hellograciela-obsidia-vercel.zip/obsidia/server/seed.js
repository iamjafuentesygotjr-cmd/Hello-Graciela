// First-run setup: creates the two initial accounts and imports the supplied leads file.
// Safe to call on every cold start: a claim row in settings makes sure it only runs once.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { init, get, run, now } from './db.js';
import { hashPassword } from './auth.js';
import { parseFile, createImport, recordsForImport, applyReview, commitImport } from './importer.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SEED_DIR = process.env.SEED_DIR || path.join(HERE, '..', 'data', 'seed');

let done = null;
export function ensureSetup() {
  if (!done) done = setup().catch(e => { done = null; throw e; });
  return done;
}

async function setup() {
  await init();
  const claim = await get("INSERT INTO settings (key, value) VALUES ('setup_claimed', ?) ON CONFLICT (key) DO NOTHING RETURNING key", [JSON.stringify(now())]);
  if (!claim) {
    // Another instance ran (or is running) setup. Wait briefly until the accounts exist.
    for (let i = 0; i < 40; i++) {
      if ((await get('SELECT COUNT(*)::int AS n FROM users')).n) return;
      await new Promise(r => setTimeout(r, 250));
    }
    return;
  }
  try {
    if (!(await get('SELECT COUNT(*)::int AS n FROM users')).n) {
      // Initial credentials come from the environment when set. They must be changed before production use.
      const accounts = [
        { username: process.env.OWNER_USERNAME || 'HELLOGRACIELA', password: process.env.OWNER_INITIAL_PASSWORD || 'hello2026', role: 'owner', name: 'Owner' },
        { username: process.env.ASSISTANT_USERNAME || 'Helloassist', password: process.env.ASSISTANT_INITIAL_PASSWORD || 'Helloassist2026', role: 'assistant', name: 'Assistant' },
      ];
      for (const a of accounts) {
        await run('INSERT INTO users (username, display_name, role, password_hash, must_change, created_at) VALUES (?, ?, ?, ?, 1, ?)',
          [a.username, a.name, a.role, hashPassword(a.password), now()]);
      }
      console.log('Created the initial owner and assistant accounts. Change their passwords before going live.');
    }
    const counts = await get('SELECT (SELECT COUNT(*) FROM leads)::int AS leads, (SELECT COUNT(*) FROM imports)::int AS imports');
    if (counts.leads || counts.imports || process.env.SKIP_SEED_IMPORT === 'true' || !fs.existsSync(SEED_DIR)) return;
    const owner = await get("SELECT * FROM users WHERE role = 'owner' ORDER BY id LIMIT 1");
    const assistant = await get("SELECT * FROM users WHERE role = 'assistant' ORDER BY id LIMIT 1");
    for (const file of fs.readdirSync(SEED_DIR).filter(f => /\.(xlsx|csv)$/i.test(f))) {
      const parsed = await parseFile(fs.readFileSync(path.join(SEED_DIR, file)), file);
      const id = await createImport(owner, file, parsed.file_kind, parsed);
      const row = await get('SELECT * FROM imports WHERE id = ?', [id]);
      const records = applyReview(recordsForImport(row, { sheet: 0 }), {}, false);
      const summary = await commitImport(row, records, owner, { assignTo: assistant?.id });
      console.log(`Imported ${file}: ${summary.added} added, ${summary.skipped} skipped, ${summary.need_correction} need correction, ${summary.flagged_gaps} flagged for missing details.`);
    }
  } catch (e) {
    // Let a later request retry setup.
    await run("DELETE FROM settings WHERE key = 'setup_claimed'").catch(() => {});
    throw e;
  }
}
