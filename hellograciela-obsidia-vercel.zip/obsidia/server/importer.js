// File parsing, column mapping, validation and duplicate detection for lead imports.
import path from 'node:path';
import ExcelJS from 'exceljs';
import Papa from 'papaparse';
import mammoth from 'mammoth';
import { PDFParse } from 'pdf-parse';
import { all, get, run, now, tx, getSetting } from './db.js';
import {
  parseLinkedIn, normaliseFit, suggestFit, renderTemplate, DEFAULT_TEMPLATES, EMAIL_RE,
} from './domain.js';
import { logActivity, notify, ownerIds, broadcast, httpError } from './services.js';

// ---------------- Field catalogue ----------------
export const FIELDS = [
  { key: 'full_name', label: 'Full name', syn: ['full name', 'name', 'contact name', 'lead name', 'contact', 'person', 'prospect'] },
  { key: 'first_name', label: 'First name', syn: ['first name', 'firstname', 'given name'] },
  { key: 'last_name', label: 'Last name', syn: ['last name', 'lastname', 'surname', 'family name'] },
  { key: 'title', label: 'Position', syn: ['title', 'position', 'job title', 'role', 'current title', 'headline', 'designation', 'job'] },
  { key: 'linkedin_url', label: 'LinkedIn URL', syn: ['linkedin', 'linkedin url', 'linkedin profile', 'profile url', 'li url', 'linkedin profile url'] },
  { key: 'company', label: 'Company', syn: ['company', 'brand', 'company brand', 'organisation', 'organization', 'account', 'business', 'company name'] },
  { key: 'website', label: 'Company website', syn: ['website', 'company website', 'domain', 'site', 'web', 'company url', 'website url'] },
  { key: 'business_email', label: 'Business email', syn: ['email', 'business email', 'work email', 'public business email', 'e mail', 'email address'] },
  { key: 'email_type', label: 'Email type', syn: ['email type'] },
  { key: 'email_source', label: 'Email source', syn: ['email source', 'email source url'] },
  { key: 'city', label: 'City', syn: ['city', 'metro', 'city metro', 'town'] },
  { key: 'country', label: 'Country', syn: ['country'] },
  { key: 'location', label: 'Location (combined)', syn: ['location', 'based in', 'region', 'geography'] },
  { key: 'location_basis', label: 'Location basis', syn: ['location basis'] },
  { key: 'market', label: 'Brand market', syn: ['brand market', 'market', 'markets'] },
  { key: 'brand_category', label: 'Brand category', syn: ['brand category', 'category', 'industry', 'niche', 'vertical', 'segment'] },
  { key: 'fit', label: 'Fit classification', syn: ['fit', 'classification', 'qualification', 'priority', 'tier', 'fit classification'] },
  { key: 'priority', label: 'Priority (high/medium/low)', syn: ['priority level', 'urgency'] },
  { key: 'fit_rationale', label: 'Why the brand fits', syn: ['why the brand fits', 'fit rationale', 'rationale', 'why', 'reason', 'fit reason'] },
  { key: 'qualification_notes', label: 'Qualification notes', syn: ['qualification notes', 'notes', 'comments', 'comment'] },
  { key: 'verification_notes', label: 'Verification notes', syn: ['verification', 'verification gaps', 'gaps', 'research notes'] },
  { key: 'company_size', label: 'Company size', syn: ['company size', 'employees', 'headcount', 'size', 'employee count'] },
  { key: 'research_date', label: 'Research date', syn: ['research date', 'date researched', 'researched'] },
  { key: 'role_source', label: 'Role source URL', syn: ['role source', 'role source url'] },
  { key: 'brand_source', label: 'Brand source URL', syn: ['brand fit source', 'brand source', 'fit source'] },
  { key: 'location_source', label: 'Location source URL', syn: ['location source', 'location source url'] },
  { key: 'connection_note', label: 'Outreach note', syn: ['outreach note', 'connection note', 'message', 'outreach message', 'note'] },
];
const FIELD_KEYS = new Set(FIELDS.map(f => f.key));
const norm = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

function scoreHeader(header) {
  const h = norm(header);
  if (!h) return { key: null, score: 0 };
  let best = { key: null, score: 0 };
  for (const f of FIELDS) {
    for (const syn of f.syn) {
      let s = 0;
      if (h === syn) s = 100 + syn.length;
      else if (new RegExp(`(^| )${syn}( |$)`).test(h)) s = syn.length;
      if (s > best.score) best = { key: f.key, score: s };
    }
  }
  return best;
}

export function suggestMapping(headers) {
  const scored = headers.map((h, i) => ({ i, ...scoreHeader(h) })).sort((a, b) => b.score - a.score);
  const used = new Set();
  const mapping = {};
  for (const s of scored) {
    if (s.key && !used.has(s.key)) { mapping[s.i] = s.key; used.add(s.key); }
  }
  return headers.map((_, i) => mapping[i] || '');
}

function detectHeaderRow(rows) {
  let best = { index: 0, score: -1 };
  rows.slice(0, 25).forEach((r, index) => {
    const filled = r.filter(c => String(c ?? '').trim()).length;
    if (filled < 2) return;
    const matches = r.filter(c => scoreHeader(c).score > 0).length;
    const score = matches * 10 + Math.min(filled, 5);
    if (matches >= 2 && score > best.score) best = { index, score };
  });
  if (best.score < 0) best.index = Math.max(0, rows.findIndex(r => r.filter(c => String(c ?? '').trim()).length >= 2));
  return best.index;
}

// ---------------- Parsing ----------------
function cellText(v) {
  if (v === null || v === undefined) return '';
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === 'object') {
    if (v.richText) return v.richText.map(t => t.text).join('');
    if ('result' in v) return cellText(v.result);
    if (v.text !== undefined) return cellText(v.text);
    if (v.hyperlink) return v.hyperlink;
    if (v.error) return '';
    return '';
  }
  return String(v);
}

function stripHtml(s) {
  return s.replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n').replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{2,}/g, '\n').trim();
}

function htmlTables(html) {
  const tables = [];
  for (const t of html.match(/<table[\s\S]*?<\/table>/gi) || []) {
    const rows = [];
    for (const tr of t.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      rows.push((tr.match(/<t[dh][\s\S]*?<\/t[dh]>/gi) || []).map(td => {
        const link = td.match(/href="([^"]*linkedin\.com[^"]*)"/i);
        const text = stripHtml(td);
        return link && !/linkedin\.com/i.test(text) ? link[1] : text;
      }));
    }
    if (rows.length >= 2) tables.push(rows);
  }
  return tables;
}

export class UnsupportedFileError extends Error {}

export async function parseFile(buf, originalName) {
  const ext = path.extname(originalName).toLowerCase();
  if (ext === '.xls') throw new UnsupportedFileError('Older .xls files aren’t supported. Save the file as .xlsx or .csv and upload it again.');
  if (ext === '.doc') throw new UnsupportedFileError('Older .doc files aren’t supported. Save the file as .docx and upload it again.');

  if (ext === '.csv' || ext === '.tsv' || ext === '.txt' && /[,\t]/.test(buf.toString('utf8', 0, 2000))) {
    const text = buf.toString('utf8').replace(/^﻿/, '');
    const res = Papa.parse(text, { skipEmptyLines: 'greedy' });
    if (!res.data.length) throw new UnsupportedFileError('This CSV file is empty.');
    return tableResult('csv', [{ name: 'Sheet 1', rows: res.data.map(r => r.map(c => String(c ?? ''))) }]);
  }
  if (ext === '.xlsx' || ext === '.xlsm') {
    const wb = new ExcelJS.Workbook();
    try { await wb.xlsx.load(buf); } catch { throw new UnsupportedFileError('This Excel file couldn’t be read. It may be damaged or password protected.'); }
    const sheets = [];
    wb.eachSheet(ws => {
      const rows = [];
      ws.eachRow({ includeEmpty: true }, (row) => {
        const vals = [];
        for (let c = 1; c <= ws.columnCount; c++) vals.push(cellText(row.getCell(c).value).trim());
        rows.push(vals);
      });
      while (rows.length && rows[rows.length - 1].every(c => !c)) rows.pop();
      if (rows.some(r => r.some(Boolean))) sheets.push({ name: ws.name, rows });
    });
    if (!sheets.length) throw new UnsupportedFileError('This workbook doesn’t contain any data.');
    return tableResult('excel', sheets);
  }
  if (ext === '.docx') {
    let html, text;
    try {
      html = (await mammoth.convertToHtml({ buffer: buf })).value;
      text = htmlToText(html);
    } catch { throw new UnsupportedFileError('This Word file couldn’t be read. It may be damaged or password protected.'); }
    const tables = htmlTables(html);
    const candidates = extractCandidates(text);
    if (tables.length) {
      const r = tableResult('word', tables.map((rows, i) => ({ name: `Table ${i + 1}`, rows })));
      r.review_required = true;
      r.text_candidates = candidates;
      return r;
    }
    return { kind: 'document', file_kind: 'word', review_required: true, candidates, text_length: text.length };
  }
  if (ext === '.pdf') {
    let text;
    try {
      const parser = new PDFParse({ data: new Uint8Array(buf) });
      text = (await parser.getText()).text;
      await parser.destroy?.();
    } catch { throw new UnsupportedFileError('This PDF couldn’t be read. It may be scanned, damaged or password protected.'); }
    if (!text || text.replace(/\s/g, '').length < 20) throw new UnsupportedFileError('No readable text was found in this PDF. Scanned PDFs need to be converted to text first.');
    return { kind: 'document', file_kind: 'pdf', review_required: true, candidates: extractCandidates(text), text_length: text.length };
  }
  throw new UnsupportedFileError('This file type isn’t supported. Upload a CSV, Excel (.xlsx), Word (.docx) or PDF file.');
}

function tableResult(fileKind, sheets) {
  return {
    kind: 'table', file_kind: fileKind,
    sheets: sheets.map(s => {
      const width = Math.max(...s.rows.map(r => r.length));
      const rows = s.rows.map(r => Array.from({ length: width }, (_, i) => r[i] ?? ''));
      const headerRow = detectHeaderRow(rows);
      return { name: s.name, rows, header_row: headerRow, mapping: suggestMapping(rows[headerRow] || []) };
    }),
  };
}

// ---------------- Word / PDF extraction ----------------
const LI_FIND = /(?:https?:\/\/)?(?:[a-z]{2,3}\.)?linkedin\.com\/(?:in|pub)\/[A-Za-z0-9\-_%.]+\/?/gi;
const URL_FIND = /\b(?:https?:\/\/)?(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|co|au|com\.au|io|net|org|shop|store|beauty|skin|us|co\.uk)(?:\/[^\s,;)]*)?/gi;
const TITLE_WORDS = /\b(founder|co-founder|cofounder|ceo|chief|director|manager|head of|vp|vice president|president|owner|lead|partner|officer|marketing|brand|creative|content|ecommerce|e-commerce|growth)\b/i;
const NAME_RE = /^(?:[A-Z][a-zA-Z'’\-]+)(?:\s+(?:[A-Z][a-zA-Z'’\-]+|[A-Z]\.)){1,3}$/;
const COUNTRIES = ['United States', 'USA', 'Australia', 'United Kingdom', 'Canada', 'New Zealand', 'Spain', 'Singapore', 'Philippines', 'Germany', 'France', 'Ireland'];

function isNameLine(l) { return NAME_RE.test(l.replace(/^name\s*:\s*/i, '').trim()) && !TITLE_WORDS.test(l); }

// Splits free text into possible lead records, anchored on LinkedIn profile URLs.
function extractCandidates(text) {
  const lines = text.replace(/\r/g, '').split('\n').map(l => l.replace(/\s+$/, ''));
  const anchors = [];
  lines.forEach((l, i) => { if (LI_FIND.test(l)) anchors.push(i); LI_FIND.lastIndex = 0; });
  const blocks = [];
  if (anchors.length) {
    const lead = (from, to) => { // lines that belong before an anchor: start at the last blank line or name line
      let seg = lines.slice(from, to);
      const blank = seg.map(l => !l.trim()).lastIndexOf(true);
      if (blank >= 0) seg = seg.slice(blank + 1);
      const nameAt = seg.findIndex(isNameLine);
      if (nameAt >= 0) seg = seg.slice(nameAt);
      return seg.slice(-6);
    };
    anchors.forEach((a, k) => {
      const prevEnd = k === 0 ? Math.max(0, a - 8) : anchors[k - 1] + 1;
      const nextStart = k === anchors.length - 1 ? Math.min(lines.length, a + 5) : anchors[k + 1];
      // Lines after this anchor stay with it until a blank line or the next person's name.
      const after = [];
      for (let i = a + 1; i < nextStart; i++) {
        const l = lines[i];
        if (!l.trim() || isNameLine(l)) break;
        if (k < anchors.length - 1 && TITLE_WORDS.test(l) && !EMAIL_RE.test(l)) break;
        after.push(l);
      }
      const before = k === 0 ? lead(prevEnd, a) : lead(prevEnd + blocksAfterLen(k - 1), a);
      blocks.push({ lines: [...before, lines[a], ...after], afterLen: after.length });
      function blocksAfterLen(j) { return blocks[j] ? blocks[j].afterLen : 0; }
    });
  } else {
    // No profile links: use paragraphs that contain an email address.
    for (const b of text.split(/\n\s*\n/)) if (EMAIL_RE.test(b)) blocks.push({ lines: b.split('\n') });
  }
  const out = [];
  for (const { lines: bl } of blocks) {
    const block = bl.filter(l => l.trim()).join('\n');
    const li = block.match(LI_FIND); LI_FIND.lastIndex = 0;
    const email = block.match(EMAIL_RE);
    const parts = bl.flatMap(l => l.split(/\t|\s{3,}|\s[|•–—]\s/)).map(x => x.trim()).filter(Boolean);
    const cand = { full_name: '', title: '', company: '', linkedin_url: li ? li[0] : '', business_email: email ? email[0] : '', website: '', country: '' };
    for (const p of parts) {
      const bare = p.replace(LI_FIND, '').replace(EMAIL_RE, '').replace(/^(name|title|position|company|brand|email|linkedin|website)\s*:\s*/i, '').trim();
      LI_FIND.lastIndex = 0;
      if (!bare) continue;
      const label = (p.match(/^(name|title|position|company|brand|website)\s*:/i) || [])[1]?.toLowerCase();
      if (label === 'name' && !cand.full_name) { cand.full_name = bare; continue; }
      if ((label === 'title' || label === 'position') && !cand.title) { cand.title = bare; continue; }
      if ((label === 'company' || label === 'brand') && !cand.company) { cand.company = bare; continue; }
      if (label === 'website' && !cand.website) { cand.website = bare; continue; }
      const at = bare.match(/^(.*?)\s+(?:at|@)\s+(.+)$/i);
      if (at && TITLE_WORDS.test(at[1]) && !cand.title) { cand.title = at[1].trim(); cand.company ||= at[2].trim(); continue; }
      if (!cand.full_name && isNameLine(bare)) { cand.full_name = bare; continue; }
      if (!cand.title && TITLE_WORDS.test(bare) && bare.length < 80) { cand.title = bare; continue; }
      const site = bare.match(URL_FIND);
      if (site && !cand.website && !/linkedin/i.test(site[0]) && !/\s/.test(bare)) { cand.website = site[0]; continue; }
      const country = COUNTRIES.find(c => new RegExp(`\\b${c}\\b`, 'i').test(bare));
      if (country && !cand.country) cand.country = country === 'USA' ? 'United States' : country;
    }
    cand._context = block.slice(0, 400);
    out.push(cand);
  }
  return out;
}

// Word HTML to text that keeps paragraph and line breaks.
function htmlToText(html) {
  return html.replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|h[1-6]|li|tr)>/gi, '\n\n').replace(/<\/t[dh]>/gi, '\t')
    .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}

// ---------------- Record building & validation ----------------
const GAP_FIELDS = new Set(['full_name', 'title', 'company', 'website', 'business_email', 'city', 'country', 'brand_category']);
const MISSING = /^(not found|not confirmed|n\/?a|none|unknown|tbc|tbd|-|—|\?)$/i;

function cleanValue(v) {
  const s = String(v ?? '').replace(/\s+/g, ' ').trim();
  return s;
}

export function recordsFromTable(sheet, headerRow, mapping) {
  const rows = sheet.rows.slice(headerRow + 1);
  const headers = sheet.rows[headerRow] || [];
  const records = [];
  rows.forEach((r, i) => {
    if (!r.some(c => String(c ?? '').trim())) return;
    const rec = { _row: headerRow + i + 2, _extra: {} };
    r.forEach((val, ci) => {
      const key = mapping[ci];
      const v = cleanValue(val);
      if (key && FIELD_KEYS.has(key)) { if (v && !rec[key]) rec[key] = v; }
      else if (v && headers[ci]) rec._extra[cleanValue(headers[ci])] = v;
    });
    records.push(rec);
  });
  return records;
}

// Turns a raw record into a lead-shaped object plus issues. Never invents values.
export function buildLead(raw) {
  const lead = {}; const gaps = {}; const errors = []; const warnings = [];
  const take = (k) => {
    const v = cleanValue(raw[k]);
    if (!v) return null;
    if (MISSING.test(v)) { if (GAP_FIELDS.has(k)) gaps[k] = v; return null; }
    return v;
  };
  lead.full_name = take('full_name') || [take('first_name'), take('last_name')].filter(Boolean).join(' ') || null;
  for (const k of ['title', 'company', 'website', 'business_email', 'email_type', 'email_source', 'city', 'country',
    'location_basis', 'market', 'brand_category', 'priority', 'fit_rationale', 'qualification_notes',
    'verification_notes', 'company_size', 'research_date', 'connection_note']) lead[k] = take(k);
  const loc = take('location');
  if (loc && !lead.city && !lead.country) {
    const bits = loc.split(',').map(s => s.trim()).filter(Boolean);
    if (bits.length > 1) { lead.country = bits.pop(); lead.city = bits.join(', '); } else lead.city = loc;
  }
  if (lead.email_type && /not found/i.test(lead.email_type)) lead.email_type = null;
  if (lead.website && !/^https?:\/\//i.test(lead.website)) lead.website = `https://${lead.website}`;
  if (lead.business_email && !EMAIL_RE.test(lead.business_email)) {
    warnings.push(`Email “${lead.business_email}” doesn’t look valid and was left out`);
    gaps.business_email = 'Unclear'; lead.business_email = null;
  }
  if (lead.priority) {
    const p = lead.priority.toLowerCase();
    lead.priority = /high/.test(p) ? 'High' : /med/.test(p) ? 'Medium' : /low/.test(p) ? 'Low' : null;
  }
  const sources = {};
  for (const k of ['role_source', 'brand_source', 'location_source']) { const v = take(k); if (v) sources[k] = v; }
  lead.sources = Object.keys(sources).length ? sources : null;
  lead.extra = raw._extra && Object.keys(raw._extra).length ? raw._extra : null;

  // Fit classification: use the file's value when it has one, otherwise suggest from the brief.
  const rawFit = take('fit');
  const fromFile = normaliseFit(rawFit);
  if (fromFile) { lead.fit = fromFile; lead.fit_basis = 'source'; }
  else {
    const s = suggestFit(lead);
    lead.fit = s.fit; lead.fit_basis = s.fit ? 'suggested' : null;
    if (s.fit) warnings.push(`Fit suggested from the brief: ${s.fit} (${s.reason.toLowerCase()})`);
    else warnings.push('Fit needs review');
  }

  if (!lead.full_name) errors.push('Name is missing');
  const li = parseLinkedIn(raw.linkedin_url);
  if (!li.ok) errors.push(li.error);
  else { lead.linkedin_url = li.url; lead.linkedin_key = li.key; }
  lead.gaps = gaps;
  for (const [k, v] of Object.entries(gaps)) {
    const label = FIELDS.find(f => f.key === k)?.label || k;
    warnings.push(`${label}: ${v.toLowerCase()}`);
  }
  if (!lead.business_email && !gaps.business_email) warnings.push('No business email');
  if (!lead.city && !lead.country && !gaps.city && !gaps.country) warnings.push('No location');
  return { lead, errors, warnings };
}

export async function validateRecords(records) {
  const existingByKey = new Map((await all('SELECT id, full_name, linkedin_key FROM leads')).map(r => [r.linkedin_key, r]));
  const existingEmails = new Map();
  for (const r of await all('SELECT id, full_name, business_email FROM leads WHERE business_email IS NOT NULL')) {
    const k = r.business_email.toLowerCase();
    if (!existingEmails.has(k)) existingEmails.set(k, []);
    existingEmails.get(k).push(r.full_name);
  }
  const seenKeys = new Map();
  const fileEmails = new Map();
  const built = records.map(r => ({ raw: r, ...buildLead(r) }));
  for (const b of built) {
    const e = b.lead.business_email?.toLowerCase();
    if (e) { if (!fileEmails.has(e)) fileEmails.set(e, []); fileEmails.get(e).push(b.lead.full_name || 'Unnamed'); }
  }
  return built.map((b, index) => {
    const out = { index, row: b.raw._row ?? null, lead: b.lead, errors: [...b.errors], warnings: [...b.warnings], state: 'ready', duplicate_of: null };
    const key = b.lead.linkedin_key;
    if (key && existingByKey.has(key)) {
      out.state = 'duplicate';
      out.duplicate_of = existingByKey.get(key).full_name;
      out.errors.unshift(`Already in the database as ${existingByKey.get(key).full_name}`);
    } else if (key && seenKeys.has(key)) {
      out.state = 'duplicate';
      out.duplicate_of = seenKeys.get(key);
      out.errors.unshift(`Same LinkedIn profile appears earlier in this file (row ${seenKeys.get(key)})`);
    } else if (out.errors.length) {
      out.state = 'error';
    }
    if (key && !seenKeys.has(key)) seenKeys.set(key, b.raw._row ?? index + 1);
    const email = b.lead.business_email?.toLowerCase();
    if (email) {
      const named = /named|personal|direct/i.test(b.lead.email_type || '');
      const inDb = existingEmails.get(email) || [];
      const inFile = (fileEmails.get(email) || []).filter(n => n !== b.lead.full_name);
      const others = [...new Set([...inDb, ...inFile])];
      if (others.length) {
        out.warnings.unshift(named
          ? `Possible duplicate person: named email also used by ${others.join(', ')}`
          : `Shared inbox also used by ${others.join(', ')}`);
      }
    }
    return out;
  });
}

// ---------------- Commit ----------------
export async function commitImport(importRow, records, user, { assignTo } = {}) {
  const results = await validateRecords(records);
  const templates = { ...DEFAULT_TEMPLATES, ...(await getSetting('templates', {})) };
  const assignee = user.role === 'assistant' ? user.id : (assignTo || null);
  const added = []; const skipped = []; const needCorrection = []; const excluded = []; let flagged = 0;
  await tx(async () => {
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      const include = records[i]._include !== false;
      const label = r.lead.full_name || `Row ${r.row ?? i + 1}`;
      if (r.state === 'duplicate') { skipped.push({ name: label, row: r.row, reason: r.errors[0] }); continue; }
      if (r.state === 'error') { needCorrection.push({ name: label, row: r.row, reason: r.errors.join('; ') }); continue; }
      if (!include) { excluded.push({ name: label, row: r.row, reason: 'Not approved in review' }); continue; }
      const l = r.lead; const t = now();
      const status = assignee ? 'Assigned' : 'New';
      const res = await get(`INSERT INTO leads (full_name, title, linkedin_url, linkedin_key, company, website, city, country,
        market, location_basis, brand_category, fit, fit_basis, priority, assigned_to, status, status_updated_at, status_updated_by,
        connection_note, followup_note, company_size, business_email, email_type, email_source, qualification_notes,
        fit_rationale, verification_notes, research_date, sources, gaps, extra, import_id, created_by, created_at, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT (linkedin_key) DO NOTHING RETURNING id`,
      [l.full_name, l.title, l.linkedin_url, l.linkedin_key, l.company, l.website, l.city, l.country,
        l.market, l.location_basis, l.brand_category, l.fit, l.fit_basis, l.priority, assignee, status, t, user.id,
        l.connection_note || renderTemplate(templates.connection, l), renderTemplate(templates.followup, l),
        l.company_size, l.business_email, l.email_type, l.email_source, l.qualification_notes,
        l.fit_rationale, l.verification_notes, l.research_date,
        l.sources ? JSON.stringify(l.sources) : null, JSON.stringify(l.gaps || {}), l.extra ? JSON.stringify(l.extra) : null,
        importRow.id, user.id, t, t]);
      if (!res) { skipped.push({ name: label, row: r.row, reason: 'Added by someone else a moment ago' }); continue; }
      await logActivity(res.id, user.id, 'imported', { to: status, detail: { file: importRow.filename, row: r.row } });
      const hasGaps = Object.keys(l.gaps || {}).length > 0 || !l.business_email;
      if (hasGaps) flagged++;
      added.push({ id: res.id, name: l.full_name, row: r.row, flagged: hasGaps });
    }
    const summary = {
      total: records.length, added: added.length, skipped: skipped.length + excluded.length,
      need_correction: needCorrection.length, flagged_gaps: flagged,
      duplicates: skipped, excluded, corrections: needCorrection, added_leads: added,
    };
    await run("UPDATE imports SET status = 'completed', summary = ?, completed_at = ?, parsed = NULL WHERE id = ?",
      [JSON.stringify(summary), now(), importRow.id]);
  });
  const summary = {
    total: records.length, added: added.length, skipped: skipped.length + excluded.length,
    need_correction: needCorrection.length, flagged_gaps: flagged,
    duplicates: skipped, excluded, corrections: needCorrection, added_leads: added,
  };
  await notify([...(await ownerIds()), user.id], {
    type: 'import', title: `File import finished: ${importRow.filename}`,
    body: `${summary.added} added, ${summary.skipped} skipped, ${summary.need_correction} need correction${flagged ? `, ${flagged} added with missing details flagged` : ''}.`,
    import_id: importRow.id,
  });
  if (assignee && assignee !== user.id && added.length) {
    await notify([assignee], { type: 'assigned', title: `${added.length} new ${added.length === 1 ? 'lead' : 'leads'} assigned to you`, body: `From ${importRow.filename}.` });
  }
  await broadcast('leads', 'imports', 'activity', 'metrics');
  return summary;
}

export async function createImport(user, filename, kind, parsed) {
  const r = await get('INSERT INTO imports (user_id, filename, file_kind, status, parsed, created_at) VALUES (?, ?, ?, ?, ?, ?) RETURNING id',
    [user.id, filename, kind, 'preview', JSON.stringify(parsed), now()]);
  return r.id;
}

export function recordsForImport(importRow, body) {
  const parsed = JSON.parse(importRow.parsed || 'null');
  if (!parsed) throw httpError(409, 'This import has already been completed or cancelled.');
  if (parsed.kind === 'table' && body.mode !== 'candidates') {
    const sheet = parsed.sheets[Number(body.sheet) || 0];
    if (!sheet) throw httpError(400, 'Choose a sheet.');
    const headerRow = Math.max(0, Math.min(Number(body.header_row ?? sheet.header_row), sheet.rows.length - 1));
    const mapping = Array.isArray(body.mapping) ? body.mapping.map(k => (FIELD_KEYS.has(k) ? k : '')) : sheet.mapping;
    if (!mapping.includes('linkedin_url')) throw httpError(400, 'Map a column to LinkedIn URL before continuing.');
    if (!mapping.some(k => ['full_name', 'first_name'].includes(k))) throw httpError(400, 'Map a column to Full name (or First name) before continuing.');
    return recordsFromTable(sheet, headerRow, mapping);
  }
  // Document candidates are edited in review and sent back.
  const recs = Array.isArray(body.records) ? body.records : [];
  return recs.slice(0, 5000).map((r, i) => {
    const rec = { _row: r._row ?? i + 1, _extra: {} };
    for (const k of FIELD_KEYS) if (r[k] !== undefined) rec[k] = String(r[k] ?? '');
    return rec;
  });
}

// Applies reviewer edits and approvals. Word/PDF imports need explicit approval per record.
export function applyReview(records, body, reviewRequired) {
  const overrides = body.overrides && typeof body.overrides === 'object' ? body.overrides : {};
  const include = Array.isArray(body.include) ? new Set(body.include.map(Number)) : null;
  return records.map((r, i) => {
    const o = overrides[i];
    const rec = { ...r };
    if (o && typeof o === 'object') for (const k of FIELD_KEYS) if (o[k] !== undefined) rec[k] = String(o[k] ?? '');
    rec._include = include ? include.has(i) : !reviewRequired;
    return rec;
  });
}
