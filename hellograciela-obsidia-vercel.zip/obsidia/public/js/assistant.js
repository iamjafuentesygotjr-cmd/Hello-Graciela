// Assistant portal: assigned leads, today's targets and the next action for each lead.
import { api, esc, fmtTime, fmtFull, patchList, ICON, toastError, safeUrl, ago } from './util.js';
import {
  statusPill, fitChip, location, gapChips, QUICK, trackOpen, statusModal, followupModal, notesPopover,
  bindNoteEditing, copyNote, resetNote, detailsBlock, bindQualForms,
} from './leads.js';
import { openImportWizard, importHistory } from './imports.js';

const FILTERS = [
  { key: 'todo', label: 'To do', match: l => ['New', 'Assigned', 'Profile opened'].includes(l.status) },
  { key: 'followups', label: 'Follow-ups', match: l => l.status === 'Follow-up due' },
  { key: 'waiting', label: 'Waiting', match: l => l.status === 'Connection sent' },
  { key: 'talking', label: 'Conversations', match: l => ['Connected', 'Replied'].includes(l.status) },
  { key: 'booked', label: 'Booked', match: l => l.status === 'Meeting booked' },
  { key: 'all', label: 'All', match: () => true },
];
const FIT_RANK = { 'Primary fit': 0, 'Secondary fit': 1 };

export function assistantView(ctx) {
  const ui = { filter: 'todo', q: '', note: null, expanded: new Set(), activity: new Map() };
  const root = document.createElement('div');
  root.className = 'page';
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  root.innerHTML = `
    <div class="page-head">
      <div>
        <h1>${greet}, <em>${esc(ctx.me.display_name)}</em></h1>
        <p class="sub" data-sub></p>
      </div>
      <button class="btn btn-dark" data-act="import">${ICON.upload} Add leads</button>
    </div>
    <section class="card card-pad" aria-labelledby="targets-h">
      <div class="card-title"><h2 id="targets-h">Today’s targets</h2><span class="muted small" data-tz></span></div>
      <div class="targets" data-targets></div>
    </section>
    <section class="section">
      <div class="toolbar">
        <div class="seg" role="group" aria-label="Filter leads" data-filters></div>
        <label class="search grow"><span class="sr-only">Search leads</span>${ICON.search}<input class="input" type="search" placeholder="Search by name, company or category" data-q></label>
      </div>
      <div class="lead-grid" data-list></div>
      <div data-empty></div>
    </section>
    <section class="section" data-uploads></section>`;

  const $ = (s) => root.querySelector(s);
  const getLead = (id) => ctx.state.leads.find(l => l.id === id);

  function visible() {
    const f = FILTERS.find(x => x.key === ui.filter);
    const q = ui.q.trim().toLowerCase();
    return ctx.state.leads.filter(l => f.match(l) && (!q || [l.full_name, l.company, l.title, l.brand_category, l.city, l.country].join(' ').toLowerCase().includes(q)))
      .sort((a, b) => (b.follow_up_overdue - a.follow_up_overdue)
        || (ui.filter === 'followups' ? String(a.follow_up_due_at).localeCompare(String(b.follow_up_due_at)) : 0)
        || ((FIT_RANK[a.fit] ?? 2) - (FIT_RANK[b.fit] ?? 2)) || a.id - b.id);
  }

  function card(l) {
    const quick = (QUICK[l.status] || []).map(q => `<button class="btn" data-act="${q.followup ? 'followup' : 'quick'}" data-to="${esc(q.to || '')}" data-id="${l.id}">${esc(q.label)}</button>`).join('');
    const noteOpen = ui.note?.id === l.id;
    const last = l.status_updated_at
      ? `${esc(l.status)} · ${esc(fmtTime(l.status_updated_at))}${l.status_updated_by_name ? ` by ${esc(l.status_updated_by_name)}` : ''}`
      : 'Not started';
    const due = l.status === 'Follow-up due' && l.follow_up_due_at
      ? `<span class="small ${l.follow_up_overdue ? '' : 'muted'}" style="display:block;margin-top:2px">${l.follow_up_overdue ? 'Overdue since' : 'Due'} ${esc(fmtFull(l.follow_up_due_at))}</span>` : '';
    return `
      <article class="card lead" id="lead-${l.id}" data-id="${l.id}">
        <button type="button" class="notes-fab" data-act="note" data-id="${l.id}" aria-expanded="${noteOpen}" aria-label="Outreach message for ${esc(l.full_name)}" title="Outreach message"><span aria-hidden="true">💬</span></button>
        ${noteOpen ? notesPopover(l, ui.note.kind) : ''}
        <div class="lead-top">${statusPill(l)}${fitChip(l)}</div>
        <div>
          <div class="lead-name">${esc(l.full_name)}</div>
          <div class="lead-role">${esc(l.title || 'Position not listed')}${l.company ? ` · <span class="co">${esc(l.company)}</span>` : ''}</div>
        </div>
        <div class="lead-meta">
          ${location(l) ? `<span class="chip">${esc(location(l))}</span>` : ''}
          ${l.brand_category ? `<span class="chip outline">${esc(l.brand_category)}</span>` : ''}
          ${gapChips(l)}
        </div>
        <div class="next ${l.follow_up_overdue ? 'overdue' : ''}"><span class="arrow" aria-hidden="true">→</span>
          <div><span class="lbl">Next action</span>${esc(l.next_action)}${due}</div></div>
        <div class="lead-actions">
          <a class="btn btn-primary btn-linkedin" href="${safeUrl(l.linkedin_url)}" target="_blank" rel="noopener noreferrer" data-act="open" data-id="${l.id}">Open LinkedIn profile ${ICON.external}</a>
          <div class="row">${quick}<button class="btn" data-act="status" data-id="${l.id}">Update status</button></div>
        </div>
        <div class="lead-foot">
          <span>${last}${l.profile_opened_at ? ` · profile opened ${esc(ago(l.profile_opened_at))}` : ''}</span>
          <button type="button" class="link-btn" data-act="details" data-id="${l.id}" aria-expanded="${ui.expanded.has(l.id)}">${ui.expanded.has(l.id) ? 'Hide details' : 'Details and history'}</button>
        </div>
        ${ui.expanded.has(l.id) ? detailsBlock(l, ui.activity.get(l.id)) : ''}
      </article>`;
  }

  let forcing = false;
  // Leave a card alone while someone is typing in it or has its notes open (unless they just changed it).
  const busy = (el) => (el.contains(document.activeElement) && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))
    || el.querySelector('[data-dirty]') || (!forcing && el.querySelector('.notes-pop'));

  function renderList(force = false) {
    forcing = force;
    try { renderListInner(); } finally { forcing = false; }
  }
  function renderListInner() {
    const counts = Object.fromEntries(FILTERS.map(f => [f.key, ctx.state.leads.filter(f.match).length]));
    $('[data-filters]').innerHTML = FILTERS.map(f => `<button type="button" data-filter="${f.key}" aria-pressed="${ui.filter === f.key}">${f.label}<span class="n">${counts[f.key]}</span></button>`).join('');
    const items = visible();
    patchList($('[data-list]'), items, l => l.id, card, busy);
    $('[data-empty]').innerHTML = items.length ? '' : `<div class="card empty"><h3>${ctx.state.leads.length ? 'Nothing here right now' : 'No leads assigned yet'}</h3><p>${ctx.state.leads.length ? 'Try another filter, or check your follow-ups.' : 'Leads the owner assigns to you, or that you upload, will appear here.'}</p></div>`;
    const open = ctx.state.leads.filter(l => FILTERS[0].match(l)).length;
    const overdue = ctx.state.leads.filter(l => l.follow_up_overdue).length;
    $('[data-sub]').textContent = `${new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })} · ${ctx.state.leads.length} assigned · ${open} to start${overdue ? ` · ${overdue} follow-up${overdue === 1 ? '' : 's'} overdue` : ''}`;
  }

  function renderTargets() {
    const p = ctx.state.progress;
    if (!p) return;
    $('[data-tz]').textContent = `Days reset at midnight, ${p.timezone.replace(/_/g, ' ')} time`;
    $('[data-targets]').innerHTML = p.metrics.map(m => {
      const pct = m.target ? Math.min(100, Math.round((m.today / m.target) * 100)) : 0;
      const done = m.target && m.today >= m.target;
      return `<div class="target">
        <div class="row"><span>${esc(m.label)}</span><span><b>${m.today}</b><span class="muted"> / ${m.target || '—'}</span>${done ? ' <span class="done-tag">Done</span>' : ''}</span></div>
        <div class="meter ${done ? 'done' : ''}" role="progressbar" aria-label="${esc(m.label)}" aria-valuemin="0" aria-valuemax="${m.target}" aria-valuenow="${m.today}"><span style="width:${pct}%"></span></div>
      </div>`;
    }).join('');
  }

  async function loadActivity(id) {
    try {
      const { activity } = await api(`/api/leads/${id}`);
      ui.activity.set(id, activity);
      renderList();
    } catch (e) { toastError(e); }
  }

  // ---------- Events ----------
  root.addEventListener('click', async (e) => {
    const f = e.target.closest('[data-filter]');
    if (f) { ui.filter = f.dataset.filter; renderList(true); return; }
    const el = e.target.closest('[data-act]');
    if (!el) {
      if (ui.note && !e.target.closest('.notes-pop')) { ui.note = null; renderList(true); }
      return;
    }
    const act = el.dataset.act;
    const id = Number(el.dataset.id || el.closest('[data-pop]')?.dataset.pop || el.closest('.lead')?.dataset.id);
    const lead = getLead(id);
    if (act === 'import') return openImportWizard(ctx);
    if (!lead) return;
    if (ui.note && ['open', 'status', 'quick', 'followup', 'details'].includes(act)) { ui.note = null; renderList(true); }
    if (act === 'open') { trackOpen(lead); return; } // default link behaviour opens the new tab
    if (act === 'status') return statusModal(lead, ctx.constants.statuses);
    if (act === 'quick') return statusModal(lead, ctx.constants.statuses, el.dataset.to);
    if (act === 'followup') return followupModal(lead);
    if (act === 'note') { ui.note = ui.note?.id === id ? null : { id, kind: 'connection' }; renderList(true); if (ui.note) root.querySelector(`[data-pop="${id}"] textarea`)?.focus(); return; }
    if (act === 'note-close') { ui.note = null; renderList(true); return; }
    if (act === 'note-tab') { ui.note = { id, kind: el.dataset.kind }; renderList(true); return; }
    if (act === 'note-copy') { const ta = el.closest('[data-pop]').querySelector('textarea'); return copyNote(lead, el.dataset.kind, ta.value); }
    if (act === 'note-reset') return resetNote(lead, el.dataset.kind, el.closest('[data-pop]'));
    if (act === 'details') {
      if (ui.expanded.has(id)) ui.expanded.delete(id); else { ui.expanded.add(id); loadActivity(id); }
      renderList();
    }
  });
  // Middle-click also opens the profile in a new tab, so record that too.
  root.addEventListener('auxclick', (e) => {
    const el = e.target.closest('[data-act="open"]');
    if (el && e.button === 1) trackOpen(getLead(Number(el.dataset.id)));
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ui.note && !document.querySelector('.modal')) { ui.note = null; renderList(true); } });
  $('[data-q]').addEventListener('input', (e) => { ui.q = e.target.value; renderList(); });
  bindNoteEditing(root, getLead);
  bindQualForms(root, getLead);

  async function renderUploads() {
    $('[data-uploads]').innerHTML = await importHistory(ctx, { title: 'Your uploads' });
  }

  return {
    el: root,
    async refresh(scopes) {
      const all = !scopes;
      if (all || scopes.has('leads')) {
        // Refresh open histories so both portals stay in step.
        for (const id of ui.expanded) loadActivity(id);
      } else if (scopes.has('activity')) for (const id of ui.expanded) loadActivity(id);
      renderList();
      renderTargets();
      if (all || scopes.has('imports')) renderUploads();
    },
    focusLead(id) {
      ui.filter = 'all'; renderList();
      const el = root.querySelector(`#lead-${id}`);
      if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 2000); }
    },
  };
}
