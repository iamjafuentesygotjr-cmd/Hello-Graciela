// Import wizard: upload → map columns → review (duplicates, validation) → summary.
import { api, esc, openModal, toast, toastError, fmtFull, ICON, plural } from './util.js';

const ACCEPT = '.csv,.xlsx,.xlsm,.docx,.pdf';
const DOC_FIELDS = [
  ['full_name', 'Full name'], ['title', 'Position'], ['company', 'Company'], ['linkedin_url', 'LinkedIn URL'],
  ['business_email', 'Business email'], ['website', 'Company website'], ['country', 'Country'], ['brand_category', 'Brand category'],
];

export function openImportWizard(ctx, file) {
  const w = { step: 'upload', imp: null, fields: [], sheet: 0, headerRow: 0, mapping: [], results: null, counts: null, records: null, include: new Set(), overrides: {}, summary: null, assignTo: '' };
  const assistants = (ctx.state.users || []).filter(u => u.role === 'assistant' && u.active);
  if (ctx.me.role === 'owner' && assistants.length) w.assignTo = String(assistants[0].id);
  const m = openModal('<div data-body></div>', { wide: true, label: 'Add leads from a file', onClose: () => { if (w.imp && w.step !== 'done') api(`/api/imports/${w.imp.id}/cancel`, { method: 'POST' }).catch(() => {}); } });
  const body = m.box.querySelector('[data-body]');
  const isDoc = () => w.imp?.preview?.kind === 'document';
  const reviewRequired = () => !!w.imp?.preview?.review_required;

  const steps = () => {
    const list = isDoc() ? [['upload', 'Upload'], ['review', 'Review'], ['done', 'Summary']] : [['upload', 'Upload'], ['map', 'Preview and map'], ['review', 'Review'], ['done', 'Summary']];
    return `<div class="steps">${list.map(([k, l], i) => `<span class="${w.step === k ? 'on' : ''}">${i + 1}. ${l}</span>`).join('')}</div>`;
  };
  const head = (title, sub) => `<div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
      <div><h2>${title}</h2>${sub ? `<p class="muted small" style="margin-top:6px">${sub}</p>` : ''}</div>
      <button class="icon-btn" data-x aria-label="Close">${ICON.close}</button></div>${steps()}`;

  function render() {
    if (w.step === 'upload') renderUpload();
    else if (w.step === 'map') renderMap();
    else if (w.step === 'review') renderReview();
    else renderDone();
    body.querySelector('[data-x]')?.addEventListener('click', () => m.close());
    m.box.scrollTop = 0;
  }

  // ---------- Upload ----------
  function renderUpload(error = '') {
    body.innerHTML = `${head('Add leads from a file', 'Upload a CSV, Excel (.xlsx), Word (.docx) or PDF file. Nothing is added until you review it.')}
      <label class="dropzone" data-drop tabindex="0">
        <input type="file" accept="${ACCEPT}" hidden data-file>
        <div class="big">Drop a file here, or choose one</div>
        <div class="muted small">Spreadsheets get column mapping. Word and PDF files are scanned for possible leads you can review and edit. Up to 4 MB per file.</div>
      </label>
      <p class="form-error" role="alert" data-err>${esc(error)}</p>`;
    const dz = body.querySelector('[data-drop]');
    const input = body.querySelector('[data-file]');
    input.onchange = () => input.files[0] && upload(input.files[0]);
    dz.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
    dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('over'));
    dz.addEventListener('drop', (e) => { e.preventDefault(); dz.classList.remove('over'); if (e.dataTransfer.files[0]) upload(e.dataTransfer.files[0]); });
  }

  async function upload(f) {
    body.querySelector('[data-err]').textContent = '';
    body.querySelector('.big').textContent = `Reading ${f.name}…`;
    const form = new FormData();
    form.append('file', f);
    try {
      const res = await api('/api/imports', { method: 'POST', form });
      w.imp = res.import; w.fields = res.fields;
      if (isDoc()) {
        w.records = w.imp.preview.candidates.map((c, i) => ({ ...c, _row: i + 1 }));
        await validate();
        w.step = 'review';
      } else {
        const s = w.imp.preview.sheets[0];
        w.sheet = 0; w.headerRow = s.header_row; w.mapping = [...s.mapping];
        w.step = 'map';
      }
      render();
    } catch (e) { renderUpload(e.message); }
  }

  // ---------- Map ----------
  function renderMap(error = '') {
    const sheets = w.imp.preview.sheets;
    const s = sheets[w.sheet];
    const headers = s.rows[w.headerRow] || [];
    const dataRows = s.rows.slice(w.headerRow + 1).filter(r => r.some(Boolean));
    const samples = headers.map((_, ci) => dataRows.map(r => r[ci]).filter(Boolean).slice(0, 2).join(' · '));
    const opts = (sel) => `<option value="">Don’t import</option>${w.fields.map(f => `<option value="${f.key}" ${f.key === sel ? 'selected' : ''}>${esc(f.label)}</option>`).join('')}`;
    const previewRows = dataRows.slice(0, 5);
    const width = Math.min(headers.length, 12);
    body.innerHTML = `${head(`Preview and map ${esc(w.imp.filename)}`, `${plural(Math.max(0, s.row_count - w.headerRow - 1), 'row')} found below the header${reviewRequired() ? '. Word tables need each record approved in the next step.' : '.'}`)}
      <div class="form-grid">
        ${sheets.length > 1 ? `<label class="field">Sheet<select class="input" data-sheet>${sheets.map((x, i) => `<option value="${i}" ${i === w.sheet ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>` : ''}
        <label class="field">Header row
          <select class="input" data-header>${s.rows.slice(0, 25).map((r, i) => `<option value="${i}" ${i === w.headerRow ? 'selected' : ''}>Row ${i + 1}: ${esc(r.filter(Boolean).slice(0, 3).join(', ').slice(0, 60) || 'empty')}</option>`).join('')}</select>
          <span class="hint">We picked the row that looks most like column names.</span>
        </label>
      </div>
      <div>
        <h3 style="font-size:15px;margin-bottom:8px">Preview</h3>
        <div class="table-wrap card" style="box-shadow:none"><table class="data" style="font-size:13px">
          <thead><tr>${headers.slice(0, width).map(h => `<th>${esc(h || '—')}</th>`).join('')}${headers.length > width ? `<th>+${headers.length - width} more</th>` : ''}</tr></thead>
          <tbody>${previewRows.map(r => `<tr style="cursor:default">${r.slice(0, width).map(c => `<td class="sub" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c)}</td>`).join('')}${headers.length > width ? '<td></td>' : ''}</tr>`).join('')}</tbody>
        </table></div>
      </div>
      <div>
        <h3 style="font-size:15px;margin-bottom:8px">Column mapping</h3>
        <div class="table-wrap"><table class="data map-table"><thead><tr><th>Column in your file</th><th>Sample values</th><th>Import as</th></tr></thead>
          <tbody>${headers.map((h, i) => `<tr style="cursor:default"><td class="name">${esc(h || `Column ${i + 1}`)}</td><td><div class="sample">${esc(samples[i] || '—')}</div></td>
            <td style="min-width:220px"><select class="input input-sm" data-map="${i}">${opts(w.mapping[i])}</select></td></tr>`).join('')}</tbody></table></div>
        <p class="hint" style="margin-top:8px">Columns you don’t import are kept with the lead as extra details. Full name and LinkedIn URL are required.</p>
      </div>
      <p class="form-error" role="alert" data-err>${esc(error)}</p>
      <div class="modal-actions"><button class="btn" data-back>Choose another file</button><button class="btn btn-primary" data-next>Check records</button></div>`;
    body.querySelector('[data-sheet]')?.addEventListener('change', (e) => { w.sheet = Number(e.target.value); const sh = sheets[w.sheet]; w.headerRow = sh.header_row; w.mapping = [...sh.mapping]; renderMap(); });
    body.querySelector('[data-header]').onchange = async (e) => {
      w.headerRow = Number(e.target.value);
      try { ({ mapping: w.mapping } = await api(`/api/imports/${w.imp.id}/suggest`, { method: 'POST', body: { sheet: w.sheet, header_row: w.headerRow } })); } catch (err) { toastError(err); }
      renderMap();
    };
    body.querySelectorAll('[data-map]').forEach(sel => sel.onchange = () => {
      const i = Number(sel.dataset.map);
      if (sel.value) w.mapping = w.mapping.map((k, j) => (j !== i && k === sel.value ? '' : k));
      w.mapping[i] = sel.value;
      renderMap();
    });
    body.querySelector('[data-back]').onclick = () => { api(`/api/imports/${w.imp.id}/cancel`, { method: 'POST' }).catch(() => {}); w.imp = null; w.step = 'upload'; render(); };
    body.querySelector('[data-next]').onclick = async () => {
      try { w.overrides = {}; w.include = null; await validate(); w.step = 'review'; render(); } catch (e) { renderMap(e.message); }
    };
  }

  function reqBody(extra = {}) {
    const b = isDoc()
      ? { mode: 'candidates', records: w.records }
      : { sheet: w.sheet, header_row: w.headerRow, mapping: w.mapping, overrides: w.overrides };
    return { ...b, ...extra };
  }

  async function validate() {
    const res = await api(`/api/imports/${w.imp.id}/validate`, { method: 'POST', body: reqBody({ include: [] }) });
    const first = w.results === null || w.include === null;
    const wasReady = new Set((w.results || []).filter(r => r.state === 'ready').map(r => r.index));
    const auto = !(reviewRequired() || isDoc());
    w.results = res.results; w.counts = res.counts;
    if (first) w.include = new Set(auto ? res.results.filter(r => r.state === 'ready').map(r => r.index) : []);
    else for (const r of res.results) {
      if (r.state !== 'ready') w.include.delete(r.index);
      else if (auto && !wasReady.has(r.index)) w.include.add(r.index); // a corrected spreadsheet row is included again
    }
  }

  // ---------- Review ----------
  function renderReview(error = '') {
    const c = w.counts;
    const flagged = w.results.filter(r => r.state === 'ready' && r.warnings.length).length;
    const approvedCount = w.results.filter(r => r.state === 'ready' && w.include.has(r.index)).length;
    const assistants = (ctx.state.users || []).filter(u => u.role === 'assistant' && u.active);
    body.innerHTML = `${head(`Review ${esc(w.imp.filename)}`, isDoc() ? 'These are possible leads found in the document. Check each one, fill in or correct details, then approve the ones to add.' : 'Duplicates are skipped. Fix any record that needs correction, or leave it out.')}
      <div class="summary-grid">
        <div class="s"><b>${c.ready}</b><span>Ready to add</span></div>
        <div class="s"><b>${c.duplicate}</b><span>Duplicates, will be skipped</span></div>
        <div class="s"><b>${c.error}</b><span>Need correction</span></div>
        <div class="s"><b>${flagged}</b><span>Ready, with missing or unclear details</span></div>
      </div>
      <div class="toolbar" style="margin:0">
        <button class="btn btn-sm" data-all>Approve all ready</button>
        <button class="btn btn-sm btn-ghost" data-none>Clear approvals</button>
        <span class="grow"></span>
        ${ctx.me.role === 'owner' ? `<label class="field" style="grid-auto-flow:column;align-items:center;gap:8px">Assign new leads to
          <select class="input input-sm" data-assign style="width:auto"><option value="">Unassigned</option>${assistants.map(a => `<option value="${a.id}" ${String(a.id) === w.assignTo ? 'selected' : ''}>${esc(a.display_name)}</option>`).join('')}</select></label>` : '<span class="muted small">New leads are assigned to you.</span>'}
      </div>
      <div class="review-list">${w.results.map(rowHtml).join('') || '<p class="muted">No records found.</p>'}</div>
      <p class="form-error" role="alert" data-err>${esc(error)}</p>
      <div class="modal-actions">
        ${!isDoc() ? '<button class="btn" data-back>Back to mapping</button>' : ''}
        <button class="btn" data-recheck>Re-check edits</button>
        <button class="btn btn-primary" data-commit ${approvedCount ? '' : 'disabled'}>Add ${plural(approvedCount, 'lead')}</button>
      </div>`;
    body.querySelector('[data-all]').onclick = () => { w.results.filter(r => r.state === 'ready').forEach(r => w.include.add(r.index)); renderReview(); };
    body.querySelector('[data-none]').onclick = () => { w.include.clear(); renderReview(); };
    body.querySelector('[data-assign]')?.addEventListener('change', (e) => { w.assignTo = e.target.value; });
    body.querySelector('[data-back]')?.addEventListener('click', () => { w.step = 'map'; render(); });
    body.querySelectorAll('[data-inc]').forEach(cb => cb.onchange = () => { const i = Number(cb.dataset.inc); if (cb.checked) w.include.add(i); else w.include.delete(i); renderReviewCounts(); });
    body.querySelectorAll('[data-fix]').forEach(inp => inp.oninput = () => {
      const i = Number(inp.dataset.fix), k = inp.dataset.field;
      if (isDoc()) w.records[i][k] = inp.value;
      else { w.overrides[i] = { ...(w.overrides[i] || {}), [k]: inp.value }; }
    });
    body.querySelector('[data-recheck]').onclick = async () => { try { await validate(); renderReview(); } catch (e) { renderReview(e.message); } };
    body.querySelector('[data-commit]').onclick = commit;
  }
  function renderReviewCounts() {
    const n = w.results.filter(r => r.state === 'ready' && w.include.has(r.index)).length;
    const btn = body.querySelector('[data-commit]');
    btn.textContent = `Add ${plural(n, 'lead')}`; btn.disabled = !n;
  }

  function rowHtml(r) {
    const l = r.lead;
    const raw = isDoc() ? w.records[r.index] : { ...r.raw, ...(w.overrides[r.index] || {}) };
    const cls = r.state === 'duplicate' ? 'dup' : r.state === 'error' ? 'err' : '';
    const stateLabel = { ready: '<span class="status st-meeting">Ready</span>', duplicate: '<span class="status st-notfit">Duplicate</span>', error: '<span class="status st-overdue">Needs correction</span>' }[r.state];
    const editable = isDoc() || r.state === 'error';
    const fields = isDoc() ? DOC_FIELDS : DOC_FIELDS.filter(([k]) => ['full_name', 'linkedin_url'].includes(k));
    return `<div class="review-row ${cls}">
      <div class="rtop">
        ${r.state === 'ready' ? `<label class="check"><input type="checkbox" data-inc="${r.index}" ${w.include.has(r.index) ? 'checked' : ''}><span class="sr-only">Approve</span></label>` : ''}
        ${stateLabel}
        <b>${esc(l.full_name || raw.full_name || 'Unnamed record')}</b>
        <span class="muted small">${esc([l.title, l.company].filter(Boolean).join(' · '))}</span>
        <span class="faint xs" style="margin-left:auto">${r.row ? `${isDoc() ? 'Record' : 'Row'} ${r.row}` : ''}</span>
      </div>
      ${r.errors.length ? `<ul class="errs">${r.errors.map(e => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}
      ${r.warnings.length ? `<ul class="warns">${r.warnings.map(e => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}
      ${editable ? `<div class="fix">${fields.map(([k, label]) => `<label class="field xs">${label}<input class="input input-sm" data-fix="${r.index}" data-field="${k}" value="${esc(raw[k] || '')}"></label>`).join('')}</div>` : ''}
      ${isDoc() && raw._context ? `<div class="ctx" aria-label="Text from the document">${esc(raw._context)}</div>` : ''}
    </div>`;
  }

  async function commit() {
    const btn = body.querySelector('[data-commit]');
    btn.disabled = true; btn.textContent = 'Adding…';
    try {
      const res = await api(`/api/imports/${w.imp.id}/commit`, { method: 'POST', body: reqBody({ include: [...w.include], assign_to: w.assignTo || null }) });
      w.summary = res.summary; w.step = 'done'; render();
      toast(`${plural(res.summary.added, 'lead')} added.`);
    } catch (e) { renderReview(e.message); }
  }

  // ---------- Done ----------
  function renderDone() {
    const s = w.summary;
    const list = (items) => items.map(i => `<li>${esc(i.name)}${i.row ? ` <span class="faint">(row ${i.row})</span>` : ''}: ${esc(i.reason)}</li>`).join('');
    body.innerHTML = `${head('Import summary', esc(w.imp.filename))}
      <div class="summary-grid">
        <div class="s"><b>${s.added}</b><span>Added</span></div>
        <div class="s"><b>${s.skipped}</b><span>Skipped</span></div>
        <div class="s"><b>${s.need_correction}</b><span>Need correction</span></div>
        <div class="s"><b>${s.flagged_gaps}</b><span>Added with missing details flagged</span></div>
      </div>
      ${s.duplicates.length || s.excluded.length ? `<div><h3 style="font-size:15px;margin-bottom:6px">Skipped</h3><ul class="small">${list([...s.duplicates, ...s.excluded])}</ul></div>` : ''}
      ${s.corrections.length ? `<div><h3 style="font-size:15px;margin-bottom:6px">Need correction (not added)</h3><ul class="small">${list(s.corrections)}</ul><p class="hint">Fix these in the file and upload it again. Leads already added will be detected as duplicates.</p></div>` : ''}
      <p class="muted small">New leads are live in both portals now.</p>
      <div class="modal-actions"><button class="btn" data-again>Upload another file</button><button class="btn btn-primary" data-close>Done</button></div>`;
    body.querySelector('[data-close]').onclick = () => m.close();
    body.querySelector('[data-again]').onclick = () => { Object.assign(w, { step: 'upload', imp: null, results: null, records: null, include: null, overrides: {}, summary: null }); render(); };
  }

  render();
  if (file) upload(file);
}

export async function importHistory(ctx, { title = 'Import history' } = {}) {
  let imports = [];
  try { ({ imports } = await api('/api/imports')); } catch (e) { return ''; }
  const rows = imports.filter(i => i.status !== 'preview');
  if (!rows.length) return `<div class="section-head"><h2>${esc(title)}</h2></div><p class="muted small">No files uploaded yet.</p>`;
  return `<div class="section-head"><h2>${esc(title)}</h2></div>
    <div class="card"><div class="table-wrap"><table class="data responsive"><thead><tr><th>File</th><th>Uploaded by</th><th>When</th><th class="num">Added</th><th class="num">Skipped</th><th class="num">Need correction</th><th class="num">Flagged</th></tr></thead>
    <tbody>${rows.map(i => `<tr style="cursor:default">
      <td data-label="File"><span class="name">${esc(i.filename)}</span>${i.status === 'cancelled' ? ' <span class="chip">Cancelled</span>' : ''}</td>
      <td data-label="By">${esc(i.user_name)}</td><td data-label="When">${esc(fmtFull(i.completed_at || i.created_at))}</td>
      <td class="num" data-label="Added">${i.summary?.added ?? '—'}</td><td class="num" data-label="Skipped">${i.summary?.skipped ?? '—'}</td>
      <td class="num" data-label="Correction">${i.summary?.need_correction ?? '—'}</td><td class="num" data-label="Flagged">${i.summary?.flagged_gaps ?? '—'}</td></tr>`).join('')}</tbody></table></div></div>`;
}
