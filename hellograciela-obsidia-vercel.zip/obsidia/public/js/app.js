// HelloGraciela Obsidia — app shell, sign-in, live sync and notifications.
import { api, esc, ICON, ago, fmtFull, initials, toast, toastError, plural } from './util.js';
import { assistantView } from './assistant.js';
import { ownerView, OWNER_TABS } from './owner.js';

const app = document.getElementById('app');
let ctx = null;
let pollTimer = null;

// ---------------- Sign in ----------------
function renderLogin(message = '') {
  stopLive();
  document.title = 'Sign in · HelloGraciela Obsidia';
  app.innerHTML = `
    <main class="login">
      <div class="login-card">
        <img class="logo" src="/assets/logo.png" alt="HelloGraciela Digital Studio">
        <p class="product">Obsidia</p>
        <p class="lede">Lead generation workspace. Sign in to continue.</p>
        <form novalidate>
          <label class="field">Username <input class="input" name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required autofocus></label>
          <label class="field">Password <input class="input" name="password" type="password" autocomplete="current-password" required></label>
          <p class="form-error" role="alert" data-err>${esc(message)}</p>
          <button class="btn btn-primary btn-lg btn-block" type="submit">Sign in</button>
        </form>
        <p class="login-foot">Owner and assistant accounts sign in here. Access is set by the owner.</p>
      </div>
    </main>`;
  const form = app.querySelector('form');
  form.onsubmit = async (e) => {
    e.preventDefault();
    const err = form.querySelector('[data-err]');
    err.textContent = '';
    if (!form.username.value.trim() || !form.password.value) { err.textContent = 'Enter your username and password.'; return; }
    const btn = form.querySelector('button');
    btn.disabled = true; btn.textContent = 'Signing in…';
    try {
      await api('/api/auth/login', { method: 'POST', body: { username: form.username.value, password: form.password.value } });
      await boot();
    } catch (ex) {
      err.textContent = ex.message;
      form.password.value = '';
      form.password.focus();
      btn.disabled = false; btn.textContent = 'Sign in';
    }
  };
}

async function signOut() {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
  ctx = null;
  history.replaceState(null, '', '/');
  renderLogin();
}

// ---------------- Boot ----------------
async function boot() {
  let me;
  try { me = await api('/api/me'); } catch (e) { return renderLogin(e.status === 401 ? '' : e.message); }
  ctx = {
    me: me.user, constants: me.constants, production: me.production, setupMode: false,
    initialInUse: me.initial_credentials_in_use || [],
    state: { leads: [], users: [], progress: null, notifications: [], unread: 0 },
    reloadMe,
  };
  if (me.setup_required) {
    if (ctx.me.role === 'assistant') return renderPaused();
    ctx.setupMode = true;
  }
  await loadAll();
  mountShell();
  if (!ctx.setupMode) startLive();
}

async function reloadMe() {
  const me = await api('/api/me');
  ctx.initialInUse = me.initial_credentials_in_use || [];
  const wasSetup = ctx.setupMode;
  ctx.me = me.user;
  if (wasSetup && !me.setup_required) { await boot(); toast('Setup complete. Obsidia is ready.'); return; }
  renderBanner();
}

function renderPaused() {
  app.innerHTML = `<main class="login"><div class="login-card" style="text-align:center">
    <img class="logo" src="/assets/logo.png" alt="HelloGraciela Digital Studio">
    <p class="product">Obsidia</p>
    <p class="lede">Your access opens once the owner finishes account setup. Check back soon.</p>
    <button class="btn btn-block" data-out>Sign out</button></div></main>`;
  app.querySelector('[data-out]').onclick = signOut;
}

async function loadAll() {
  const owner = ctx.me.role === 'owner';
  const jobs = [api('/api/users').then(r => { ctx.state.users = r.users; })];
  if (!ctx.setupMode) {
    jobs.push(api('/api/leads').then(r => { ctx.state.leads = r.leads; }));
    jobs.push(loadNotifications());
    if (!owner) jobs.push(api('/api/my-progress').then(r => { ctx.state.progress = r; }));
  }
  await Promise.all(jobs);
}
async function loadNotifications() {
  const r = await api('/api/notifications');
  ctx.state.notifications = r.notifications;
  ctx.state.unread = r.unread;
}

// ---------------- Shell ----------------
let view = null;
function mountShell() {
  const owner = ctx.me.role === 'owner';
  document.title = `${owner ? 'Owner' : 'Assistant'} · HelloGraciela Obsidia`;
  app.innerHTML = `
    <header class="topbar">
      <div class="topbar-inner">
        <a class="brand" href="${owner ? '#/overview' : '#'}" aria-label="HelloGraciela Obsidia home">
          <img src="/assets/wordmark.png" alt="HelloGraciela"><span class="product">Obsidia</span>
        </a>
        <span class="portal-chip">${owner ? 'Owner portal' : 'Assistant portal'}</span>
        <span class="spacer"></span>
        <span class="live off" data-live title="Connecting"><i></i><span>Connecting</span></span>
        ${ctx.setupMode ? '' : `<div class="user-menu" data-notif-wrap>
          <button class="icon-btn" data-notif aria-label="Notifications" aria-haspopup="true" aria-expanded="false">${ICON.bell}<span class="badge" data-badge hidden></span></button>
        </div>`}
        <div class="user-menu" data-menu-wrap>
          <button class="icon-btn" data-menu aria-label="Account menu" aria-haspopup="true" aria-expanded="false"><span class="avatar">${esc(initials(ctx.me.display_name))}</span></button>
        </div>
      </div>
      ${owner && !ctx.setupMode ? `<nav class="nav" aria-label="Owner sections">${OWNER_TABS.map(t => `<a href="#/${t.key}" data-tab="${t.key}">${esc(t.label)}${t.key === 'followups' ? '<span class="count" data-due-count hidden></span>' : ''}</a>`).join('')}</nav>` : ''}
    </header>
    <div data-banner></div>
    <main data-main></main>`;
  view = owner ? ownerView(ctx) : assistantView(ctx);
  app.querySelector('[data-main]').appendChild(view.el);
  app.querySelector('[data-menu]').onclick = toggleMenu;
  app.querySelector('[data-notif]')?.addEventListener('click', toggleNotifications);
  renderBanner();
  renderBadge();
  if (owner) {
    if (ctx.setupMode) view.route('settings');
    else { window.onhashchange = route; route(); }
  } else {
    window.onhashchange = null;
    view.refresh(null);
  }
}

function route() {
  const tab = (location.hash.match(/^#\/(\w+)/) || [])[1] || 'overview';
  app.querySelectorAll('[data-tab]').forEach(a => a.classList.toggle('active', a.dataset.tab === tab));
  app.querySelectorAll('[data-tab]').forEach(a => a.setAttribute('aria-current', a.dataset.tab === tab ? 'page' : 'false'));
  view.route(tab).then(() => view.refresh(null));
  window.scrollTo(0, 0);
}

function renderBanner() {
  const el = app.querySelector('[data-banner]');
  if (!el) return;
  const list = ctx.initialInUse || [];
  if (ctx.me.role === 'owner' && list.length && !ctx.setupMode) {
    const who = [...new Set(list)].map(r => (r === 'owner' ? 'owner' : 'assistant')).join(' and ');
    el.innerHTML = `<div class="page" style="padding-bottom:0;padding-top:20px"><div class="banner" role="note"><span aria-hidden="true">⚠</span><div><strong>Initial passwords are still in use for the ${esc(who)} ${list.length > 1 ? 'accounts' : 'account'}.</strong> Change them in <a href="#/settings">Settings</a> before going live.${ctx.production ? '' : ' In production mode, Obsidia requires this before anyone can work.'}</div></div></div>`;
  } else el.innerHTML = '';
  const due = ctx.state.leads.filter(l => l.follow_up_overdue).length;
  const c = app.querySelector('[data-due-count]');
  if (c) { c.hidden = !due; c.textContent = due; c.title = `${plural(due, 'overdue follow-up')}`; }
}

function closePopovers() {
  app.querySelectorAll('.menu, .notif-panel').forEach(m => m.remove());
  app.querySelectorAll('[aria-expanded="true"][data-menu], [aria-expanded="true"][data-notif]').forEach(b => b.setAttribute('aria-expanded', 'false'));
}
document.addEventListener('click', (e) => {
  if (!e.target.closest('[data-menu-wrap], [data-notif-wrap]')) closePopovers();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePopovers(); });

function toggleMenu(e) {
  e.stopPropagation();
  const wrap = app.querySelector('[data-menu-wrap]');
  if (wrap.querySelector('.menu')) return closePopovers();
  closePopovers();
  wrap.insertAdjacentHTML('beforeend', `<div class="menu" role="menu">
    <div class="who"><b>${esc(ctx.me.display_name)}</b><div class="muted small">@${esc(ctx.me.username)} · ${ctx.me.role === 'owner' ? 'Owner' : 'Assistant'}</div></div>
    ${ctx.me.role === 'owner' && !ctx.setupMode ? '<button role="menuitem" data-go="settings">Settings</button>' : ''}
    <button role="menuitem" data-signout>Sign out</button></div>`);
  wrap.querySelector('[data-menu]').setAttribute('aria-expanded', 'true');
  wrap.querySelector('[data-signout]').onclick = signOut;
  wrap.querySelector('[data-go]')?.addEventListener('click', () => { location.hash = '#/settings'; closePopovers(); });
}

// ---------------- Notifications ----------------
const NOTIF_ICON = { reply: '💬', meeting: '📅', target: '🎯', overdue: '⏰', import: '📄', assigned: '📋' };
function renderBadge() {
  const b = app.querySelector('[data-badge]');
  if (!b) return;
  b.hidden = !ctx.state.unread;
  b.textContent = ctx.state.unread > 99 ? '99+' : ctx.state.unread;
  app.querySelector('[data-notif]').setAttribute('aria-label', `Notifications${ctx.state.unread ? `, ${ctx.state.unread} unread` : ''}`);
}
function notifPanelHtml() {
  const list = ctx.state.notifications;
  return `<div class="notif-panel" role="dialog" aria-label="Notifications">
    <div class="notif-head"><h3>Notifications</h3>${ctx.state.unread ? '<button class="link-btn small" data-readall>Mark all as read</button>' : '<span class="muted small">All caught up</span>'}</div>
    <ul class="notif-list">${list.length ? list.map(n => `<li class="${n.read_at ? 'read' : ''}"><button data-nid="${n.id}">
      <span class="ic" aria-hidden="true">${NOTIF_ICON[n.type] || '•'}</span>
      <span><div class="t">${esc(n.title)}</div>${n.body ? `<div class="b">${esc(n.body)}</div>` : ''}<div class="when" title="${esc(fmtFull(n.created_at))}">${esc(ago(n.created_at))} · ${esc(fmtFull(n.created_at))}</div></span>
      <span class="unread-dot" aria-label="${n.read_at ? 'Read' : 'Unread'}"></span></button></li>`).join('') : '<li class="muted small" style="padding:24px 16px">Nothing yet. Replies, booked meetings, completed targets, overdue follow-ups and finished imports show up here.</li>'}</ul></div>`;
}
function toggleNotifications(e) {
  e.stopPropagation();
  const wrap = app.querySelector('[data-notif-wrap]');
  if (wrap.querySelector('.notif-panel')) return closePopovers();
  closePopovers();
  wrap.insertAdjacentHTML('beforeend', notifPanelHtml());
  wrap.querySelector('[data-notif]').setAttribute('aria-expanded', 'true');
  bindNotifPanel(wrap);
}
function bindNotifPanel(wrap) {
  const panel = wrap.querySelector('.notif-panel');
  panel.querySelector('[data-readall]')?.addEventListener('click', async () => {
    try { await api('/api/notifications/read', { method: 'POST', body: { all: true } }); await loadNotifications(); refreshNotifPanel(); } catch (err) { toastError(err); }
  });
  panel.querySelectorAll('[data-nid]').forEach(b => b.onclick = async () => {
    const n = ctx.state.notifications.find(x => x.id === Number(b.dataset.nid));
    if (!n.read_at) api('/api/notifications/read', { method: 'POST', body: { ids: [n.id] } }).catch(() => {});
    n.read_at = new Date().toISOString();
    ctx.state.unread = Math.max(0, ctx.state.unread - 1);
    closePopovers(); renderBadge();
    if (n.lead_id) {
      view.focusLead(n.lead_id);
    } else if (n.import_id && ctx.me.role === 'owner') location.hash = '#/imports';
  });
}
function refreshNotifPanel() {
  renderBadge();
  const wrap = app.querySelector('[data-notif-wrap]');
  const panel = wrap?.querySelector('.notif-panel');
  if (!panel) return;
  const scroll = panel.querySelector('.notif-list').scrollTop;
  panel.remove();
  wrap.insertAdjacentHTML('beforeend', notifPanelHtml());
  wrap.querySelector('.notif-list').scrollTop = scroll;
  bindNotifPanel(wrap);
}

// ---------------- Live sync ----------------
let pending = new Set();
let flushTimer = null;
let lastUnread = 0;
function queue(scopes) {
  scopes.forEach(s => pending.add(s));
  clearTimeout(flushTimer);
  flushTimer = setTimeout(flush, 120);
}
async function flush() {
  if (!ctx || !view) return;
  const scopes = pending; pending = new Set();
  const owner = ctx.me.role === 'owner';
  const jobs = [];
  const full = scopes.has('*');
  try {
    if (full || scopes.has('leads')) jobs.push(api('/api/leads').then(r => { ctx.state.leads = r.leads; }));
    if (full || scopes.has('notifications')) jobs.push(loadNotifications());
    if (full || scopes.has('users')) jobs.push(api('/api/users').then(r => { ctx.state.users = r.users; }));
    if (!owner && (full || scopes.has('metrics') || scopes.has('users') || scopes.has('leads'))) jobs.push(api('/api/my-progress').then(r => { ctx.state.progress = r; }));
    await Promise.all(jobs);
  } catch (e) { if (e.status !== 401) console.warn(e); return; }
  if (ctx.state.unread > lastUnread && !full) {
    const newest = ctx.state.notifications.find(n => !n.read_at);
    if (newest) toast(newest.title, { action: 'View', onAction: () => app.querySelector('[data-notif]')?.click() });
  }
  lastUnread = ctx.state.unread;
  refreshNotifPanel();
  renderBanner();
  await view.refresh(full ? null : scopes);
}

function setLive(on) {
  const el = app.querySelector('[data-live]');
  if (!el) return;
  el.classList.toggle('off', !on);
  el.title = on ? 'Live: changes appear automatically' : 'Reconnecting…';
  el.querySelector('span').textContent = on ? 'Live' : 'Reconnecting';
}

// Live sync: poll a tiny change log. Works on serverless hosts (Vercel) where open connections aren't kept.
let cursor = null;
let pollRun = 0;
let failures = 0;
function startLive() {
  stopLive();
  lastUnread = ctx.state.unread;
  const run = ++pollRun;
  cursor = null;
  const tick = async () => {
    if (run !== pollRun || !ctx) return;
    try {
      const r = await api(`/api/changes${cursor === null ? '' : `?after=${cursor}`}`);
      if (run !== pollRun) return;
      if (failures) queue(['*']); // catch up after a connection problem
      failures = 0;
      setLive(true);
      if (cursor !== null && r.scopes.length) queue(r.scopes);
      cursor = r.latest;
    } catch (e) {
      failures++;
      setLive(false);
      if (e.status === 401 || e.status === 403) return; // signed out or setup required; handled elsewhere
    }
    const delay = document.visibilityState === 'visible' ? (failures ? Math.min(15000, 2000 * failures) : 2000) : 15000;
    pollTimer = setTimeout(tick, delay);
  };
  tick();
}
function stopLive() {
  pollRun++;
  clearTimeout(pollTimer); pollTimer = null;
}

window.addEventListener('obsidia:signedout', () => { if (ctx) { ctx = null; renderLogin('Your session ended. Please sign in again.'); } });
window.addEventListener('obsidia:setup', () => { if (ctx && !ctx.setupMode) boot(); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && ctx && !ctx.setupMode) { queue(['*']); startLive(); } });
// Keep relative times and overdue flags fresh.
setInterval(() => { if (ctx && !ctx.setupMode && document.visibilityState === 'visible') queue(['leads']); }, 60000);

boot().catch(e => { console.error(e); toastError(e); });
