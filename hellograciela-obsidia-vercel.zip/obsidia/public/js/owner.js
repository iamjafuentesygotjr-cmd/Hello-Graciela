// Owner portal: live dashboard, lead database, follow-ups, imports, team targets and settings.
import {
  api, esc, fmtTime, fmtFull, ago, patchList, ICON, toast, toastError, safeUrl, confirmDialog, plural, copyText, initials,
} from './util.js';
import {
  statusPill, fitChip, location, gapChips, trackOpen, statusModal, followupModal, timeline, describeActivity, copyNote, QUICK,
} from './leads.js';
import { barChart, dayLabels, weekLabels, bindTooltips } from './charts.js';
import { openImportWizard, importHistory } from './imports.js';

export const OWNER_TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'leads', label: 'Leads' },
  { key: 'followups', label: 'Follow-ups' },
  { key: 'imports', label: 'Imports' },
  { key: 'team', label: 'Team and targets' },
  { key: 'settings', label: 'Settings' },
];

export function ownerView(ctx) {
  const ui = {
    tab: 'overview', metricsFor: '', trend: 'daily', table: false,
    q: '', fStatus: '', fFit: '', fAssigned: '', selected: new Set(),
    drawer: null, feed: [], metrics: null, settings: null, teamMetrics: {},
  };
  const root = document.createElement('div');
  root.className = 'page';
  bindTooltips(root);
  const getLead = (id) => ctx.state.leads.find(l => l.id === id);
  const assistants = () => (ctx.state.users || []).filter(u => u.role === 'assistant');

  // ---------------- Overview ----------------
  function overview() {
    const s = ui.metrics;
    const opts = `<option value="">All assistants</option>${assistants().map(a => `<option value="${a.id}" ${String(a.id) === ui.metricsFor ? 'selected' : ''}>${esc(a.display_name)}</option>`).join('')}`;
    if (!s) return `<p class="muted">Loading…</p>`;
    const cards = s.definitions.map(d => {
      const m = s.metrics[d.key], t = s.targets[d.key] || 0;
      const pct = t ? Math.min(100, Math.round(m.today / t * 100)) : 0;
      const done = t && m.today >= t;
      return `<div class="card metric-card">
        <div class="label">${esc(d.label)}</div>
        <div class="value"><b>${m.today}</b><span>of ${t || '—'} today</span></div>
        <div class="meter ${done ? 'done' : ''}" role="progressbar" aria-label="${esc(d.label)} against today’s target" aria-valuemin="0" aria-valuemax="${t}" aria-valuenow="${m.today}"><span style="width:${pct}%"></span></div>
        <div class="foot"><span>${t ? (done ? 'Target reached' : `${pct}% of target`) : 'No target set'}</span><span>This week <b>${m.week}</b> · All time <b>${m.total}</b></span></div>
      </div>`;
    }).join('');
    const keys = ui.trend === 'daily' ? s.dayKeys : s.weekKeys;
    const labels = ui.trend === 'daily' ? dayLabels(keys) : weekLabels(keys);
    const series = (k) => keys.map(x => (ui.trend === 'daily' ? s.metrics[k].daily[x] : s.metrics[k].weekly[x]) || 0);
    const charts = ui.table
      ? `<div class="table-wrap"><table class="data"><thead><tr><th>${ui.trend === 'daily' ? 'Day' : 'Week'}</th>${s.definitions.map(d => `<th class="num">${esc(d.short)}</th>`).join('')}</tr></thead>
         <tbody>${keys.map((k, i) => `<tr style="cursor:default"><td>${esc(labels[i])}</td>${s.definitions.map(d => `<td class="num">${series(d.key)[i]}</td>`).join('')}</tr>`).reverse().join('')}</tbody></table></div>`
      : `<div class="charts">${s.definitions.map(d => {
          const vals = series(d.key);
          return `<figure class="chart" style="margin:0"><div class="ch-head"><figcaption class="ch-title">${esc(d.label)}</figcaption><span class="ch-total">${vals.reduce((a, b) => a + b, 0)} in ${ui.trend === 'daily' ? '14 days' : '8 weeks'}</span></div>
            ${barChart({ keys, values: vals, labels, target: ui.trend === 'daily' ? s.targets[d.key] : 0, todayKey: ui.trend === 'daily' ? s.today : keys[keys.length - 1] })}</figure>`;
        }).join('')}</div>`;
    const due = ctx.state.leads.filter(l => l.status === 'Follow-up due').sort((a, b) => (b.follow_up_overdue - a.follow_up_overdue) || String(a.follow_up_due_at).localeCompare(String(b.follow_up_due_at)));
    const pipeline = ctx.constants.statuses.map(st => [st, ctx.state.leads.filter(l => l.status === st && (!ui.metricsFor || String(l.assigned_to) === ui.metricsFor)).length]);
    const pmax = Math.max(1, ...pipeline.map(p => p[1]));
    return `
      <div class="page-head">
        <div><h1>Today at a <em>glance</em></h1>
          <p class="sub">${esc(new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }))} · Days run on ${esc(s.timezone.replace(/_/g, ' '))} time</p></div>
        <div class="toolbar" style="margin:0">
          <label><span class="sr-only">Show activity for</span><select class="input" data-metrics-for style="width:auto">${opts}</select></label>
          <button class="btn btn-dark" data-act="import">${ICON.upload} Add leads</button>
        </div>
      </div>
      <div class="grid grid-3 metric-grid">${cards}</div>
      <p class="hint" style="margin-top:10px">Opening a profile only counts as a profile opened. Requests, acceptances, replies, follow-ups and meetings count only when someone confirms them. Each lead counts once per milestone.</p>
      <section class="section card card-pad">
        <div class="card-title"><h2>Trends</h2>
          <div class="toolbar" style="margin:0">
            <div class="seg" role="group" aria-label="Trend period">
              <button data-trend="daily" aria-pressed="${ui.trend === 'daily'}">Daily</button><button data-trend="weekly" aria-pressed="${ui.trend === 'weekly'}">Weekly</button>
            </div>
            <button class="btn btn-sm btn-ghost" data-toggle-table>${ui.table ? 'Show charts' : 'Show as table'}</button>
          </div></div>
        ${charts}
        ${!ui.table && ui.trend === 'daily' ? '<p class="hint" style="margin-top:10px">Dashed line: daily target. Hover or focus a bar for the exact count.</p>' : ''}
      </section>
      <div class="grid grid-2 section">
        <section class="card card-pad"><div class="card-title"><h2>Follow-ups needing attention</h2><a href="#/followups" class="small">See all</a></div>
          ${due.length ? due.slice(0, 6).map(followRow).join('') : '<p class="muted small">No follow-ups due. Leads marked Follow-up due will appear here.</p>'}</section>
        <section class="card card-pad"><div class="card-title"><h2>Live activity</h2><span class="live"><i></i><span>Updating live</span></span></div>
          ${feed()}</section>
      </div>
      <section class="section card card-pad"><div class="card-title"><h2>Pipeline</h2><span class="muted small">${plural(ctx.state.leads.length, 'lead')} in the database</span></div>
        <div class="pipeline">${pipeline.map(([st, n]) => `<div class="prow"><span>${esc(st)}</span><div class="pbar"><span style="width:${n / pmax * 100}%"></span></div><span class="pnum">${n}</span></div>`).join('')}</div>
      </section>`;
  }

  function followRow(l) {
    return `<div class="followup-item">
      <div><button class="link-btn" data-open-lead="${l.id}" style="color:var(--obsidian);font-weight:600">${esc(l.full_name)}</button>
        <div class="small muted">${esc(l.company || '')}${l.assigned_name ? ` · ${esc(l.assigned_name)}` : ' · Unassigned'}</div></div>
      <span class="status ${l.follow_up_overdue ? 'st-overdue' : 'st-followup'}">${l.follow_up_overdue ? 'Overdue' : 'Due'} ${esc(fmtTime(l.follow_up_due_at))}</span>
    </div>`;
  }

  const FEED_ICON = { profile_opened: ['↗', 'k'], status_change: ['●', 'k'], followup_sent: ['↺', 'w'], imported: ['+', ''], assigned: ['→', ''], note_copied: ['⧉', ''], undo: ['↶', 'w'], note_edited: ['✎', ''], edited: ['✎', ''] };
  function feed() {
    if (!ui.feed.length) return '<p class="muted small">Activity from both portals appears here as it happens.</p>';
    // Collapse runs of imported rows from the same file into one line.
    const items = [];
    for (const a of ui.feed) {
      const prev = items[items.length - 1];
      if (a.type === 'imported' && prev?.type === 'imported' && prev.detail?.file === a.detail?.file && prev.user_id === a.user_id) { prev._count = (prev._count || 1) + 1; continue; }
      items.push({ ...a });
    }
    return `<ul class="feed">${items.slice(0, 40).map(a => {
      if (a._count > 1) {
        return `<li><span class="dot" aria-hidden="true">+</span><div><div><b>${esc(a.user_name)}</b> · imported ${a._count} leads</div>
          <div class="small">From ${esc(a.detail?.file || 'a file')}</div><div class="when" title="${esc(fmtFull(a.created_at))}">${esc(ago(a.created_at))} · ${esc(fmtTime(a.created_at))}</div></div></li>`;
      }
      const [ic, cls] = FEED_ICON[a.type] || ['•', ''];
      const good = a.to_status === 'Meeting booked' || a.to_status === 'Replied';
      return `<li><span class="dot ${good ? 'g' : cls}" aria-hidden="true">${ic}</span><div>
        <div><b>${esc(a.user_name)}</b> · ${a.lead_name ? `<button class="link-btn" data-open-lead="${a.lead_id}">${esc(a.lead_name)}</button>` : 'a deleted lead'}</div>
        <div class="small">${esc(describeActivity(a))}${a.voided ? ' (undone)' : ''}</div>
        <div class="when" title="${esc(fmtFull(a.created_at))}">${esc(ago(a.created_at))} · ${esc(fmtTime(a.created_at))}</div></div></li>`;
    }).join('')}</ul>`;
  }

  // ---------------- Leads ----------------
  function leadsTab() {
    const countries = [...new Set(ctx.state.leads.map(l => l.country).filter(Boolean))].sort();
    return `
      <div class="page-head"><div><h1>Lead <em>database</em></h1><p class="sub" data-lead-count></p></div>
        <button class="btn btn-dark" data-act="import">${ICON.upload} Add leads</button></div>
      <div class="toolbar">
        <label class="search grow"><span class="sr-only">Search</span>${ICON.search}<input class="input" type="search" data-q placeholder="Search name, company, category or location" value="${esc(ui.q)}"></label>
        <select class="input" style="width:auto" data-f="fStatus" aria-label="Filter by status"><option value="">All statuses</option>${ctx.constants.statuses.map(s => `<option ${s === ui.fStatus ? 'selected' : ''}>${esc(s)}</option>`).join('')}<option value="__overdue" ${ui.fStatus === '__overdue' ? 'selected' : ''}>Follow-up overdue</option></select>
        <select class="input" style="width:auto" data-f="fFit" aria-label="Filter by fit"><option value="">All fits</option>${ctx.constants.fits.map(s => `<option ${s === ui.fFit ? 'selected' : ''}>${esc(s)}</option>`).join('')}<option value="__none" ${ui.fFit === '__none' ? 'selected' : ''}>Not classified</option></select>
        <select class="input" style="width:auto" data-f="fAssigned" aria-label="Filter by assistant"><option value="">Everyone</option><option value="__none" ${ui.fAssigned === '__none' ? 'selected' : ''}>Unassigned</option>${assistants().map(a => `<option value="${a.id}" ${String(a.id) === ui.fAssigned ? 'selected' : ''}>${esc(a.display_name)}</option>`).join('')}</select>
        ${countries.length > 1 ? `<select class="input" style="width:auto" data-f="fCountry" aria-label="Filter by country"><option value="">All countries</option>${countries.map(c => `<option ${c === ui.fCountry ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select>` : ''}
      </div>
      <div class="card"><div class="table-wrap"><table class="data responsive">
        <thead><tr><th style="width:36px"><input type="checkbox" data-all aria-label="Select all visible"></th><th>Name</th><th>Company</th><th>Location</th><th>Fit</th><th>Status</th><th>Assigned to</th><th>Last update</th></tr></thead>
        <tbody data-rows></tbody></table></div><div data-lead-empty></div></div>
      <div data-bulk></div>`;
  }
  function filteredLeads() {
    const q = ui.q.trim().toLowerCase();
    return ctx.state.leads.filter(l =>
      (!q || [l.full_name, l.company, l.title, l.brand_category, l.city, l.country, l.business_email].join(' ').toLowerCase().includes(q))
      && (!ui.fStatus || (ui.fStatus === '__overdue' ? l.follow_up_overdue : l.status === ui.fStatus))
      && (!ui.fFit || (ui.fFit === '__none' ? !l.fit : l.fit === ui.fFit))
      && (!ui.fAssigned || (ui.fAssigned === '__none' ? !l.assigned_to : String(l.assigned_to) === ui.fAssigned))
      && (!ui.fCountry || l.country === ui.fCountry));
  }
  function leadRow(l) {
    return `<tr data-row="${l.id}" class="${ui.selected.has(l.id) ? 'sel' : ''}">
      <td class="cb"><input type="checkbox" data-sel="${l.id}" ${ui.selected.has(l.id) ? 'checked' : ''} aria-label="Select ${esc(l.full_name)}"></td>
      <td data-label="Name"><div class="name">${esc(l.full_name)}</div><div class="sub">${esc(l.title || '')}</div></td>
      <td data-label="Company"><div>${esc(l.company || '—')}</div><div class="sub">${esc(l.brand_category || '')}</div></td>
      <td data-label="Location">${esc(location(l) || '—')}</td>
      <td data-label="Fit">${fitChip(l)}</td>
      <td data-label="Status">${statusPill(l)}</td>
      <td data-label="Assigned">${esc(l.assigned_name || 'Unassigned')}</td>
      <td data-label="Updated" class="sub">${l.status_updated_at ? `${esc(ago(l.status_updated_at))}${l.status_updated_by_name ? ` · ${esc(l.status_updated_by_name)}` : ''}` : '—'}</td>
    </tr>`;
  }
  function renderLeadRows() {
    const tbody = root.querySelector('[data-rows]');
    if (!tbody) return;
    const items = filteredLeads();
    patchList(tbody, items, l => l.id, leadRow, el => el.contains(document.activeElement) && document.activeElement.tagName === 'SELECT');
    root.querySelector('[data-lead-count]').textContent = `${plural(ctx.state.leads.length, 'lead')} · ${items.length} shown`;
    root.querySelector('[data-lead-empty]').innerHTML = items.length ? '' : '<div class="empty"><h3>No leads match</h3><p>Try clearing a filter.</p></div>';
    const sel = [...ui.selected].filter(id => getLead(id));
    ui.selected = new Set(sel);
    const all = root.querySelector('[data-all]');
    if (all) all.checked = items.length > 0 && items.every(l => ui.selected.has(l.id));
    root.querySelector('[data-bulk]').innerHTML = sel.length ? `
      <div class="bulkbar"><b>${plural(sel.length, 'lead')} selected</b>
        <select class="input input-sm" data-bulk-to style="width:auto" aria-label="Assign to"><option value="">Unassign</option>${assistants().filter(a => a.active).map(a => `<option value="${a.id}">${esc(a.display_name)}</option>`).join('')}</select>
        <button class="btn btn-sm btn-primary" data-bulk-apply>Assign</button>
        <button class="btn btn-sm btn-ghost" style="color:#fff" data-bulk-clear>Clear selection</button></div>` : '';
    const first = root.querySelector('[data-bulk-to] option[value]:not([value=""])');
    if (first) first.selected = true;
  }

  // ---------------- Follow-ups ----------------
  function followupsTab() {
    const due = ctx.state.leads.filter(l => l.status === 'Follow-up due').sort((a, b) => (b.follow_up_overdue - a.follow_up_overdue) || String(a.follow_up_due_at).localeCompare(String(b.follow_up_due_at)));
    const overdue = due.filter(l => l.follow_up_overdue).length;
    return `<div class="page-head"><div><h1>Follow-<em>ups</em></h1><p class="sub">${plural(due.length, 'lead')} due · ${overdue} overdue</p></div></div>
      <div class="card">${due.length ? `<div class="table-wrap"><table class="data responsive"><thead><tr><th>Lead</th><th>Due</th><th>Last update</th><th>Assigned to</th><th></th></tr></thead><tbody>
        ${due.map(l => `<tr data-row="${l.id}">
          <td data-label="Lead"><div class="name">${esc(l.full_name)}</div><div class="sub">${esc([l.title, l.company].filter(Boolean).join(' · '))}</div></td>
          <td data-label="Due"><span class="status ${l.follow_up_overdue ? 'st-overdue' : 'st-followup'}">${l.follow_up_overdue ? 'Overdue' : 'Due'} ${esc(fmtFull(l.follow_up_due_at))}</span></td>
          <td data-label="Updated" class="sub">${esc(ago(l.status_updated_at))}${l.status_updated_by_name ? ` · ${esc(l.status_updated_by_name)}` : ''}</td>
          <td data-label="Assigned"><select class="input input-sm" data-reassign="${l.id}" aria-label="Reassign ${esc(l.full_name)}" style="width:auto"><option value="">Unassigned</option>${assistants().filter(a => a.active || a.id === l.assigned_to).map(a => `<option value="${a.id}" ${a.id === l.assigned_to ? 'selected' : ''}>${esc(a.display_name)}</option>`).join('')}</select></td>
          <td><button class="btn btn-sm" data-open-lead="${l.id}">Open</button></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty"><h3>No follow-ups due</h3><p>When a lead is set to Follow-up due, it shows here with its due date.</p></div>'}</div>`;
  }

  // ---------------- Imports ----------------
  function importsTab() {
    return `<div class="page-head"><div><h1>Imports</h1><p class="sub">Add leads from CSV, Excel, Word or PDF files. Every file is previewed and checked for duplicates first.</p></div>
      <button class="btn btn-dark" data-act="import">${ICON.upload} Upload a file</button></div>
      <div data-history><p class="muted">Loading…</p></div>`;
  }

  // ---------------- Team ----------------
  function teamTab() {
    const list = assistants();
    return `<div class="page-head"><div><h1>Team and <em>targets</em></h1><p class="sub">Daily targets drive the progress bars in both portals.</p></div></div>
      <div class="grid">${list.map(a => {
        const tm = ui.teamMetrics[a.id];
        return `<section class="card card-pad">
          <div class="card-title"><div class="kv"><span class="avatar">${esc(initials(a.display_name))}</span><div><h2 style="font-size:20px">${esc(a.display_name)}</h2><div class="muted small">@${esc(a.username)} · ${plural(a.lead_count, 'lead')} assigned</div></div></div>
            <span class="pill-tag ${a.active ? 'ok' : ''}">${a.active ? 'Active' : 'Paused'}</span></div>
          <form data-targets="${a.id}" class="grid" style="gap:14px">
            <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
              ${ctx.constants.metrics.map(m => `<label class="field">${esc(m.label)} <span class="hint">Today: ${tm ? tm.metrics[m.key].today : '…'}</span>
                <input class="input" type="number" min="0" max="10000" step="1" name="${m.key}" value="${a.targets?.[m.key] ?? 0}"></label>`).join('')}
            </div>
            <div class="kv"><button class="btn btn-primary btn-sm" type="submit">Save targets</button>
              <label class="field" style="grid-auto-flow:column;align-items:center">Display name <input class="input input-sm" name="display_name" value="${esc(a.display_name)}" style="width:180px"></label>
              <button class="btn btn-sm" type="button" data-rename="${a.id}">Rename</button>
              <button class="btn btn-sm ${a.active ? 'btn-danger' : ''}" type="button" data-active="${a.id}" data-to="${a.active ? 0 : 1}">${a.active ? 'Pause access' : 'Restore access'}</button></div>
          </form></section>`;
      }).join('')}
      <section class="card card-pad"><h2 style="margin-bottom:14px">Add an assistant</h2>
        <form data-add-user class="form-grid">
          <label class="field">Display name <input class="input" name="display_name" required></label>
          <label class="field">Username <input class="input" name="username" autocomplete="off" required></label>
          <label class="field">Password <input class="input" type="password" name="password" autocomplete="new-password" required><span class="hint">At least 10 characters, with a letter and a number.</span></label>
          <div style="align-self:end"><button class="btn btn-primary" type="submit">Add assistant</button></div>
        </form><p class="form-error" data-add-err></p></section></div>`;
  }

  function credentialsCard(users) {
    return `<section class="card card-pad" id="security">
          <h2>Sign-in credentials</h2>
          <p class="muted small" style="margin:6px 0 4px">Passwords are stored as salted scrypt hashes on the server. Changing a password signs that account out on other devices.</p>
          ${users.map(u => `<form class="account-row" data-cred="${u.id}" autocomplete="off">
            <div class="kv"><b>${esc(u.display_name)}</b><span class="chip">${u.role === 'owner' ? 'Owner' : 'Assistant'}</span>
              ${u.must_change ? '<span class="pill-tag">Initial password in use</span>' : `<span class="pill-tag ok">Password updated${u.password_changed_at ? ` ${esc(fmtFull(u.password_changed_at))}` : ''}</span>`}</div>
            <div class="form-grid">
              <label class="field">Username <input class="input" name="username" value="${esc(u.username)}" autocomplete="off"></label>
              <label class="field">New password <input class="input" type="password" name="password" autocomplete="new-password" placeholder="Leave blank to keep"></label>
              <label class="field">Confirm new password <input class="input" type="password" name="confirm" autocomplete="new-password"></label>
              <label class="field">Your current owner password <input class="input" type="password" name="current_password" autocomplete="current-password" required></label>
            </div>
            <div class="kv"><button class="btn btn-primary btn-sm" type="submit">Save ${u.role === 'owner' ? 'owner' : esc(u.display_name)} credentials</button><span class="form-error" data-err></span></div>
          </form>`).join('')}
        </section>`;
  }

  // ---------------- Settings ----------------
  function settingsTab() {
    const users = ctx.state.users || [];
    const st = ui.settings;
    const tzs = typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : [st?.timezone || 'UTC'];
    if (ctx.setupMode) {
      return `<div class="page-head"><div><h1>Finish <em>setup</em></h1><p class="sub">Before Obsidia goes live, replace the initial passwords for every account. The assistant can sign in once this is done.</p></div></div>
        <div class="settings-grid">${credentialsCard(users)}</div>`;
    }
    return `<div class="page-head"><div><h1><em>Settings</em></h1><p class="sub">Only the owner can see or change these.</p></div></div>
      <div class="settings-grid">
        ${credentialsCard(users)}
        <section class="card card-pad">
          <h2>Outreach templates</h2>
          <p class="muted small" style="margin:6px 0 14px">Used to prepare each lead’s editable notes. Placeholders: {first_name}, {company}, {focus}, {sector}, {title}.</p>
          ${st ? `<form data-templates class="grid" style="gap:14px">
            <label class="field">Connection note <textarea class="input" name="connection" maxlength="2000">${esc(st.templates.connection)}</textarea><span class="hint" data-tcount></span></label>
            <label class="field">Follow-up message <textarea class="input" name="followup" maxlength="2000">${esc(st.templates.followup)}</textarea></label>
            <label class="check"><input type="checkbox" name="regen"> Also refresh notes for leads that haven’t been contacted yet</label>
            <div class="kv"><button class="btn btn-primary btn-sm" type="submit">Save templates</button><button class="btn btn-sm btn-ghost" type="button" data-tpl-default>Restore defaults</button></div>
          </form>` : '<p class="muted">Loading…</p>'}
        </section>
        <section class="card card-pad">
          <h2>Reporting time zone</h2>
          <p class="muted small" style="margin:6px 0 14px">Daily targets and charts reset at midnight in this time zone.</p>
          ${st ? `<form data-tz class="kv"><select class="input" name="tz" style="width:auto;max-width:100%">${tzs.map(z => `<option ${z === st.timezone ? 'selected' : ''}>${esc(z)}</option>`).join('')}</select><button class="btn btn-primary btn-sm" type="submit">Save time zone</button></form>` : ''}
        </section>
      </div>`;
  }

  // ---------------- Drawer ----------------
  async function openDrawer(id) {
    ui.drawer = { id, lead: getLead(id), activity: null };
    renderDrawer();
    await loadDrawer();
  }
  async function loadDrawer() {
    if (!ui.drawer) return;
    try {
      const { lead, activity } = await api(`/api/leads/${ui.drawer.id}`);
      if (!ui.drawer) return;
      ui.drawer.lead = lead; ui.drawer.activity = activity;
      renderDrawer();
    } catch (e) {
      if (e.status === 404) { closeDrawer(); toast('That lead was removed.'); } else toastError(e);
    }
  }
  function closeDrawer() {
    ui.drawer = null;
    document.querySelector('.drawer')?.remove();
    document.querySelector('.scrim.dr')?.remove();
  }
  function renderDrawer() {
    const d = ui.drawer;
    if (!d) return;
    const l = d.lead;
    let drawer = document.querySelector('.drawer');
    if (!drawer) {
      const scrim = document.createElement('div'); scrim.className = 'scrim dr'; scrim.onclick = closeDrawer;
      drawer = document.createElement('aside'); drawer.className = 'drawer'; drawer.setAttribute('role', 'dialog'); drawer.setAttribute('aria-label', 'Lead details');
      drawer.innerHTML = '<div data-dh></div><div class="drawer-body"><div data-dact></div><div data-dnotes></div><div data-dform></div><div data-dhist></div></div>';
      document.body.append(scrim, drawer);
      drawer.addEventListener('click', drawerClick);
      drawer.addEventListener('submit', drawerSubmit);
      drawer.addEventListener('change', drawerChange);
      drawer.addEventListener('input', (e) => { const f = e.target.closest('form'); if (f) f.dataset.dirty = '1'; });
      drawer.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDrawer(); });
      setTimeout(() => drawer.querySelector('[data-close]')?.focus(), 30);
    }
    drawer.querySelector('[data-dh]').innerHTML = `<div class="drawer-head">
      <div style="min-width:0"><div class="kv" style="margin-bottom:8px">${statusPill(l)}${fitChip(l)}</div>
        <h2 style="font-size:26px">${esc(l.full_name)}</h2>
        <div class="muted" style="margin-top:4px">${esc([l.title, l.company].filter(Boolean).join(' · '))}</div>
        <div class="lead-meta" style="margin-top:10px">${location(l) ? `<span class="chip">${esc(location(l))}</span>` : ''}${l.brand_category ? `<span class="chip outline">${esc(l.brand_category)}</span>` : ''}${gapChips(l)}</div></div>
      <button class="icon-btn" data-close aria-label="Close">${ICON.close}</button></div>`;
    const quick = (QUICK[l.status] || []).map(q => `<button class="btn btn-sm" data-dq="${esc(q.to || '')}" ${q.followup ? 'data-dfollow' : ''}>${esc(q.label)}</button>`).join('');
    drawer.querySelector('[data-dact]').innerHTML = `<div class="grid" style="gap:10px">
      <a class="btn btn-primary btn-linkedin" href="${safeUrl(l.linkedin_url)}" target="_blank" rel="noopener noreferrer" data-dopen>Open LinkedIn profile ${ICON.external}</a>
      <p class="hint">${esc(l.linkedin_url)} · Opening records a profile visit under your name.</p>
      <div class="kv">${quick}<button class="btn btn-sm" data-dstatus>Update status</button>
        <label class="field" style="grid-auto-flow:column;align-items:center;gap:8px;margin-left:auto">Assigned to
          <select class="input input-sm" data-dassign style="width:auto"><option value="">Unassigned</option>${assistants().filter(a => a.active || a.id === l.assigned_to).map(a => `<option value="${a.id}" ${a.id === l.assigned_to ? 'selected' : ''}>${esc(a.display_name)}</option>`).join('')}</select></label></div>
      <p class="small muted">${esc(l.next_action)}${l.follow_up_due_at ? ` · follow-up due ${esc(fmtFull(l.follow_up_due_at))}` : ''}${l.meeting_at ? ` · meeting ${esc(fmtFull(l.meeting_at))}` : ''}</p>
      ${l.profile_opened_at ? `<p class="small muted">Profile last opened ${esc(fmtFull(l.profile_opened_at))} by ${esc(l.profile_opened_by_name || 'someone')}</p>` : ''}
    </div>`;
    const notesEl = drawer.querySelector('[data-dnotes]');
    if (!notesEl.querySelector('form[data-dirty]') && !notesEl.contains(document.activeElement)) {
      notesEl.innerHTML = `<form data-dnotesf class="grid" style="gap:10px"><h3>💬 Outreach notes</h3>
        <label class="field">Connection note <textarea class="input" name="connection_note">${esc(l.connection_note || '')}</textarea><span class="hint">${(l.connection_note || '').length} / 300 characters</span></label>
        <label class="field">Follow-up message <textarea class="input" name="followup_note">${esc(l.followup_note || '')}</textarea></label>
        <div class="kv"><button class="btn btn-sm btn-primary" type="submit">Save notes</button><button type="button" class="btn btn-sm" data-dcopy="connection">${ICON.copy} Copy connection note</button><button type="button" class="btn btn-sm" data-dcopy="followup">${ICON.copy} Copy follow-up</button></div></form>`;
    }
    const formEl = drawer.querySelector('[data-dform]');
    if (!formEl.querySelector('form[data-dirty]') && !formEl.contains(document.activeElement)) {
      const f = (k, label, type = 'text') => `<label class="field">${label}<input class="input input-sm" name="${k}" type="${type}" value="${esc(l[k] || '')}"></label>`;
      formEl.innerHTML = `<form data-dedit class="grid" style="gap:12px"><h3>Details</h3>
        <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
          ${f('full_name', 'Full name')}${f('title', 'Position')}${f('company', 'Company')}${f('website', 'Company website')}
          ${f('linkedin_url', 'LinkedIn URL')}${f('city', 'City')}${f('country', 'Country')}${f('market', 'Brand market')}
          ${f('brand_category', 'Brand category')}
          <label class="field">Fit<select class="input input-sm" name="fit">${['', ...ctx.constants.fits].map(x => `<option value="${x}" ${x === (l.fit || '') ? 'selected' : ''}>${x || 'Not classified'}</option>`).join('')}</select>${l.fit_basis === 'suggested' ? '<span class="hint">Suggested from the brief</span>' : ''}</label>
          <label class="field">Priority<select class="input input-sm" name="priority">${['', ...ctx.constants.priorities].map(x => `<option value="${x}" ${x === (l.priority || '') ? 'selected' : ''}>${x || 'None'}</option>`).join('')}</select></label>
          ${f('company_size', 'Company size')}${f('business_email', 'Business email', 'email')}${f('email_type', 'Email type')}${f('email_source', 'Email source')}
        </div>
        <label class="field">Why the brand fits<textarea class="input" style="min-height:70px" name="fit_rationale">${esc(l.fit_rationale || '')}</textarea></label>
        <label class="field">Qualification notes<textarea class="input" style="min-height:70px" name="qualification_notes">${esc(l.qualification_notes || '')}</textarea></label>
        <label class="field">Research and verification notes<textarea class="input" style="min-height:70px" name="verification_notes">${esc(l.verification_notes || '')}</textarea></label>
        ${l.sources ? `<div class="small"><span class="muted">Sources:</span> ${Object.entries(l.sources).map(([k, v]) => `<a href="${safeUrl(v)}" target="_blank" rel="noopener noreferrer">${esc(k.replace('_source', ''))}</a>`).join(' · ')}</div>` : ''}
        ${l.extra ? `<div class="small"><span class="muted">Other columns:</span> ${Object.entries(l.extra).map(([k, v]) => `${esc(k)}: ${esc(v)}`).join(' · ')}</div>` : ''}
        <div class="kv"><button class="btn btn-primary btn-sm" type="submit">Save details</button><button class="btn btn-sm btn-danger" type="button" data-ddelete style="margin-left:auto">Delete lead</button></div>
      </form>`;
    }
    drawer.querySelector('[data-dhist]').innerHTML = `<h3>History</h3>${timeline(d.activity)}`;
  }
  async function drawerClick(e) {
    const l = ui.drawer?.lead; if (!l) return;
    if (e.target.closest('[data-close]')) return closeDrawer();
    if (e.target.closest('[data-dopen]')) return trackOpen(l);
    if (e.target.closest('[data-dstatus]')) return statusModal(l, ctx.constants.statuses);
    const q = e.target.closest('[data-dq]');
    if (q) return q.hasAttribute('data-dfollow') ? followupModal(l) : statusModal(l, ctx.constants.statuses, q.dataset.dq);
    const c = e.target.closest('[data-dcopy]');
    if (c) { const f = c.closest('form'); return copyNote(l, c.dataset.dcopy, f[c.dataset.dcopy === 'followup' ? 'followup_note' : 'connection_note'].value); }
    if (e.target.closest('[data-ddelete]')) {
      if (await confirmDialog({ title: `Delete ${l.full_name}?`, body: 'This removes the lead and its history from both portals. It can’t be undone.', confirm: 'Delete lead', danger: true })) {
        try { await api(`/api/leads/${l.id}`, { method: 'DELETE' }); closeDrawer(); toast('Lead deleted.'); } catch (err) { toastError(err); }
      }
    }
  }
  async function drawerSubmit(e) {
    e.preventDefault();
    const f = e.target; const l = ui.drawer?.lead; if (!l) return;
    const body = {};
    for (const el of f.elements) if (el.name) body[el.name] = el.value;
    try {
      await api(`/api/leads/${l.id}`, { method: 'PATCH', body });
      delete f.dataset.dirty; document.activeElement?.blur?.();
      toast('Saved.');
      loadDrawer();
    } catch (err) { toastError(err); }
  }
  async function drawerChange(e) {
    const sel = e.target.closest('[data-dassign]');
    if (!sel) return;
    try { await api('/api/leads/assign', { method: 'POST', body: { ids: [ui.drawer.id], assistant_id: sel.value || null } }); toast(sel.value ? 'Lead assigned.' : 'Lead unassigned.'); } catch (err) { toastError(err); }
  }

  // ---------------- Render & events ----------------
  async function loadMetrics() {
    try { ui.metrics = await api(`/api/metrics${ui.metricsFor ? `?assistant=${ui.metricsFor}` : ''}`); } catch (e) { toastError(e); }
  }
  async function loadFeed() { try { ({ activity: ui.feed } = await api('/api/activity?limit=60')); } catch {} }
  async function loadSettings() { try { ui.settings = await api('/api/settings'); } catch {} }
  async function loadTeamMetrics() {
    await Promise.all(assistants().map(async a => { try { ui.teamMetrics[a.id] = await api(`/api/metrics?assistant=${a.id}`); } catch {} }));
  }

  function render() {
    const scrollY = window.scrollY;
    const busy = root.contains(document.activeElement) && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)
      || root.querySelector('form[data-dirty]');
    if (ui.tab === 'leads' && root.querySelector('[data-rows]')) { renderLeadRows(); return; }
    if (busy) return; // don't wipe a control or form someone is using; the next update will catch up
    const views = { overview, leads: leadsTab, followups: followupsTab, imports: importsTab, team: teamTab, settings: settingsTab };
    root.innerHTML = views[ui.tab]();
    if (ui.tab === 'leads') renderLeadRows();
    if (ui.tab === 'imports') importHistory(ctx).then(h => { const el = root.querySelector('[data-history]'); if (el) el.innerHTML = h; });
    const tc = root.querySelector('[data-tcount]');
    if (tc) { const ta = root.querySelector('form[data-templates] [name=connection]'); const upd = () => { tc.textContent = `${ta.value.length} characters before placeholders are filled`; }; ta.addEventListener('input', upd); upd(); }
    window.scrollTo(0, scrollY);
  }

  root.addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('[data-act="import"]')) return openImportWizard(ctx);
    const ol = t.closest('[data-open-lead]');
    if (ol) return openDrawer(Number(ol.dataset.openLead));
    const tr = t.closest('[data-trend]');
    if (tr) { ui.trend = tr.dataset.trend; return render(); }
    if (t.closest('[data-toggle-table]')) { ui.table = !ui.table; return render(); }
    if (t.closest('[data-sel]') || t.closest('td.cb')) {
      const cb = t.closest('td.cb')?.querySelector('[data-sel]') || t.closest('[data-sel]');
      if (t !== cb) cb.checked = !cb.checked;
      const id = Number(cb.dataset.sel);
      if (cb.checked) ui.selected.add(id); else ui.selected.delete(id);
      return renderLeadRows();
    }
    if (t.closest('[data-all]')) {
      const items = filteredLeads();
      if (t.checked) items.forEach(l => ui.selected.add(l.id)); else items.forEach(l => ui.selected.delete(l.id));
      return renderLeadRows();
    }
    if (t.closest('[data-bulk-clear]')) { ui.selected.clear(); return renderLeadRows(); }
    if (t.closest('[data-bulk-apply]')) {
      const to = root.querySelector('[data-bulk-to]').value;
      try {
        const { changed } = await api('/api/leads/assign', { method: 'POST', body: { ids: [...ui.selected], assistant_id: to || null } });
        toast(`${plural(changed, 'lead')} ${to ? 'assigned' : 'unassigned'}.`);
        ui.selected.clear();
      } catch (err) { toastError(err); }
      return;
    }
    const row = t.closest('tr[data-row]');
    if (row && !t.closest('select, a, button, input')) return openDrawer(Number(row.dataset.row));
    const act = t.closest('[data-active]');
    if (act) {
      const on = act.dataset.to === '1';
      if (!on && !(await confirmDialog({ title: 'Pause this assistant’s access?', body: 'They’ll be signed out right away. Their leads stay assigned until you reassign them.', confirm: 'Pause access', danger: true }))) return;
      try { ({ users: ctx.state.users } = await api(`/api/users/${act.dataset.active}`, { method: 'PUT', body: { active: on } })); toast(on ? 'Access restored.' : 'Access paused.'); render(); } catch (err) { toastError(err); }
      return;
    }
    const rn = t.closest('[data-rename]');
    if (rn) {
      const f = rn.closest('form');
      try { ({ users: ctx.state.users } = await api(`/api/users/${rn.dataset.rename}`, { method: 'PUT', body: { display_name: f.display_name.value } })); toast('Name updated.'); delete f.dataset.dirty; render(); } catch (err) { toastError(err); }
      return;
    }
    if (t.closest('[data-tpl-default]')) {
      const f = root.querySelector('form[data-templates]');
      f.connection.value = ui.settings.default_templates.connection;
      f.followup.value = ui.settings.default_templates.followup;
      f.dataset.dirty = '1';
    }
  });
  root.addEventListener('input', (e) => {
    if (e.target.matches('[data-q]')) { ui.q = e.target.value; renderLeadRows(); return; }
    const f = e.target.closest('form'); if (f) f.dataset.dirty = '1';
  });
  root.addEventListener('change', async (e) => {
    const t = e.target;
    if (t.matches('[data-f]')) { ui[t.dataset.f] = t.value; renderLeadRows(); return; }
    if (t.matches('[data-metrics-for]')) { ui.metricsFor = t.value; await loadMetrics(); render(); return; }
    if (t.matches('[data-reassign]')) {
      try { await api('/api/leads/assign', { method: 'POST', body: { ids: [Number(t.dataset.reassign)], assistant_id: t.value || null } }); toast('Lead reassigned.'); t.blur(); } catch (err) { toastError(err); }
    }
  });
  root.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    try {
      if (f.matches('[data-targets]')) {
        const targets = {};
        for (const m of ctx.constants.metrics) targets[m.key] = Number(f[m.key].value);
        ({ users: ctx.state.users } = await api(`/api/users/${f.dataset.targets}`, { method: 'PUT', body: { targets } }));
        delete f.dataset.dirty; toast('Targets saved. Both portals are updated.'); render();
      } else if (f.matches('[data-add-user]')) {
        const body = { display_name: f.display_name.value, username: f.username.value, password: f.password.value };
        ({ users: ctx.state.users } = await api('/api/users', { method: 'POST', body }));
        delete f.dataset.dirty; toast('Assistant added.'); render();
      } else if (f.matches('[data-cred]')) {
        const err = f.querySelector('[data-err]'); err.textContent = '';
        if (f.password.value && f.password.value !== f.confirm.value) { err.textContent = 'The new passwords don’t match.'; return; }
        const body = { current_password: f.current_password.value, username: f.username.value };
        if (f.password.value) body.password = f.password.value;
        try {
          ({ users: ctx.state.users } = await api(`/api/users/${f.dataset.cred}/credentials`, { method: 'PUT', body }));
          delete f.dataset.dirty; toast('Credentials updated.');
          await ctx.reloadMe();
          render();
        } catch (ex) { err.textContent = ex.message; }
      } else if (f.matches('[data-templates]')) {
        await api('/api/settings', { method: 'PUT', body: { templates: { connection: f.connection.value, followup: f.followup.value }, regenerate_notes: f.regen.checked } });
        delete f.dataset.dirty; toast(f.regen.checked ? 'Templates saved and notes refreshed.' : 'Templates saved.'); await loadSettings(); render();
      } else if (f.matches('[data-tz]')) {
        await api('/api/settings', { method: 'PUT', body: { timezone: f.tz.value } });
        toast('Time zone saved.'); await loadSettings(); await loadMetrics(); render();
      }
    } catch (err) {
      if (f.matches('[data-add-user]')) root.querySelector('[data-add-err]').textContent = err.message; else toastError(err);
    }
  });

  return {
    el: root,
    async route(tab) {
      ui.tab = OWNER_TABS.some(t => t.key === tab) ? tab : 'overview';
      if (ui.tab === 'settings' && !ui.settings) await loadSettings();
      if (ui.tab === 'team') await loadTeamMetrics();
      root.innerHTML = '';
      render();
    },
    async refresh(scopes) {
      const all = !scopes;
      const jobs = [];
      if (all || scopes.has('metrics') || scopes.has('users') || scopes.has('settings')) jobs.push(loadMetrics());
      if (all || scopes.has('activity') || scopes.has('leads')) jobs.push(loadFeed());
      if ((all || scopes.has('settings')) && ui.tab === 'settings') jobs.push(loadSettings());
      if (ui.tab === 'team' && (all || scopes.has('metrics') || scopes.has('users'))) jobs.push(loadTeamMetrics());
      await Promise.all(jobs);
      if (ui.tab !== 'settings' || all || scopes.has('users') || scopes.has('settings')) render();
      if (ui.drawer && (all || scopes.has('leads') || scopes.has('activity'))) loadDrawer();
    },
    focusLead(id) { if (getLead(id)) openDrawer(id); },
    closeDrawer,
  };
}
