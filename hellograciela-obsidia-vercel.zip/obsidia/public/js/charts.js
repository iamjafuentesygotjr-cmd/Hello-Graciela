// Small-multiple bar charts (one metric per chart, one hue) with hover and keyboard tooltips.
import { esc, fmtDayKey } from './util.js';

export function barChart({ keys, values, labels, target = 0, todayKey, unit = '' }) {
  const W = 320, H = 132, padL = 24, padR = 6, padT = 10, padB = 20;
  const innerW = W - padL - padR, innerH = H - padT - padB;
  const max = Math.max(1, target, ...values);
  const nice = niceMax(max);
  const step = innerW / keys.length;
  const bw = Math.max(4, Math.min(18, step * 0.62));
  const y = (v) => padT + innerH - (v / nice) * innerH;
  const grid = [0.5, 1].map(f => {
    const gy = y(nice * f);
    return `<line class="grid" x1="${padL}" x2="${W - padR}" y1="${gy}" y2="${gy}"/><text x="${padL - 6}" y="${gy + 3.5}" text-anchor="end">${Math.round(nice * f)}</text>`;
  }).join('');
  const bars = keys.map((k, i) => {
    const v = values[i];
    const x = padL + step * i + (step - bw) / 2;
    const top = y(v);
    const h = padT + innerH - top;
    const r = Math.min(4, bw / 2, h);
    const path = v > 0
      ? `M${x},${padT + innerH} V${top + r} Q${x},${top} ${x + r},${top} H${x + bw - r} Q${x + bw},${top} ${x + bw},${top + r} V${padT + innerH} Z`
      : '';
    const tip = `<b>${esc(labels[i])}</b> · ${v}${unit}`;
    return `<rect class="hit" x="${padL + step * i}" y="${padT}" width="${step}" height="${innerH}" tabindex="0" data-tip="${esc(tip)}" aria-label="${esc(labels[i])}: ${v}"/>
      ${path ? `<path class="bar ${k === todayKey ? 'today' : ''}" d="${path}"/>` : ''}`;
  }).join('');
  const xl = [0, Math.floor((keys.length - 1) / 2), keys.length - 1].filter((v, i, a) => a.indexOf(v) === i)
    .map((i, n, arr) => `<text x="${n === 0 ? padL : n === arr.length - 1 ? W - padR : padL + step * i + step / 2}" y="${H - 5}" text-anchor="${n === 0 ? 'start' : n === arr.length - 1 ? 'end' : 'middle'}">${esc(labels[i].replace(/^Week of /, ''))}</text>`).join('');
  const tl = target > 0 ? `<line class="target" x1="${padL}" x2="${W - padR}" y1="${y(target)}" y2="${y(target)}"><title>Daily target ${target}</title></line>` : '';
  return `<svg viewBox="0 0 ${W} ${H}" role="img">${grid}<line class="base" x1="${padL}" x2="${W - padR}" y1="${padT + innerH}" y2="${padT + innerH}"/>${tl}${bars}${xl}</svg>`;
}

function niceMax(v) {
  if (v <= 4) return 4;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}

export function dayLabels(keys) { return keys.map(k => fmtDayKey(k, { weekday: 'short', month: 'short', day: 'numeric' })); }
export function weekLabels(keys) { return keys.map(k => `Week of ${fmtDayKey(k)}`); }

// One tooltip element for every chart on the page.
export function bindTooltips(root) {
  const tip = document.getElementById('tooltip');
  const show = (el, x, y) => {
    tip.innerHTML = el.dataset.tip;
    tip.hidden = false;
    const r = tip.getBoundingClientRect();
    tip.style.left = `${Math.max(8, Math.min(window.innerWidth - r.width - 8, x - r.width / 2))}px`;
    tip.style.top = `${Math.max(8, y - r.height - 12)}px`;
  };
  root.addEventListener('pointermove', (e) => {
    const el = e.target.closest('[data-tip]');
    if (el) show(el, e.clientX, e.clientY); else tip.hidden = true;
  });
  root.addEventListener('pointerleave', () => { tip.hidden = true; });
  root.addEventListener('focusin', (e) => {
    const el = e.target.closest('[data-tip]');
    if (!el) return;
    const r = el.getBoundingClientRect();
    show(el, r.left + r.width / 2, r.top + 20);
  });
  root.addEventListener('focusout', () => { tip.hidden = true; });
}
