// Shared lead components and actions used by both portals.
import {
  api, esc, safeUrl, fmtTime, fmtFull, fmtDate, toast, toastError, openModal, copyText, ICON, toLocalInput, ago,
} from './util.js';

export const STATUS_CLASS = {
  'New': 'st-new', 'Assigned': 'st-assigned', 'Profile opened': 'st-opened', 'Connection sent': 'st-sent',
  'Connected': 'st-connected', 'Replied': 'st-replied', 'Follow-up due': 'st-followup',
  'Meeting booked': 'st-meeting', 'Not a fit': 'st-notfit',
};
export function statusPill(lead) {
  if (lead.follow_up_overdue) return `<span class="status st-overdue">Follow-up overdue</span>`;
  return `<span class="status ${STATUS_CLASS[lead.status] || 'st-new'}">${esc(lead.status)}</span>`;
}
export function fitChip(lead) {
  const cls = { 'Primary fit': 'fit-primary', 'Secondary fit': 'fit-secondary', 'Not a fit': 'fit-not' }[lead.fit] || 'fit-none';
  const label = lead.fit || 'Fit to review';
  const title = lead.fit_basis === 'suggested' ? 'Suggested from the HelloGraciela brief. Confirm or change it.' : lead.fit_basis === 'source' ? 'From the imported file' : '';
  return `<span class="chip fit ${cls}" ${title ? `title="${esc(title)}"` : ''}>${esc(label)}${lead.fit_basis === 'suggested' ? ' · suggested' : ''}</span>`;
}
export const location = (l) => [l.city, l.country].filter(Boolean).join(', ');
const GAP_LABEL = { business_email: 'Email', city: 'City', country: 'Country', title: 'Position', company: 'Company', website: 'Website', brand_category: 'Category' };
export function gapChips(lead) {
  return Object.entries(lead.gaps || {}).map(([k, v]) => `<span class="chip gap" title="From the research file">${esc(GAP_LABEL[k] || k)}: ${esc(String(v).toLowerCase())}</span>`).join('');
}

export const QUICK = {
  'Profile opened': [{ label: 'Mark connection sent', to: 'Connection sent' }],
  'Connection sent': [{ label: 'Mark connected', to: 'Connected' }],
  'Connected': [{ label: 'Log follow-up sent', followup: true }, { label: 'Mark replied', to: 'Replied' }],
  'Replied': [{ label: 'Mark meeting booked', to: 'Meeting booked' }, { label: 'Set follow-up', to: 'Follow-up due' }],
  'Follow-up due': [{ label: 'Log follow-up sent', followup: true }, { label: 'Mark replied', to: 'Replied' }],
};

const CONFIRM_COPY = {
  'Connection sent': 'Confirm you sent the connection request on LinkedIn.',
  'Connected': 'Confirm they accepted your connection request.',
  'Replied': 'Confirm they replied to you on LinkedIn.',
  'Meeting booked': 'Confirm a meeting is booked.',
  'Follow-up due': 'Choose when the next follow-up is due.',
  'Not a fit': 'This lead will stay in the database but drop out of the active list.',
};

// ---------- Activity descriptions ----------
export function describeActivity(a) {
  const d = a.detail || {};
  switch (a.type) {
    case 'profile_opened': return `Opened the LinkedIn profile${a.from_status !== a.to_status ? ' · status set to Profile opened' : ''}`;
    case 'status_change': {
      let s = `Changed status from ${a.from_status} to ${a.to_status}`;
      if (d.follow_up_due_at) s += ` · due ${fmtFull(d.follow_up_due_at)}`;
      if (d.meeting_at) s += ` · meeting ${fmtFull(d.meeting_at)}`;
      if (d.reason) s += ` · “${d.reason}”`;
      return s;
    }
    case 'followup_sent': return `Logged a follow-up sent${d.next_due_at ? ` · next due ${fmtFull(d.next_due_at)}` : ''}${a.from_status !== a.to_status ? ` · status ${a.to_status}` : ''}`;
    case 'note_copied': return `Copied the ${d.kind === 'followup' ? 'follow-up message' : 'connection note'} (not counted as sent)`;
    case 'note_edited': return 'Edited the outreach note';
    case 'edited': return `Updated ${(d.fields || []).map(f => f.replace(/_/g, ' ')).join(', ')}`;
    case 'assigned': return d.to_user ? `Assigned to ${d.to_user}${d.from_user ? ` (was ${d.from_user})` : ''}` : `Unassigned${d.from_user ? ` from ${d.from_user}` : ''}`;
    case 'imported': return `Imported from ${d.file || 'a file'}${d.row ? `, row ${d.row}` : ''}`;
    case 'undo': return `Undid an update (${a.from_status} back to ${a.to_status})`;
    default: return a.type;
  }
}
export function timeline(activity) {
  if (!activity) return '<p class="muted small">Loading history…</p>';
  if (!activity.length) return '<p class="muted small">No activity yet.</p>';
  const key = new Set(['profile_opened', 'status_change', 'followup_sent']);
  return `<ol class="timeline">${activity.map(a => `
    <li class="${key.has(a.type) ? 'key' : ''} ${a.voided ? 'void' : ''}">
      <div>${esc(describeActivity(a))}${a.voided ? ' (undone)' : ''}
        <span class="when">${esc(a.user_name)} · ${esc(fmtFull(a.created_at))}</span></div>
    </li>`).join('')}</ol>`;
}

// ---------- Actions ----------
export function trackOpen(lead, onDone) {
  // The link itself opens the profile in a new tab; this only records the open.
  fetch(`/api/leads/${lead.id}/open`, { method: 'POST', headers: { 'X-Obsidia': '1' }, keepalive: true, credentials: 'same-origin' })
    .then(r => r.ok ? r.json() : Promise.reject(r))
    .then((res) => {
      toast(res.status === 'Profile opened' && lead.status !== 'Profile opened'
        ? `Profile opened at ${fmtTime(res.opened_at)}. Status set to Profile opened.`
        : `Profile opened at ${fmtTime(res.opened_at)}.`,
      res.activityId ? { action: 'Undo', onAction: () => undo(res.activityId) } : {});
      onDone?.();
    })
    .catch(() => toast('The profile opened, but the visit couldn’t be recorded. Check your connection.', { error: true }));
}

export async function undo(activityId) {
  try { await api(`/api/activity/${activityId}/undo`, { method: 'POST' }); toast('Update undone.'); } catch (e) { toastError(e); }
}

export function statusModal(lead, statuses, preset) {
  const initial = preset || lead.status;
  const defaultDue = toLocalInput(new Date(Date.now() + 3 * 864e5).toISOString());
  const m = openModal(`
    <div>
      <h2>Update status</h2>
      <p class="muted small" style="margin-top:6px">${esc(lead.full_name)}${lead.company ? ` · ${esc(lead.company)}` : ''}</p>
    </div>
    <form class="grid" style="gap:14px" novalidate>
      <label class="field">Status
        <select class="input" name="status">${statuses.map(s => `<option ${s === initial ? 'selected' : ''}>${esc(s)}</option>`).join('')}</select>
      </label>
      <p class="hint" data-copy></p>
      <label class="field" data-when="Follow-up due">Follow-up due
        <input class="input" type="datetime-local" name="follow_up_due_at" value="${esc(lead.follow_up_due_at ? toLocalInput(lead.follow_up_due_at) : defaultDue)}">
      </label>
      <label class="field" data-when="Meeting booked">Meeting date and time <span class="hint">Optional</span>
        <input class="input" type="datetime-local" name="meeting_at" value="${esc(lead.meeting_at ? toLocalInput(lead.meeting_at) : '')}">
      </label>
      <label class="field" data-when="Not a fit">Reason <span class="hint">Optional</span>
        <input class="input" name="reason" maxlength="200" placeholder="For example, not founder-led">
      </label>
      <p class="form-error" data-err></p>
      <div class="modal-actions">
        <button type="button" class="btn" data-x>Cancel</button>
        <button type="submit" class="btn btn-primary" autofocus>Save status</button>
      </div>
    </form>`, { label: 'Update status' });
  const form = m.box.querySelector('form');
  const sync = () => {
    const s = form.status.value;
    m.box.querySelectorAll('[data-when]').forEach(el => { el.hidden = el.dataset.when !== s; });
    m.box.querySelector('[data-copy]').textContent = CONFIRM_COPY[s] || 'Updates are recorded with your name and the time.';
  };
  form.status.onchange = sync; sync();
  m.box.querySelector('[data-x]').onclick = () => m.close();
  form.onsubmit = async (e) => {
    e.preventDefault();
    const s = form.status.value;
    const body = { status: s };
    if (s === 'Follow-up due') {
      if (!form.follow_up_due_at.value) { m.box.querySelector('[data-err]').textContent = 'Choose when the follow-up is due.'; return; }
      body.follow_up_due_at = new Date(form.follow_up_due_at.value).toISOString();
    }
    if (s === 'Meeting booked' && form.meeting_at.value) body.meeting_at = new Date(form.meeting_at.value).toISOString();
    if (s === 'Not a fit' && form.reason.value.trim()) body.reason = form.reason.value.trim();
    try {
      const res = await api(`/api/leads/${lead.id}/status`, { method: 'POST', body });
      m.close();
      if (res.activityId) toast(`Status updated to ${s}.`, { action: 'Undo', onAction: () => undo(res.activityId) });
    } catch (err) { m.box.querySelector('[data-err]').textContent = err.message; }
  };
}

export function followupModal(lead) {
  const m = openModal(`
    <div>
      <h2>Log follow-up sent</h2>
      <p class="muted small" style="margin-top:6px">Confirm you sent a follow-up message to ${esc(lead.full_name)} on LinkedIn.</p>
    </div>
    <form class="grid" style="gap:14px">
      <label class="check"><input type="checkbox" name="schedule"> Schedule another follow-up</label>
      <label class="field" data-next hidden>Next follow-up due
        <input class="input" type="datetime-local" name="next" value="${esc(toLocalInput(new Date(Date.now() + 5 * 864e5).toISOString()))}">
      </label>
      <p class="form-error" data-err></p>
      <div class="modal-actions">
        <button type="button" class="btn" data-x>Cancel</button>
        <button type="submit" class="btn btn-primary" autofocus>Yes, I sent it</button>
      </div>
    </form>`, { label: 'Log follow-up sent' });
  const form = m.box.querySelector('form');
  form.schedule.onchange = () => { m.box.querySelector('[data-next]').hidden = !form.schedule.checked; };
  m.box.querySelector('[data-x]').onclick = () => m.close();
  form.onsubmit = async (e) => {
    e.preventDefault();
    const body = form.schedule.checked && form.next.value ? { next_due_at: new Date(form.next.value).toISOString() } : {};
    try {
      const res = await api(`/api/leads/${lead.id}/followup-sent`, { method: 'POST', body });
      m.close();
      toast('Follow-up logged.', { action: 'Undo', onAction: () => undo(res.activityId) });
    } catch (err) { m.box.querySelector('[data-err]').textContent = err.message; }
  };
}

export async function copyNote(lead, kind, text) {
  const ok = await copyText(text);
  if (!ok) { toast('Couldn’t copy automatically. Select the text and copy it manually.', { error: true }); return; }
  toast('Copied. Paste it into LinkedIn. Copying isn’t counted as sending.');
  api(`/api/leads/${lead.id}/copied`, { method: 'POST', body: { kind } }).catch(() => {});
}

// ---------- Notes popover ----------
export function notesPopover(lead, kind = 'connection') {
  const text = kind === 'followup' ? lead.followup_note : lead.connection_note;
  const limit = kind === 'connection' ? 300 : 8000;
  return `
    <div class="notes-pop" role="dialog" aria-label="Outreach message for ${esc(lead.full_name)}" data-pop="${lead.id}">
      <div class="tabs" role="tablist">
        <button type="button" role="tab" data-act="note-tab" data-kind="connection" aria-selected="${kind === 'connection'}">Connection note</button>
        <button type="button" role="tab" data-act="note-tab" data-kind="followup" aria-selected="${kind === 'followup'}">Follow-up message</button>
        <span style="flex:1"></span>
        <button type="button" class="icon-btn" style="width:32px;height:32px" data-act="note-close" aria-label="Close">${ICON.close}</button>
      </div>
      <textarea class="input" data-note="${kind}" data-limit="${limit}" aria-label="${kind === 'connection' ? 'Connection note' : 'Follow-up message'}">${esc(text || '')}</textarea>
      <div class="bar">
        <span class="count" data-count>${(text || '').length}${kind === 'connection' ? ' / 300' : ''} characters</span>
        <button type="button" class="btn btn-ghost btn-sm" data-act="note-reset" data-kind="${kind}">Reset</button>
        <button type="button" class="btn btn-primary btn-sm" data-act="note-copy" data-kind="${kind}">${ICON.copy} Copy text</button>
      </div>
      <p class="hint">${kind === 'connection' ? 'LinkedIn allows up to 300 characters in a connection note (200 on some free accounts). ' : ''}Edits save automatically.</p>
    </div>`;
}

const saveTimers = new Map();
export function bindNoteEditing(root, getLead) {
  root.addEventListener('input', (e) => {
    const ta = e.target.closest('textarea[data-note]');
    if (!ta) return;
    const pop = ta.closest('[data-pop]');
    const lead = getLead(Number(pop.dataset.pop));
    const kind = ta.dataset.note;
    const count = pop.querySelector('[data-count]');
    const n = ta.value.length;
    count.textContent = `${n}${kind === 'connection' ? ' / 300' : ''} characters`;
    count.classList.toggle('over', kind === 'connection' && n > 300);
    pop.dataset.dirty = '1';
    clearTimeout(saveTimers.get(ta));
    saveTimers.set(ta, setTimeout(async () => {
      try {
        await api(`/api/leads/${lead.id}`, { method: 'PATCH', body: { [kind === 'followup' ? 'followup_note' : 'connection_note']: ta.value } });
        if (kind === 'followup') lead.followup_note = ta.value; else lead.connection_note = ta.value;
        delete pop.dataset.dirty;
        count.textContent = `${ta.value.length}${kind === 'connection' ? ' / 300' : ''} characters · saved`;
      } catch (err) { toastError(err); }
    }, 700));
  });
}

export async function resetNote(lead, kind, pop) {
  try {
    const { text } = await api(`/api/leads/${lead.id}/reset-note`, { method: 'POST', body: { kind } });
    const ta = pop.querySelector('textarea');
    ta.value = text;
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  } catch (e) { toastError(e); }
}

// ---------- Details block ----------
export function detailsBlock(lead, activity, { editable = true } = {}) {
  const rows = [
    ['Email', lead.business_email ? `${esc(lead.business_email)}${lead.email_type ? ` <span class="faint">· ${esc(lead.email_type)}</span>` : ''}` : '<span class="faint">Not found</span>'],
    ['Website', lead.website ? `<a href="${safeUrl(lead.website)}" target="_blank" rel="noopener noreferrer">${esc(lead.website.replace(/^https?:\/\/(www\.)?/, ''))}</a>` : '<span class="faint">Not provided</span>'],
    ['Market', esc(lead.market || '—')],
    ['Location basis', esc(lead.location_basis || '—')],
    ['Why it fits', esc(lead.fit_rationale || '—')],
    ['Research notes', esc(lead.verification_notes || '—')],
  ];
  if (lead.research_date) rows.push(['Researched', esc(fmtDate(lead.research_date))]);
  return `
    <div class="details">
      <dl>${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>
      ${editable ? `
      <form class="grid" style="gap:10px" data-qual="${lead.id}">
        <div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">
          <label class="field">Fit
            <select class="input input-sm" name="fit">
              ${['', 'Primary fit', 'Secondary fit', 'Not a fit'].map(f => `<option value="${f}" ${f === (lead.fit || '') ? 'selected' : ''}>${f || 'Not classified'}</option>`).join('')}
            </select></label>
          <label class="field">Company size <input class="input input-sm" name="company_size" value="${esc(lead.company_size || '')}" placeholder="Optional"></label>
          <label class="field">Business email <input class="input input-sm" name="business_email" type="email" value="${esc(lead.business_email || '')}" placeholder="Optional"></label>
          <label class="field">Email source <input class="input input-sm" name="email_source" value="${esc(lead.email_source || '')}" placeholder="Where it was found"></label>
        </div>
        <label class="field">Qualification notes <textarea class="input" style="min-height:70px" name="qualification_notes" placeholder="Anything the owner should know">${esc(lead.qualification_notes || '')}</textarea></label>
        <div><button class="btn btn-sm" type="submit">Save details</button></div>
      </form>` : ''}
      <div><h3 style="font-size:15px;margin:4px 0 6px">History</h3>${timeline(activity)}</div>
    </div>`;
}

export function bindQualForms(root, getLead) {
  root.addEventListener('input', (e) => { const f = e.target.closest('form[data-qual]'); if (f) f.dataset.dirty = '1'; });
  root.addEventListener('submit', async (e) => {
    const f = e.target.closest('form[data-qual]');
    if (!f) return;
    e.preventDefault();
    const lead = getLead(Number(f.dataset.qual));
    const body = {};
    for (const k of ['fit', 'company_size', 'business_email', 'email_source', 'qualification_notes']) body[k] = f[k].value;
    try {
      await api(`/api/leads/${lead.id}`, { method: 'PATCH', body });
      delete f.dataset.dirty;
      toast('Details saved.');
    } catch (err) { toastError(err); }
  });
}

export { ago };
