// Small shared helpers: API calls, escaping, formatting, toasts, modals.

export class ApiError extends Error {
  constructor(status, message, data) { super(message); this.status = status; this.data = data; }
}

export async function api(path, { method = 'GET', body, form } = {}) {
  const opts = { method, headers: { 'X-Obsidia': '1' }, credentials: 'same-origin' };
  if (form) opts.body = form;
  else if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  let res;
  try { res = await fetch(path, opts); } catch { throw new ApiError(0, 'You appear to be offline. Check your connection and try again.'); }
  let data = null;
  try { data = await res.json(); } catch { /* empty */ }
  if (!res.ok) {
    const err = new ApiError(res.status, data?.error || 'Something went wrong. Please try again.', data);
    if (res.status === 401 && path !== '/api/auth/login') window.dispatchEvent(new CustomEvent('obsidia:signedout'));
    if (data?.code === 'setup_required') window.dispatchEvent(new CustomEvent('obsidia:setup'));
    throw err;
  }
  return data;
}

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ESC[c]);
export const safeUrl = (u) => (/^https?:\/\//i.test(String(u || '')) ? esc(u) : '#');
export const html = (strings, ...vals) => strings.reduce((out, s, i) => out + s + (i < vals.length ? vals[i] ?? '' : ''), '');

export function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const sameDay = d.toDateString() === new Date().toDateString();
  return sameDay
    ? d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
    : d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}
export function fmtFull(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}
export function fmtDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}
export function ago(iso) {
  if (!iso) return '';
  const s = Math.round((Date.now() - Date.parse(iso)) / 1000);
  if (s < 45) return 'just now';
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  if (d < 7) return `${d} ${d === 1 ? 'day' : 'days'} ago`;
  return fmtDate(iso);
}
export function fmtDayKey(key, opts = { month: 'short', day: 'numeric' }) {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString(undefined, { ...opts, timeZone: 'UTC' });
}
export const plural = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
export const initials = (name = '') => name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('') || '?';
export function toLocalInput(iso) {
  const d = iso ? new Date(iso) : new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ---------- Toasts ----------
export function toast(message, { error = false, action, onAction, timeout = 5000 } = {}) {
  const box = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast${error ? ' err' : ''}`;
  el.innerHTML = `<span>${esc(message)}</span>${action ? `<button type="button">${esc(action)}</button>` : ''}`;
  box.appendChild(el);
  const close = () => el.remove();
  if (action) el.querySelector('button').onclick = () => { close(); onAction?.(); };
  setTimeout(close, timeout);
}
export const toastError = (e) => toast(e?.message || String(e), { error: true });

// ---------- Modals ----------
let modalStack = [];
export function openModal(contentHtml, { wide = false, onClose, label = 'Dialog' } = {}) {
  const scrim = document.createElement('div');
  scrim.className = 'scrim';
  const box = document.createElement('div');
  box.className = `modal${wide ? ' wide' : ''}`;
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-modal', 'true');
  box.setAttribute('aria-label', label);
  box.innerHTML = contentHtml;
  document.body.append(scrim, box);
  const prevFocus = document.activeElement;
  const close = () => {
    scrim.remove(); box.remove();
    modalStack = modalStack.filter(m => m !== entry);
    document.removeEventListener('keydown', onKey);
    prevFocus?.focus?.();
    onClose?.();
  };
  const onKey = (e) => { if (e.key === 'Escape' && modalStack[modalStack.length - 1] === entry) close(); };
  document.addEventListener('keydown', onKey);
  scrim.onclick = close;
  const entry = { box, close };
  modalStack.push(entry);
  setTimeout(() => (box.querySelector('[autofocus]') || box.querySelector('input, textarea, select, button'))?.focus(), 30);
  return entry;
}

export function confirmDialog({ title, body = '', confirm = 'Confirm', danger = false }) {
  return new Promise(resolve => {
    let done = false;
    const m = openModal(`
      <h2>${esc(title)}</h2>
      ${body ? `<p class="muted">${body}</p>` : ''}
      <div class="modal-actions">
        <button class="btn" data-x>Cancel</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-ok autofocus>${esc(confirm)}</button>
      </div>`, { onClose: () => { if (!done) resolve(false); } });
    m.box.querySelector('[data-x]').onclick = () => m.close();
    m.box.querySelector('[data-ok]').onclick = () => { done = true; resolve(true); m.close(); };
  });
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }
}

// <template> parses table rows correctly, unlike a <div>.
function fromHtml(markup) {
  const t = document.createElement('template');
  t.innerHTML = markup.trim();
  return t.content.firstElementChild;
}

// Keyed list patching: only re-renders items whose markup changed and leaves busy items alone.
const hashes = new WeakMap();
export function patchList(container, items, key, render, isBusy = () => false) {
  const existing = new Map([...container.children].filter(c => c.dataset.key).map(c => [c.dataset.key, c]));
  let prev = null;
  for (const item of items) {
    const k = String(key(item));
    const markup = render(item);
    let el = existing.get(k);
    if (el) {
      existing.delete(k);
      if (hashes.get(el) !== markup && !isBusy(el)) {
        const fresh = fromHtml(markup);
        fresh.dataset.key = k;
        el.replaceWith(fresh);
        el = fresh;
        hashes.set(el, markup);
      }
    } else {
      el = fromHtml(markup);
      el.dataset.key = k;
      hashes.set(el, markup);
    }
    const expected = prev ? prev.nextElementSibling : container.firstElementChild;
    if (expected !== el) container.insertBefore(el, prev ? prev.nextElementSibling : container.firstElementChild);
    prev = el;
  }
  for (const el of existing.values()) if (!isBusy(el)) el.remove();
}

export const ICON = {
  external: '<svg class="ico" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 2.5h4.5V7M13.5 2.5 7 9M12 9.5V13a.5.5 0 0 1-.5.5h-9A.5.5 0 0 1 2 13V4a.5.5 0 0 1 .5-.5H6"/></svg>',
  bell: '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 8a5 5 0 0 1 10 0c0 5 2 6 2 6H3s2-1 2-6M8.3 17a1.9 1.9 0 0 0 3.4 0"/></svg>',
  search: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="7" cy="7" r="4.8"/><path d="m10.6 10.6 3.4 3.4"/></svg>',
  upload: '<svg class="ico" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 10.5V2.5M4.5 6 8 2.5 11.5 6M2.5 10.5v2a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1v-2"/></svg>',
  close: '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><path d="m4.5 4.5 9 9m0-9-9 9"/></svg>',
  copy: '<svg class="ico" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><rect x="5.5" y="5.5" width="8" height="8" rx="1.5"/><path d="M10.5 5.5V3.5a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2"/></svg>',
};
